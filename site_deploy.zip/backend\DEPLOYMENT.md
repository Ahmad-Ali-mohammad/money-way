# Production Deployment (Quick Guide)

## متطلبات
- إعداد متغيرات البيئة في `backend/.env.production` أو عبر secrets في مزود الاستضافة
- قاعدة بيانات MySQL (مديرة أو متشغلة في docker-compose)

## تشغيل باستخدام Docker Compose
1. ضع القيم الصحيحة في `docker-compose.prod.yml` أو استخدم متغيرات بيئة
2. شغّل:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d --build
   ```
3. تحقق من أن الخدمة تعمل:
   - Backend: http://your-server:4000
   - Frontend: http://your-server:3000

## ملاحظات
- تأكد من تغيير `JWT_SECRET` إلى قيمة قوية.
- إنك تستخدم قاعدة بيانات مُدارة، اضبط `DATABASE_URL` على اتصال المضيف الخارجي بدلاً من خدمة `db` في docker-compose.
- لا تنس النسخ الاحتياطي وقواعد الجدار الناري (firewall).
