-- Seed default categories
INSERT INTO categories (user_id, name, type, created_at) VALUES
(NULL, 'Freelance', 'income', NOW()),
(NULL, 'Salary', 'income', NOW()),
(NULL, 'Consulting', 'income', NOW()),
(NULL, 'Investment Returns', 'income', NOW()),
(NULL, 'Rent', 'expense', NOW()),
(NULL, 'Food & Dining', 'expense', NOW()),
(NULL, 'Transport', 'expense', NOW()),
(NULL, 'Utilities', 'expense', NOW()),
(NULL, 'Entertainment', 'expense', NOW()),
(NULL, 'Shopping', 'expense', NOW()),
(NULL, 'Healthcare', 'expense', NOW()),
(NULL, 'Education', 'expense', NOW());

-- Seed example user (password: password123)
INSERT INTO users (email, password_hash, name, currency, income_pattern, created_at, updated_at) VALUES
('demo@adaptivefi.com', '$2b$10$KzZxQxQxQxQxQxQxQxQxQeO8Z.ZZ0ZZ0ZZ0ZZ0ZZ0ZZ0ZZ0ZZ0Z', 'Demo User', 'USD', 'variable', NOW(), NOW());

-- Get the user id
SET @user_id = LAST_INSERT_ID();

-- Seed example account
INSERT INTO accounts (user_id, name, type, balance, created_at, updated_at) VALUES
(@user_id, 'Main Checking', 'checking', 5000.00, NOW(), NOW());

-- Get the account id
SET @account_id = LAST_INSERT_ID();

-- Seed example transactions
INSERT INTO transactions (user_id, account_id, amount, currency, type, category_id, notes, occurred_at, created_at, updated_at) VALUES
(@user_id, @account_id, 3500.00, 'USD', 'income', 1, 'Client project - Website redesign', DATE_SUB(NOW(), INTERVAL 5 DAY), NOW(), NOW()),
(@user_id, @account_id, 1200.00, 'USD', 'expense', 5, 'Monthly rent payment', DATE_SUB(NOW(), INTERVAL 3 DAY), NOW(), NOW()),
(@user_id, @account_id, 250.00, 'USD', 'expense', 6, 'Groceries and dining', DATE_SUB(NOW(), INTERVAL 2 DAY), NOW(), NOW()),
(@user_id, @account_id, 800.00, 'USD', 'income', 3, 'Consulting session', DATE_SUB(NOW(), INTERVAL 1 DAY), NOW(), NOW());
