نظام التصميم UI Kit

- قِيم التصميم (Design tokens): ألوان أساسية/ثانوية، أحجام خطوط، مسافات ثابتة
- مكونات أساسية: Buttons, Inputs, Selects, Modals, Alerts
- أيقونات: استخدم مكتبة محسّنة للأداء (مثل Heroicons أو custom SVG sprite)
- RTL: تحقق من اتجاه النص ومحاذاة العناصر، استخدم utilities خاصة بالـ RTL

اقتراح ألوان أساسي (مثال):
- Primary: #0B5FFF
- Secondary: #00A86B
- Accent: #F59E0B
- Neutral/Dark: #111827

Storybook
- إعداد Storybook لعرض المكونات وتسهيل اختبارها
- تضمين حالات RTL ودوال الوصول (accessibility checks)