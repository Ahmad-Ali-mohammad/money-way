#!/bin/sh
set -e
# Wait for DB to be ready (simple loop)
RETRIES=15
until npx prisma db pull >/dev/null 2>&1 || [ $RETRIES -eq 0 ]; do
  echo "Waiting for database..."
  RETRIES=$((RETRIES - 1))
  sleep 2
done
# Run migrations
npx prisma migrate deploy
# Start app
node dist/index.js
