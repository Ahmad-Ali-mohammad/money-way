# مخطط حالات الاستخدام (Use Case)

```mermaid
usecase
  :User: as U
  U -> (Create Account)
  U -> (Add Transaction)
  U -> (Generate Report)
  U -> (Set Budget)
  U -> (Set Goal)
  U -> (Receive Alerts)
```

> يغطي المخطط الحالات الأساسية التي يستخدمها المستخدم النهائي. يمكن توسيع المخطط ليتضمن أدواراً إضافية كالـ Admin أو Accountant.
