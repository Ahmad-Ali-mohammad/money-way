import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const alertSchema = z.object({
  type: z.enum(['budget_exceeded', 'goal_milestone', 'unusual_spending', 'income_received', 'bill_due', 'custom']),
  message: z.string().min(1),
  severity: z.enum(['low', 'medium', 'high']).default('medium'),
  isRead: z.boolean().default(false),
  metadata: z.record(z.string(), z.any()).optional(),
});

export const getAllAlerts = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const { isRead } = req.query;

    const where: any = { userId };
    if (isRead !== undefined) {
      where.isRead = isRead === 'true';
    }

    const alerts = await prisma.alert.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    const serialized = JSON.parse(
      JSON.stringify(alerts, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching alerts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createAlert = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = alertSchema.parse(req.body);

    const alert = await prisma.alert.create({
      data: {
        userId,
        type: data.type,
        message: data.message,
        severity: data.severity,
        isRead: data.isRead,
        metadata: data.metadata ? JSON.parse(JSON.stringify(data.metadata)) : null,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(alert, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating alert:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const markAsRead = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const alertId = parseInt(req.params.id as string);

    const alert = await prisma.alert.findFirst({
      where: { id: alertId, userId },
    });

    if (!alert) {
      return res.status(404).json({ error: 'Alert not found' });
    }

    const updated = await prisma.alert.update({
      where: { id: alertId },
      data: { isRead: true },
    });

    const serialized = JSON.parse(
      JSON.stringify(updated, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error marking alert as read:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const markAllAsRead = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    await prisma.alert.updateMany({
      where: { userId, isRead: false },
      data: { isRead: true },
    });

    res.json({ message: 'All alerts marked as read' });
  } catch (error) {
    console.error('Error marking all alerts as read:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteAlert = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const alertId = parseInt(req.params.id as string);

    const alert = await prisma.alert.findFirst({
      where: { id: alertId, userId },
    });

    if (!alert) {
      return res.status(404).json({ error: 'Alert not found' });
    }

    await prisma.alert.delete({
      where: { id: alertId },
    });

    res.json({ message: 'Alert deleted successfully' });
  } catch (error) {
    console.error('Error deleting alert:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getUnreadCount = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const count = await prisma.alert.count({
      where: { userId, isRead: false },
    });

    res.json({ unreadCount: count });
  } catch (error) {
    console.error('Error getting unread count:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Smart Alert Generation Functions
export const checkBudgetAlerts = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const budgets = await prisma.budget.findMany({
      where: { userId },
      include: { category: true },
    });

    const alerts = [];

    for (const budget of budgets) {
      const percentage = (Number(budget.spent) / Number(budget.amount)) * 100;

      if (percentage >= 100 && !budget.isAdaptive) {
        alerts.push({
          type: 'budget_exceeded' as const,
          message: `Budget exceeded for ${budget.category?.name || budget.name}! You've spent ${Math.round(percentage)}% of your budget.`,
          severity: 'high' as const,
          metadata: {
            budgetId: budget.id.toString(),
            categoryName: budget.category?.name || budget.name,
            percentage: Math.round(percentage).toString(),
          },
        });
      } else if (percentage >= 80 && percentage < 100) {
        alerts.push({
          type: 'budget_exceeded' as const,
          message: `Warning: You've used ${Math.round(percentage)}% of your ${budget.category?.name || budget.name} budget.`,
          severity: 'medium' as const,
          metadata: {
            budgetId: budget.id.toString(),
            categoryName: budget.category?.name || budget.name,
            percentage: Math.round(percentage).toString(),
          },
        });
      }
    }

    // Create alerts in database
    for (const alertData of alerts) {
      await prisma.alert.create({
        data: {
          userId,
          ...alertData,
          metadata: JSON.parse(JSON.stringify(alertData.metadata)),
        },
      });
    }

    res.json({ 
      message: `Generated ${alerts.length} budget alerts`,
      alerts: alerts.length,
    });
  } catch (error) {
    console.error('Error checking budget alerts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const checkGoalAlerts = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const goals = await prisma.goal.findMany({
      where: { userId },
    });

    const alerts = [];

    for (const goal of goals) {
      const percentage = (Number(goal.currentAmount) / Number(goal.targetAmount)) * 100;

      // Milestone alerts (25%, 50%, 75%, 100%)
      const milestones = [25, 50, 75, 100];
      for (const milestone of milestones) {
        if (percentage >= milestone && percentage < milestone + 5) {
          alerts.push({
            type: 'goal_milestone' as const,
            message: `Congratulations! You've reached ${milestone}% of your "${goal.name}" goal!`,
            severity: 'low' as const,
            metadata: {
              goalId: goal.id.toString(),
              goalName: goal.name,
              percentage: Math.round(percentage).toString(),
              milestone: milestone.toString(),
            },
          });
        }
      }
    }

    for (const alertData of alerts) {
      await prisma.alert.create({
        data: {
          userId,
          ...alertData,
          metadata: JSON.parse(JSON.stringify(alertData.metadata)),
        },
      });
    }

    res.json({ 
      message: `Generated ${alerts.length} goal alerts`,
      alerts: alerts.length,
    });
  } catch (error) {
    console.error('Error checking goal alerts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};



