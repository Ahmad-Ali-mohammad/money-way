import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
import * as dotenv from 'dotenv';

dotenv.config();

const prisma = new PrismaClient();

// User data for 20 diverse users
const usersData = [
  { email: 'ahmed@example.com', name: 'أحمد محمد', currency: 'USD', incomePattern: 'salary', country: 'SA', phone: '+966501234567' },
  { email: 'sara@example.com', name: 'سارة علي', currency: 'USD', incomePattern: 'freelancer', country: 'SA', phone: '+966507654321' },
  { email: 'mohammed@example.com', name: 'محمد خالد', currency: 'EUR', incomePattern: 'salary', country: 'AE', phone: '+971501234567' },
  { email: 'fatima@example.com', name: 'فاطمة حسن', currency: 'GBP', incomePattern: 'freelancer', country: 'UK', phone: '+447700900123' },
  { email: 'ali@example.com', name: 'علي أحمد', currency: 'SAR', incomePattern: 'salary', country: 'SA', phone: '+966502345678' },
  { email: 'layla@example.com', name: 'ليلى محمود', currency: 'USD', incomePattern: 'business', country: 'EG', phone: '+201012345678' },
  { email: 'omar@example.com', name: 'عمر سعيد', currency: 'AED', incomePattern: 'freelancer', country: 'AE', phone: '+971509876543' },
  { email: 'maryam@example.com', name: 'مريم عبدالله', currency: 'USD', incomePattern: 'salary', country: 'JO', phone: '+962791234567' },
  { email: 'youssef@example.com', name: 'يوسف إبراهيم', currency: 'EUR', incomePattern: 'business', country: 'FR', phone: '+33612345678' },
  { email: 'noor@example.com', name: 'نور الدين', currency: 'CAD', incomePattern: 'salary', country: 'CA', phone: '+14165551234' },
  { email: 'hassan@example.com', name: 'حسن عبدالرحمن', currency: 'SAR', incomePattern: 'freelancer', country: 'SA', phone: '+966503456789' },
  { email: 'aisha@example.com', name: 'عائشة فاطمة', currency: 'USD', incomePattern: 'salary', country: 'US', phone: '+12125551234' },
  { email: 'abdullah@example.com', name: 'عبدالله ماجد', currency: 'KWD', incomePattern: 'business', country: 'KW', phone: '+96550012345' },
  { email: 'zainab@example.com', name: 'زينب أمين', currency: 'QAR', incomePattern: 'salary', country: 'QA', phone: '+97433123456' },
  { email: 'khalid@example.com', name: 'خالد سامي', currency: 'USD', incomePattern: 'freelancer', country: 'MA', phone: '+212612345678' },
  { email: 'huda@example.com', name: 'هدى ناصر', currency: 'AUD', incomePattern: 'salary', country: 'AU', phone: '+61412345678' },
  { email: 'ibrahim@example.com', name: 'إبراهيم فهد', currency: 'OMR', incomePattern: 'business', country: 'OM', phone: '+96891234567' },
  { email: 'amina@example.com', name: 'أمينة سالم', currency: 'BHD', incomePattern: 'salary', country: 'BH', phone: '+97333123456' },
  { email: 'tariq@example.com', name: 'طارق وليد', currency: 'USD', incomePattern: 'freelancer', country: 'LB', phone: '+96171234567' },
  { email: 'salma@example.com', name: 'سلمى رشيد', currency: 'TND', incomePattern: 'salary', country: 'TN', phone: '+21612345678' },
];

async function main() {
  console.log('🌱 Starting seed with 20 users...');

  // Clear existing data
  console.log('🗑️  Clearing existing data...');
  await prisma.transactionTag.deleteMany();
  await prisma.transaction.deleteMany();
  await prisma.budget.deleteMany();
  await prisma.goal.deleteMany();
  await prisma.project.deleteMany();
  await prisma.alert.deleteMany();
  await prisma.receipt.deleteMany();
  await prisma.tag.deleteMany();
  await prisma.category.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();

  // Create test users
  console.log('👤 Creating 20 users...');
  const hashedPassword = await bcrypt.hash('password123', 10);

  const users = await Promise.all(
    usersData.map((userData) =>
      prisma.user.create({
        data: {
          email: userData.email,
          passwordHash: hashedPassword,
          name: userData.name,
          currency: userData.currency,
          incomePattern: userData.incomePattern,
          metadata: JSON.stringify({ phone: userData.phone, country: userData.country }),
        },
      })
    )
  );

  console.log(`✅ ${users.length} Users created`);

  // Create comprehensive data for each user
  for (let userIndex = 0; userIndex < users.length; userIndex++) {
    const user = users[userIndex];
    console.log(`\n📦 Creating data for user ${userIndex + 1}: ${user.name}...`);

    // Create categories
    const categoriesData = [
      { name: 'راتب', type: 'income', userId: user.id },
      { name: 'استشارات', type: 'income', userId: user.id },
      { name: 'مشاريع', type: 'income', userId: user.id },
      { name: 'استثمارات', type: 'income', userId: user.id },
      { name: 'إيجار', type: 'expense', userId: user.id },
      { name: 'طعام', type: 'expense', userId: user.id },
      { name: 'مواصلات', type: 'expense', userId: user.id },
      { name: 'فواتير', type: 'expense', userId: user.id },
      { name: 'ترفيه', type: 'expense', userId: user.id },
      { name: 'صحة', type: 'expense', userId: user.id },
      { name: 'تعليم', type: 'expense', userId: user.id },
      { name: 'تسوق', type: 'expense', userId: user.id },
    ];

    const categories = await Promise.all(
      categoriesData.map((cat) => prisma.category.create({ data: cat }))
    );

    // Create accounts (2-4 accounts per user)
    const accountTypes = ['checking', 'savings', 'credit', 'investment'];
    const numAccounts = Math.floor(Math.random() * 3) + 2;
    const accounts = [];

    for (let i = 0; i < numAccounts; i++) {
      const accountType = accountTypes[i % accountTypes.length];
      const balance = Math.floor(Math.random() * 50000) + 5000;
      
      const account = await prisma.account.create({
        data: {
          userId: user.id,
          name: `${accountType === 'checking' ? 'الحساب الرئيسي' : accountType === 'savings' ? 'حساب التوفير' : accountType === 'credit' ? 'البطاقة الائتمانية' : 'حساب الاستثمار'} ${i + 1}`,
          type: accountType,
          balance: balance,
          currency: user.currency,
        },
      });
      accounts.push(account);
    }

    // Create tags
    const tagsData = [
      { name: 'عاجل', color: '#ef4444', userId: user.id },
      { name: 'متكرر', color: '#3b82f6', userId: user.id },
      { name: 'مشروع', color: '#10b981', userId: user.id },
      { name: 'ضرائب', color: '#f59e0b', userId: user.id },
      { name: 'هام', color: '#8b5cf6', userId: user.id },
      { name: 'عمل', color: '#ec4899', userId: user.id },
    ];

    const tags = await Promise.all(
      tagsData.map((tag) => prisma.tag.create({ data: tag }))
    );

    // Create transactions for the last 6 months
    const now = new Date();
    const transactions: any[] = [];
    const mainAccount = accounts[0];

    // Generate income based on pattern
    const incomeAmount = user.incomePattern === 'salary' ? 5000 + Math.random() * 3000 :
                         user.incomePattern === 'freelancer' ? 3000 + Math.random() * 5000 :
                         8000 + Math.random() * 7000; // business

    for (let i = 0; i < 6; i++) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 15);
      const variation = 1 + (Math.random() - 0.5) * 0.2; // ±10% variation
      
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: Math.floor(incomeAmount * variation),
        currency: user.currency,
        type: 'income',
        categoryId: categories.find((c) => c.name === 'راتب')?.id,
        notes: user.incomePattern === 'salary' ? 'راتب شهري' : 
               user.incomePattern === 'freelancer' ? 'دخل مستقل' : 'دخل من الأعمال',
        occurredAt: date,
      });
    }

    // Random project income for freelancers and business owners
    if (user.incomePattern !== 'salary') {
      for (let i = 0; i < Math.floor(Math.random() * 4) + 2; i++) {
        const date = new Date(now.getFullYear(), now.getMonth() - Math.floor(Math.random() * 6), Math.floor(Math.random() * 28) + 1);
        transactions.push({
          userId: user.id,
          accountId: mainAccount.id,
          amount: Math.floor(Math.random() * 3000) + 1000,
          currency: user.currency,
          type: 'income',
          categoryId: categories.find((c) => c.name === 'مشاريع')?.id,
          notes: 'مشروع إضافي',
          occurredAt: date,
        });
      }
    }

    // Recurring expenses - Rent
    const rentAmount = 800 + Math.random() * 1200;
    for (let i = 0; i < 6; i++) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: Math.floor(rentAmount),
        currency: user.currency,
        type: 'expense',
        categoryId: categories.find((c) => c.name === 'إيجار')?.id,
        notes: 'إيجار شهري',
        occurredAt: date,
        isRecurring: true,
      });
    }

    // Food expenses (15-25 transactions)
    const numFoodTransactions = Math.floor(Math.random() * 10) + 15;
    for (let i = 0; i < numFoodTransactions; i++) {
      const monthsAgo = Math.floor(Math.random() * 6);
      const day = Math.floor(Math.random() * 28) + 1;
      const amount = Math.floor(Math.random() * 300) + 50;
      
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: amount,
        currency: user.currency,
        type: 'expense',
        categoryId: categories.find((c) => c.name === 'طعام')?.id,
        notes: amount > 200 ? 'تسوق بقالة' : amount > 100 ? 'مطعم' : 'وجبة سريعة',
        occurredAt: new Date(now.getFullYear(), now.getMonth() - monthsAgo, day),
      });
    }

    // Transportation expenses (10-15 transactions)
    const numTransportTransactions = Math.floor(Math.random() * 6) + 10;
    for (let i = 0; i < numTransportTransactions; i++) {
      const monthsAgo = Math.floor(Math.random() * 6);
      const day = Math.floor(Math.random() * 28) + 1;
      const amount = Math.floor(Math.random() * 150) + 30;
      
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: amount,
        currency: user.currency,
        type: 'expense',
        categoryId: categories.find((c) => c.name === 'مواصلات')?.id,
        notes: amount > 100 ? 'بنزين' : 'مواصلات عامة',
        occurredAt: new Date(now.getFullYear(), now.getMonth() - monthsAgo, day),
      });
    }

    // Utilities (monthly)
    const utilityTypes = [
      { name: 'كهرباء', min: 100, max: 250 },
      { name: 'ماء', min: 40, max: 80 },
      { name: 'إنترنت', min: 50, max: 100 },
      { name: 'هاتف', min: 30, max: 80 },
    ];

    for (let i = 0; i < 6; i++) {
      for (const utility of utilityTypes) {
        const date = new Date(now.getFullYear(), now.getMonth() - i, Math.floor(Math.random() * 10) + 5);
        const amount = Math.floor(Math.random() * (utility.max - utility.min)) + utility.min;
        
        transactions.push({
          userId: user.id,
          accountId: mainAccount.id,
          amount: amount,
          currency: user.currency,
          type: 'expense',
          categoryId: categories.find((c) => c.name === 'فواتير')?.id,
          notes: `فاتورة ${utility.name}`,
          occurredAt: date,
          isRecurring: true,
        });
      }
    }

    // Entertainment (5-10 transactions)
    const numEntertainment = Math.floor(Math.random() * 6) + 5;
    const entertainmentItems = ['Netflix', 'سينما', 'مقهى', 'رياضة', 'كتب', 'ألعاب'];
    for (let i = 0; i < numEntertainment; i++) {
      const monthsAgo = Math.floor(Math.random() * 6);
      const day = Math.floor(Math.random() * 28) + 1;
      const amount = Math.floor(Math.random() * 150) + 20;
      const item = entertainmentItems[Math.floor(Math.random() * entertainmentItems.length)];
      
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: amount,
        currency: user.currency,
        type: 'expense',
        categoryId: categories.find((c) => c.name === 'ترفيه')?.id,
        notes: item,
        occurredAt: new Date(now.getFullYear(), now.getMonth() - monthsAgo, day),
      });
    }

    // Health expenses (2-5 transactions)
    const numHealth = Math.floor(Math.random() * 4) + 2;
    for (let i = 0; i < numHealth; i++) {
      const monthsAgo = Math.floor(Math.random() * 6);
      const day = Math.floor(Math.random() * 28) + 1;
      const amount = Math.floor(Math.random() * 400) + 50;
      
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: amount,
        currency: user.currency,
        type: 'expense',
        categoryId: categories.find((c) => c.name === 'صحة')?.id,
        notes: amount > 200 ? 'كشف طبي' : 'أدوية',
        occurredAt: new Date(now.getFullYear(), now.getMonth() - monthsAgo, day),
      });
    }

    // Shopping (5-12 transactions)
    const numShopping = Math.floor(Math.random() * 8) + 5;
    for (let i = 0; i < numShopping; i++) {
      const monthsAgo = Math.floor(Math.random() * 6);
      const day = Math.floor(Math.random() * 28) + 1;
      const amount = Math.floor(Math.random() * 500) + 50;
      
      transactions.push({
        userId: user.id,
        accountId: mainAccount.id,
        amount: amount,
        currency: user.currency,
        type: 'expense',
        categoryId: categories.find((c) => c.name === 'تسوق')?.id,
        notes: amount > 300 ? 'ملابس' : amount > 150 ? 'إلكترونيات' : 'متنوع',
        occurredAt: new Date(now.getFullYear(), now.getMonth() - monthsAgo, day),
      });
    }

    // Create all transactions
    const createdTransactions = await Promise.all(
      transactions.map((tx) => prisma.transaction.create({ data: tx }))
    );

    // Add tags to some transactions
    const recurringTransactions = createdTransactions.filter((tx) => tx.isRecurring);
    for (const tx of recurringTransactions.slice(0, 5)) {
      await prisma.transactionTag.create({
        data: {
          transactionId: tx.id,
          tagId: tags.find((t) => t.name === 'متكرر')!.id,
        },
      });
    }

    // Create budgets (3-6 budgets per user)
    const budgetCategories = [
      { cat: 'طعام', amount: 600, adaptive: false },
      { cat: 'مواصلات', amount: 500, adaptive: false },
      { cat: 'ترفيه', amount: 300, adaptive: true },
      { cat: 'فواتير', amount: 400, adaptive: false },
      { cat: 'صحة', amount: 500, adaptive: true },
      { cat: 'تسوق', amount: 400, adaptive: true },
    ];

    const numBudgets = Math.floor(Math.random() * 4) + 3;
    for (let i = 0; i < numBudgets; i++) {
      const budgetInfo = budgetCategories[i];
      const category = categories.find((c) => c.name === budgetInfo.cat);
      const spent = Math.floor(Math.random() * budgetInfo.amount * 1.2);
      
      await prisma.budget.create({
        data: {
          userId: user.id,
          categoryId: category?.id,
          name: `ميزانية ${budgetInfo.cat}`,
          amount: budgetInfo.amount,
          spent: spent,
          period: 'monthly',
          isAdaptive: budgetInfo.adaptive,
          adaptiveRule: budgetInfo.adaptive ? 'adjust_based_on_income' : undefined,
          active: true,
        },
      });
    }

    // Create goals (2-5 goals per user)
    const goalTemplates = [
      { name: 'لابتوب جديد', target: 1800, monthsAway: 3 },
      { name: 'صندوق الطوارئ', target: 5000, monthsAway: 12 },
      { name: 'إجازة سنوية', target: 2500, monthsAway: 8 },
      { name: 'سيارة جديدة', target: 15000, monthsAway: 24 },
      { name: 'تجديد المنزل', target: 8000, monthsAway: 18 },
      { name: 'دورة تدريبية', target: 1200, monthsAway: 4 },
      { name: 'استثمار', target: 10000, monthsAway: 36 },
    ];

    const numGoals = Math.floor(Math.random() * 4) + 2;
    for (let i = 0; i < numGoals; i++) {
      const goal = goalTemplates[i % goalTemplates.length];
      const progress = Math.random() * 0.8; // 0-80% progress
      
      await prisma.goal.create({
        data: {
          userId: user.id,
          name: goal.name,
          targetAmount: goal.target,
          currentAmount: Math.floor(goal.target * progress),
          deadline: new Date(now.getFullYear(), now.getMonth() + goal.monthsAway, 1),
        },
      });
    }

    // Create projects (1-3 projects per user)
    const projectTemplates = [
      { name: 'متجر إلكتروني', desc: 'مشروع تجارة إلكترونية', investment: 3000, revenue: 1500, expense: 800 },
      { name: 'تطبيق موبايل', desc: 'تطبيق للإنتاجية', investment: 5000, revenue: 800, expense: 300 },
      { name: 'دورة أونلاين', desc: 'دورة تعليمية', investment: 1500, revenue: 0, expense: 0 },
      { name: 'خدمة استشارية', desc: 'خدمات استشارية', investment: 1000, revenue: 2500, expense: 500 },
      { name: 'مدونة', desc: 'مدونة متخصصة', investment: 500, revenue: 300, expense: 50 },
    ];

    const numProjects = Math.floor(Math.random() * 3) + 1;
    for (let i = 0; i < numProjects; i++) {
      const project = projectTemplates[i % projectTemplates.length];
      const statuses = ['planning', 'active', 'active', 'active']; // More likely to be active
      
      await prisma.project.create({
        data: {
          userId: user.id,
          name: `${project.name} ${i + 1}`,
          description: project.desc,
          initialInvestment: project.investment,
          monthlyRevenue: project.revenue,
          monthlyExpenses: project.expense,
          startDate: project.revenue > 0 ? new Date(now.getFullYear(), now.getMonth() - Math.floor(Math.random() * 6), 1) : undefined,
          status: statuses[Math.floor(Math.random() * statuses.length)],
          metadata: JSON.stringify({ category: 'business', index: i }),
        },
      });
    }

    // Create alerts (2-5 alerts per user)
    const alertTemplates = [
      { type: 'budget_warning', message: 'اقتربت من تجاوز الميزانية', severity: 'high', isRead: false },
      { type: 'goal_progress', message: 'تحقيق تقدم ممتاز في الهدف', severity: 'low', isRead: false },
      { type: 'large_transaction', message: 'معاملة كبيرة تمت', severity: 'medium', isRead: true },
      { type: 'low_balance', message: 'رصيد منخفض في الحساب', severity: 'high', isRead: false },
      { type: 'bill_reminder', message: 'تذكير بفاتورة قادمة', severity: 'medium', isRead: false },
    ];

    const numAlerts = Math.floor(Math.random() * 4) + 2;
    for (let i = 0; i < numAlerts; i++) {
      const alert = alertTemplates[i % alertTemplates.length];
      
      await prisma.alert.create({
        data: {
          userId: user.id,
          type: alert.type,
          message: alert.message,
          severity: alert.severity,
          isRead: alert.isRead,
          metadata: JSON.stringify({ index: i }),
        },
      });
    }

    console.log(`   ✅ User ${userIndex + 1} complete: ${createdTransactions.length} transactions`);
  }

  console.log('\n🎉 Seed completed successfully with 20 diverse users!');
  console.log('\n📊 Password for all users: password123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
