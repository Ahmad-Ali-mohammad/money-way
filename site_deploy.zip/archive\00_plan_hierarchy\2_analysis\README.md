قسم 2 — تحليل النظام التفصيلي

ملفات في هذا المجلد:
- 2.1_functional_requirements.md
- 2.2_non_functional_requirements.md