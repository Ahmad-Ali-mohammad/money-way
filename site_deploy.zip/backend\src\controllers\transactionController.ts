import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const transactionSchema = z.object({
  amount: z.number().positive(),
  type: z.enum(['income', 'expense', 'transfer', 'investment']),
  accountId: z.number().optional(),
  toAccountId: z.number().optional(), // Added for transfers
  categoryId: z.number().optional(),
  notes: z.string().optional(),
  tags: z.array(z.string()).optional(),
  occurredAt: z.string().datetime().optional(),
  isRecurring: z.boolean().optional(),
  recurrenceRule: z.string().optional(),
});

export const getAllTransactions = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const {
      limit = '50',
      offset = '0',
      type,
      startDate,
      endDate,
      categoryId,
      accountId,
      search
    } = req.query;

    const where: any = { userId };

    if (type && typeof type === 'string' && type !== 'all') {
      where.type = type;
    }

    if (startDate || endDate) {
      where.occurredAt = {};
      if (startDate) where.occurredAt.gte = new Date(startDate as string);
      if (endDate) where.occurredAt.lte = new Date(endDate as string);
    }

    if (categoryId) {
      where.categoryId = parseInt(categoryId as string);
    }

    if (accountId) {
      where.accountId = parseInt(accountId as string);
    }

    if (search && typeof search === 'string') {
      where.OR = [
        { notes: { contains: search, mode: 'insensitive' } },
        { tags: { array_contains: search } }
      ];
    }

    const transactions = await prisma.transaction.findMany({
      where,
      include: {
        category: true,
        account: true,
      },
      orderBy: { occurredAt: 'desc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
    });

    const serialized = JSON.parse(
      JSON.stringify(transactions, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createTransaction = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = transactionSchema.parse(req.body);

    // Use Prisma transaction for atomic operations
    const result = await prisma.$transaction(async (tx) => {
      // Get user's first account if no accountId provided
      let mainAccount = await tx.account.findFirst({
        where: { userId },
      });

      if (!mainAccount) {
        mainAccount = await tx.account.create({
          data: {
            userId,
            name: 'Main Account',
            type: 'checking',
            balance: 0,
          },
        });
      }

      const accountId = data.accountId || mainAccount.id;

      // Verify account belongs to user
      const sourceAccount = await tx.account.findFirst({
        where: { id: accountId, userId },
      });
      if (!sourceAccount) {
        throw new Error('Account not found or access denied');
      }

      // If transfer, verify destination account
      if (data.type === 'transfer' && data.toAccountId) {
        const destAccount = await tx.account.findFirst({
          where: { id: data.toAccountId, userId },
        });
        if (!destAccount) {
          throw new Error('Destination account not found');
        }
      }

      // Handle tags: find or create tags and prepare connection
      let tagConnections = {};
      if (data.tags && data.tags.length > 0) {
        const tagPromises = data.tags.map(async (tagName) => {
          let tag = await tx.tag.findUnique({
            where: { userId_name: { userId, name: tagName } },
          });
          if (!tag) {
            tag = await tx.tag.create({
              data: { userId, name: tagName },
            });
          }
          return tag.id;
        });
        const tagIds = await Promise.all(tagPromises);
        tagConnections = {
          create: tagIds.map((tagId) => ({
            tag: { connect: { id: tagId } },
          })),
        };
      }

      // Create transaction
      const transaction = await tx.transaction.create({
        data: {
          userId,
          accountId,
          toAccountId: data.type === 'transfer' ? data.toAccountId : null,
          amount: data.amount,
          type: data.type,
          categoryId: data.categoryId || null,
          notes: data.notes,
          occurredAt: data.occurredAt ? new Date(data.occurredAt) : new Date(),
          isRecurring: data.isRecurring || false,
          recurrenceRule: data.recurrenceRule,
          tags: tagConnections,
        },
        include: {
          category: true,
          account: true,
          toAccount: true,
          tags: {
            include: {
              tag: true,
            },
          },
        },
      });

      // Update balances
      if (data.type === 'income') {
        await tx.account.update({
          where: { id: accountId },
          data: { balance: { increment: data.amount } },
        });
      } else if (data.type === 'expense') {
        await tx.account.update({
          where: { id: accountId },
          data: { balance: { decrement: data.amount } },
        });
      } else if (data.type === 'transfer' && data.toAccountId) {
        // Decrease source
        await tx.account.update({
          where: { id: accountId },
          data: { balance: { decrement: data.amount } },
        });
        // Increase destination
        await tx.account.update({
          where: { id: data.toAccountId },
          data: { balance: { increment: data.amount } },
        });
      }

      return transaction;
    });

    const serialized = JSON.parse(
      JSON.stringify(result, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating transaction:', error);
    res.status(500).json({ error: error instanceof Error ? error.message : 'Internal server error' });
  }
};

export const getTransactionById = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const transactionId = parseInt(req.params.id as string);

    const transaction = await prisma.transaction.findFirst({
      where: {
        id: transactionId,
        userId,
      },
      include: {
        category: true,
        account: true,
      },
    });

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    const serialized = JSON.parse(
      JSON.stringify(transaction, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching transaction:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateTransaction = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const transactionId = parseInt(req.params.id as string);
    const data = transactionSchema.partial().parse(req.body);

    const result = await prisma.$transaction(async (tx) => {
      const existing = await tx.transaction.findFirst({
        where: { id: transactionId, userId },
      });

      if (!existing) {
        throw new Error('Transaction not found');
      }

      // Revert old balances
      if (existing.type === 'income') {
        await tx.account.update({
          where: { id: existing.accountId },
          data: { balance: { decrement: Number(existing.amount) } },
        });
      } else if (existing.type === 'expense') {
        await tx.account.update({
          where: { id: existing.accountId },
          data: { balance: { increment: Number(existing.amount) } },
        });
      } else if (existing.type === 'transfer' && existing.toAccountId) {
        await tx.account.update({
          where: { id: existing.accountId },
          data: { balance: { increment: Number(existing.amount) } },
        });
        await tx.account.update({
          where: { id: existing.toAccountId },
          data: { balance: { decrement: Number(existing.amount) } },
        });
      }

      // Apply new balances
      const newAmount = data.amount !== undefined ? data.amount : Number(existing.amount);
      const newType = data.type || existing.type;
      const newAccountId = data.accountId !== undefined ? data.accountId : existing.accountId;
      const newToAccountId = data.toAccountId !== undefined ? data.toAccountId : existing.toAccountId;

      if (newType === 'income') {
        await tx.account.update({
          where: { id: newAccountId },
          data: { balance: { increment: newAmount } },
        });
      } else if (newType === 'expense') {
        await tx.account.update({
          where: { id: newAccountId },
          data: { balance: { decrement: newAmount } },
        });
      } else if (newType === 'transfer' && newToAccountId) {
        await tx.account.update({
          where: { id: newAccountId },
          data: { balance: { decrement: newAmount } },
        });
        await tx.account.update({
          where: { id: newToAccountId },
          data: { balance: { increment: newAmount } },
        });
      }

      // Handle tags update
      let tagData = {};
      if (data.tags !== undefined) {
        // Remove old tags
        await tx.transactionTag.deleteMany({
          where: { transactionId },
        });

        if (data.tags.length > 0) {
          const tagPromises = data.tags.map(async (tagName) => {
            let tag = await tx.tag.findUnique({
              where: { userId_name: { userId, name: tagName } },
            });
            if (!tag) {
              tag = await tx.tag.create({
                data: { userId, name: tagName },
              });
            }
            return tag.id;
          });
          const tagIds = await Promise.all(tagPromises);
          tagData = {
            create: tagIds.map((tagId) => ({
              tag: { connect: { id: tagId } },
            })),
          };
        }
      }

      // Update transaction
      const updated = await tx.transaction.update({
        where: { id: transactionId },
        data: {
          amount: data.amount,
          type: data.type,
          accountId: data.accountId,
          toAccountId: data.type === 'transfer' ? data.toAccountId : (data.type !== undefined ? null : undefined),
          categoryId: data.categoryId,
          notes: data.notes,
          occurredAt: data.occurredAt ? new Date(data.occurredAt) : undefined,
          isRecurring: data.isRecurring,
          recurrenceRule: data.recurrenceRule,
          ...(data.tags !== undefined && { tags: tagData }),
        },
        include: {
          category: true,
          account: true,
          toAccount: true,
          tags: {
            include: {
              tag: true,
            },
          },
        },
      });

      return updated;
    });

    const serialized = JSON.parse(
      JSON.stringify(result, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error updating transaction:', error);
    res.status(500).json({ error: error instanceof Error ? error.message : 'Internal server error' });
  }
};

export const deleteTransaction = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const transactionId = parseInt(req.params.id as string);

    await prisma.$transaction(async (tx) => {
      const existing = await tx.transaction.findFirst({
        where: { id: transactionId, userId },
      });

      if (!existing) {
        throw new Error('Transaction not found');
      }

      // Revert the balance change
      if (existing.type === 'income') {
        await tx.account.update({
          where: { id: existing.accountId },
          data: { balance: { decrement: Number(existing.amount) } },
        });
      } else if (existing.type === 'expense') {
        await tx.account.update({
          where: { id: existing.accountId },
          data: { balance: { increment: Number(existing.amount) } },
        });
      } else if (existing.type === 'transfer' && existing.toAccountId) {
        // Increment source (revert decrease)
        await tx.account.update({
          where: { id: existing.accountId },
          data: { balance: { increment: Number(existing.amount) } },
        });
        // Decrement destination (revert increase)
        await tx.account.update({
          where: { id: existing.toAccountId },
          data: { balance: { decrement: Number(existing.amount) } },
        });
      }

      // Delete the transaction
      await tx.transaction.delete({
        where: { id: transactionId },
      });
    });

    res.json({ message: 'Transaction deleted successfully' });
  } catch (error) {
    if (error instanceof Error && error.message === 'Transaction not found') {
      return res.status(404).json({ error: 'Transaction not found' });
    }
    console.error('Error deleting transaction:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getTransactionStats = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const { startDate, endDate } = req.query;

    const where: any = { userId };
    if (startDate && endDate) {
      where.occurredAt = {
        gte: new Date(startDate as string),
        lte: new Date(endDate as string),
      };
    }

    const [incomeTransactions, expenseTransactions] = await Promise.all([
      prisma.transaction.findMany({
        where: { ...where, type: 'income' },
      }),
      prisma.transaction.findMany({
        where: { ...where, type: 'expense' },
      }),
    ]);

    const totalIncome = incomeTransactions.reduce(
      (sum, t) => sum + Number(t.amount),
      0
    );
    const totalExpense = expenseTransactions.reduce(
      (sum, t) => sum + Number(t.amount),
      0
    );

    res.json({
      totalIncome,
      totalExpense,
      netBalance: totalIncome - totalExpense,
      transactionCount: incomeTransactions.length + expenseTransactions.length,
    });
  } catch (error) {
    console.error('Error fetching transaction stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const bulkCreateTransactions = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const transactions = z.array(transactionSchema).parse(req.body);

    const results = [];
    const errors = [];

    // Get user's first account once
    let mainAccount = await prisma.account.findFirst({
      where: { userId },
    });

    if (!mainAccount) {
      mainAccount = await prisma.account.create({
        data: {
          userId,
          name: 'Main Account',
          type: 'checking',
          balance: 0,
        },
      });
    }

    for (let i = 0; i < transactions.length; i++) {
      try {
        const data = transactions[i];

        const result = await prisma.$transaction(async (tx) => {
          const accountId = data.accountId || mainAccount!.id;

          // Verify accounts
          const sourceAccount = await tx.account.findFirst({
            where: { id: accountId, userId },
          });
          if (!sourceAccount) throw new Error('Source account not found');

          if (data.type === 'transfer' && data.toAccountId) {
            const destAccount = await tx.account.findFirst({
              where: { id: data.toAccountId, userId },
            });
            if (!destAccount) throw new Error('Destination account not found');
          }

          // Handle tags
          let tagConnections = {};
          if (data.tags && data.tags.length > 0) {
            const tagPromises = data.tags.map(async (tagName) => {
              let tag = await tx.tag.findUnique({
                where: { userId_name: { userId, name: tagName } },
              });
              if (!tag) {
                tag = await tx.tag.create({
                  data: { userId, name: tagName },
                });
              }
              return tag.id;
            });
            const tagIds = await Promise.all(tagPromises);
            tagConnections = {
              create: tagIds.map((tagId) => ({
                tag: { connect: { id: tagId } },
              })),
            };
          }

          const transaction = await tx.transaction.create({
            data: {
              userId,
              accountId,
              toAccountId: data.type === 'transfer' ? data.toAccountId : null,
              amount: data.amount,
              type: data.type,
              categoryId: data.categoryId || null,
              notes: data.notes,
              occurredAt: data.occurredAt ? new Date(data.occurredAt) : new Date(),
              isRecurring: data.isRecurring || false,
              recurrenceRule: data.recurrenceRule,
              tags: tagConnections,
            },
            include: {
              category: true,
              account: true,
              toAccount: true,
              tags: { include: { tag: true } },
            },
          });

          // Update balances
          if (data.type === 'income') {
            await tx.account.update({
              where: { id: accountId },
              data: { balance: { increment: data.amount } },
            });
          } else if (data.type === 'expense') {
            await tx.account.update({
              where: { id: accountId },
              data: { balance: { decrement: data.amount } },
            });
          } else if (data.type === 'transfer' && data.toAccountId) {
            await tx.account.update({
              where: { id: accountId },
              data: { balance: { decrement: data.amount } },
            });
            await tx.account.update({
              where: { id: data.toAccountId },
              data: { balance: { increment: data.amount } },
            });
          }

          return transaction;
        });

        results.push(result);
      } catch (error) {
        errors.push({ index: i, error: error instanceof Error ? error.message : 'Unknown error' });
      }
    }

    const serialized = JSON.parse(
      JSON.stringify(results, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json({
      success: results.length,
      failed: errors.length,
      results: serialized,
      errors,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error bulk creating transactions:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getTransactionTemplates = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    // Get most common transactions as templates
    const templates = await prisma.transaction.groupBy({
      by: ['notes', 'categoryId', 'type'],
      where: {
        userId,
        notes: { not: null },
      },
      _count: {
        id: true,
      },
      _avg: {
        amount: true,
      },
      orderBy: {
        _count: {
          id: 'desc',
        },
      },
      take: 10,
    });

    const templatesWithDetails = await Promise.all(
      templates.map(async (template) => {
        const category = template.categoryId
          ? await prisma.category.findUnique({
            where: { id: template.categoryId },
            select: { name: true },
          })
          : null;

        return {
          notes: template.notes,
          categoryId: template.categoryId,
          categoryName: category?.name,
          type: template.type,
          averageAmount: Math.round(Number(template._avg.amount) * 100) / 100,
          frequency: template._count.id,
        };
      })
    );

    res.json(templatesWithDetails);
  } catch (error) {
    console.error('Error fetching transaction templates:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getAdvancedTransactionStats = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const { period = 'monthly', startDate, endDate } = req.query;

    let dateFilter: any = { userId };
    if (startDate && endDate) {
      dateFilter.occurredAt = {
        gte: new Date(startDate as string),
        lte: new Date(endDate as string),
      };
    } else {
      // Default to last 12 months
      const twelveMonthsAgo = new Date();
      twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);
      dateFilter.occurredAt = { gte: twelveMonthsAgo };
    }

    const transactions = await prisma.transaction.findMany({
      where: dateFilter,
      include: { category: true },
    });

    // Group by period
    const groupedData: any = {};

    transactions.forEach((t) => {
      let periodKey: string;
      const date = t.occurredAt;

      switch (period) {
        case 'daily':
          periodKey = date.toISOString().split('T')[0];
          break;
        case 'weekly':
          const weekStart = new Date(date);
          weekStart.setDate(date.getDate() - date.getDay());
          periodKey = weekStart.toISOString().split('T')[0];
          break;
        case 'yearly':
          periodKey = date.getFullYear().toString();
          break;
        default: // monthly
          periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      }

      if (!groupedData[periodKey]) {
        groupedData[periodKey] = {
          period: periodKey,
          income: 0,
          expense: 0,
          count: 0,
          categories: {},
        };
      }

      if (t.type === 'income') {
        groupedData[periodKey].income += Number(t.amount);
      } else {
        groupedData[periodKey].expense += Number(t.amount);
      }

      groupedData[periodKey].count += 1;

      // Category breakdown
      const categoryName = t.category?.name || 'Uncategorized';
      if (!groupedData[periodKey].categories[categoryName]) {
        groupedData[periodKey].categories[categoryName] = 0;
      }
      groupedData[periodKey].categories[categoryName] += Number(t.amount);
    });

    // Calculate trends and averages
    const periods = Object.values(groupedData);
    const totalIncome = periods.reduce((sum: number, p: any) => sum + p.income, 0);
    const totalExpense = periods.reduce((sum: number, p: any) => sum + p.expense, 0);
    const avgIncome = periods.length > 0 ? totalIncome / periods.length : 0;
    const avgExpense = periods.length > 0 ? totalExpense / periods.length : 0;

    res.json({
      period,
      totalPeriods: periods.length,
      summary: {
        totalIncome,
        totalExpense,
        netBalance: totalIncome - totalExpense,
        averageIncome: Math.round(avgIncome * 100) / 100,
        averageExpense: Math.round(avgExpense * 100) / 100,
      },
      periods: periods.map((p: any) => ({
        ...p,
        net: p.income - p.expense,
        savingsRate: p.income > 0 ? Math.round(((p.income - p.expense) / p.income) * 10000) / 100 : 0,
      })),
    });
  } catch (error) {
    console.error('Error fetching advanced transaction stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};




