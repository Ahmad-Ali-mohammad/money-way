# الفصل الثالث: الدراستين التحليلية والتصميمية

## 3.1 منهجية التطوير (موسّعة ومفصّلة)

### فلسفة العمل
اتباع منهجية Agile بتعديلات تناسب مشروع تخرج: السعي لإصدار MVP سريع مع التركيز على جودة الكود، القابلية للصيانة، والقدرة على التوسّع لاحقًا. تم اختيار تكرارات قصيرة (Sprints أسبوعية أو كل أسبوعين) لتقليل زمن الاكتشاف والتصحيح.

### أدوار الفريق ومسؤولياتها
- Product Owner: تجميع متطلبات المشروع، ترتيب الأولويات، التواصل مع المشرف.
- Scrum Master (دوام جزئي): إزالة العوائق، تنظيم الاجتماعات اليومية.
- المطورون: تقسيم المهام، كتابة الكود والاختبارات، توثيق المخرجات.
- QA / Tester: كتابة خطط الاختبار، تنفيذ اختبارات التكامل والقبول.

### سير العمل (Workflow)
- فتح Issue تفصيلي لكل ميزة.
- إنشاء فرع feature/<issue-number> لكل ميزة.
- كتابة اختبارات قبل أو أثناء التطوير (TDD إن أمكن).
- إرسال Pull Request وطلب مراجعة (Code Review) من زميل واحد على الأقل.
- دمج الفرع بعد اجتياز الاختبارات والمراجعات، وتحديث Changelog.
- نشر نسخة تطوير (staging) للاختبار اليدوي.

### أدوات ومتريكس متبعة
- GitHub (Issues, PRs)
- Vitest وSupertest للاختبارات
- ESLint وPrettier للالتزام بأسلوب الكود
- CI (GitHub Actions) لتشغيل الاختبارات والبناء

---

## 3.2 تحليل المتطلبات (مفصّل وموسّع)

### 3.2.1 المتطلبات الوظيفية (موسّعة)
- Authentication & Authorization
  - تسجيل المستخدم، تسجيل الدخول، استعادة كلمة المرور.
  - أدوار: مستخدم عادي، مشرف نظام (Admin).
- Accounts Management
  - CRUD للحسابات، ربط حساب افتراضي بالنظام (مثل Cash)، عمليات تحويل داخلية.
- Transactions
  - إضافة/تحرير/حذف معاملات مع دعم التكرار (Recurring), التصنيف بالفئة والوسوم.
  - دعم للحسومات/الضرائب إن لزم.
- Budgets
  - إنشاء قواعد ميزانية (مبالغ ثابتة، نسب مئوية، ميزانيات Adaptive بسيطة).
  - تنبيهات عند الاقتراب أو التجاوز.
- Goals
  - إنشاء أهداف وحساب نسبة التقدّم، إضافة معالجات للدفعات (contributions).
- Reports & Analytics
  - توليد ملخصات زمنية، تصدير CSV/PDF، رسوم بيانية تفاعلية.
- Notifications
  - إشعارات محلية (in-app) وبإمكان التكامل لرسائل بريدية أو Push لاحقًا.

### 3.2.2 المتطلبات غير الوظيفية (موسّعة)
- الأداء
  - زمن استجابة للطلبات الشائعة <= 500ms في بيئة التطوير على الأجهزة الحديثة.
  - تصميم لاستيعاب آلاف المعاملات لكل مستخدم في المستقبل.
- الأمان
  - تشفير كلمات المرور، استخدام HTTPS، تخزين آمن لمتغيرات البيئة.
- الصدق والموثوقية
  - معامل معاملات ضمن DB تكون ضمن transaction لضمان التكامل عند تعدد العمليات.
- الصيانة
  - توثيق واضح، إرشادات إعداد dev/production، تنفيذ migrations بشكل منظم.

### 3.2.3 قصص المستخدم الموسّعة
- قصة: "إدارة الدخل المتكرر" — كـ"مستخدم" أريد تعريف دخل شهري ثابت بحيث يُضاف تلقائيًا كل شهر ويتم احتسابه في تقاريري.
  - Acceptance Criteria: إضافة دخل متكرر، جدول التنفيذ الآلي، تعديل/إيقاف.
- قصة: "ميزانية ذكية" — كـ"مستخدم" أريد نظامًا يقترح تعديل ميزانيتي بناءً على إنفاق الأشهر الثلاثة الماضية.
  - Acceptance Criteria: عرض توصية، إمكانية قبول/رفض التعديل.

---

## 3.3 التصميم المعماري (تفصيلي)

### 3.3.1 رؤيا عالية المستوى
يتألف النظام من: Frontend SPA، Backend (REST API)، قاعدة بيانات، خدمة الإشعارات، ومُجَدِّول للعمليات المتكررة. يعتمد Backend على طبقات: Routes → Controllers → Services → Repositories (Prisma).

### 3.3.2 مكونات أساسية ووظائفها
- Frontend (React + TypeScript)
  - عرض البيانات، التحكم في حالة الواجهة، تهيئة الاستدعاءات للـ API.
- API Server (Express + TypeScript)
  - نقاط النهاية، التحقق من صحة الطلبات (Zod), مصادقة (JWT), إدارة الأخطاء.
- Data Layer (Prisma)
  - ORM لإدارة migrations، استعلامات transaction وcreateMany للمجموعات.
- Scheduler (node-cron)
  - مهام مجدولة: إضافة معاملات متكررة، تنظيف البيانات، إرسال تنبيهات.
- Notification Service
  - تسجيل رسائل التنبيه، آلية تسليم لاحقة للبريد/Push.

### 3.3.3 Component Diagram (موجز)
انظر الملف: `diagrams/uml_component.puml`.

---

## 3.4 نماذج البيانات والاعتبارات التفصيلية

### 3.4.1 مخطط ERD (تفصيل الحقول)
- Users: id, email, password_hash, name, currency, created_at, updated_at
- Accounts: id, user_id(FK), name, type, balance, currency, meta
- Transactions: id, user_id(FK), account_id(FK), to_account_id(FK?), amount, currency, type, category_id(FK?), notes, receipt_id, is_recurring, recurrence_rule, next_occurrence, occurred_at, created_at
- Budgets: id, user_id(FK), category_id(FK?), name, amount, period, spent, active, adaptive_rule
- Goals: id, user_id(FK), name, target_amount, current_amount, deadline, icon

### 3.4.2 سياسات التكامل والقيود
- القيود (Constraints): unique(email), unique tag per user, composite unique (transaction_id, tag_id) in TransactionTag
- سياسات الحذف: ON DELETE CASCADE لموارد المستخدم؛ ON DELETE SET NULL لبعض العلاقات (مثلاً: toAccount)

### 3.4.3 أمثلة استعلامات أداء ومحسّنات
- فهرسة: إنشاء index على (user_id, occurred_at)
- Aggregation: استخدام materialized views للتقارير الثقيلّة (مثلاً: رصيد شهري بحسب الفئة)
- Pagination: استخدام cursor-based pagination بدلاً من offset

---

## 3.5 تصميم API تفصيلي ومواصفات endpoints

### مبادئ التصميم
- RESTful، موارد واضحة، استخدام HTTP verbs المناسب.
- التحقق من المدخلات عبر Zod، وإرجاع رسائل خطأ موحّدة.
- مصادقة JWT مع صلاحية زمنية قصيرة واستخدام Refresh Tokens آمن.

### مجموعة نقاط نهاية مفصّلة (نماذج)

1) Authentication
- POST /api/auth/register
  - Request: { email, password, name }
  - Response: 201 { user: { id, email, name } }
- POST /api/auth/login
  - Request: { email, password }
  - Response: 200 { token }

2) Transactions
- GET /api/transactions?from=&to=&limit=&cursor=
  - Response: 200 { data: [transactions], nextCursor }
- POST /api/transactions
  - Request: { accountId, amount, currency, categoryId?, occurredAt?, notes?, tags? }
  - Response: 201 { transaction }
- PUT /api/transactions/:id
  - Request: { ...fields }
  - Response: 200 { transaction }

3) Budgets
- POST /api/budgets
  - Request: { name, categoryId?, amount, period }
  - Response: 201 { budget }
- GET /api/budgets
  - Response: 200 [budgets]

### أمثلة على جسم الخطأ (Error Response)
```json
{
  "status": "error",
  "code": 400,
  "message": "Validation failed",
  "details": [{ "field": "amount", "error": "Must be positive" }]
}
```

---

## 3.6 مخططات السلوك والتتابع (Sequence & Activity)

### تسلسل إضافة معاملة
انظر: `diagrams/sequence_add_transaction.puml` — يتضمن تفاعل المستخدم مع الواجهة، استدعاء API، تسجيل المعاملة في DB، تحديث الأرصدة، وإرسال تنبيهات إن لزم.

### تسلسل فحص الميزانيات
انظر: `diagrams/sequence_budget_alert.puml` — مجدول يقرأ الميزانيات، يحسب الإنفاق، ويولّد إشعارًا في القوائم (Notification Queue).

---

## 3.7 الطبقات البرمجية (Pattern & Best Practices)

### فصل الطبقات
- Controllers: التعامل مع الطلب/الاستجابة، استدعاء الخدمات.
- Services: منطق الأعمال (Business Logic) — تحويل العملات، حساب التنبؤات، قواعد الميزنة.
- Repositories: تفاعل منخفض المستوى مع Prisma/DB.

### استراتيجيات المعالجة الخاطئة
- استخدام Transactions في Prisma (`prisma.$transaction`) عند تعديل عدة جداول مرتبطة.
- تجنّب عمليات Blocking على الخادم عبر تحويل العمليات الطويلة إلى Jobs مجدولة.

---

## 3.8 الأمان والخصوصية (تنفيذية)

### سياسات المصادقة
- Access Token (JWT): مدة قصيرة (مثلاً 15-60 دقيقة).
- Refresh Token: مدة أطول وتخزينه بأمان (HttpOnly cookie أو في DB مع rotating tokens).
- Endpoint /api/auth/refresh لإصدار توكن جديد بعد التحقق.

### حماية endpoints
- تحقق من الملكية (Ownership): تحقق أن `userId` في الموارد تُمثّل نفس المستخدم صاحب التوكين.
- Rate Limiting: حد لطلبات تسجيل الدخول، وبعض endpoints الحساسة.
- Input Validation: Zod في كل نقاط النهاية.

### إدارة الأسرار
- استخدام .env في البيئات المحلية و Secret Manager في الإنتاج (مثل Azure Key Vault أو AWS Secrets Manager).
- تقييد صلاحيات المستخدمين للعناصر التي تتعامل مع الأسرار.

---

## 3.9 اختبار النظام (Testing Strategy)

### مستويات الاختبارات
- Unit Tests: اختبارات وحدات للخدمات والمنطق (Vitest)
- Integration Tests: اختبارات قواعد بيانات باستخدام DB اختبارية (SQLite in-memory أو test DB)
- End-to-End (E2E): تدفق تسجيل مستخدم، إضافة معاملات، توليد تقارير (يمكن اعتماد Playwright لاحقًا)

### حالات اختبار نموذجية
- تسجيل مستخدم جديد والتأكد من تشفير كلمة المرور.
- إضافة معاملة والتحقق من تحديث رصيد الحساب.
- إنشاء ميزانية والتحقق من إشعار التجاوز.
- سيناريوهات استثنائية: رفض معاملة بمبلغ سلبي، محاولة الوصول لمورد مستخدم آخر.

### أتمتة الاختبارات
- تشغيل الاختبارات ضمن GitHub Actions على كل PR.
- نشر تقارير التغطية (Coverage) وتحليل الفشل.

---

## 3.10 الأداء والقابلية للتوسع (Scalability)

### قياس الأداء
- مؤشرات: Latency (p95, p99), Throughput (requests/sec), DB query time.
- أدوات مقترحة للقياس: k6, Locust.

### تحسينات مرشحة
- Caching: استخدام Redis للكاش المؤقت لاستعلامات Dashboard.
- Connection Pooling: تأكد من إعدادات Prisma/DB وPgBouncer في حال PostgreSQL.
- Partitioning / Archival: أرشفة المعاملات القديمة لتحسين أداء عمليات OLTP.

---

## 3.11 التكامل والتوزيع (Deployment & CI/CD)

### وصف عملية النشر
- CI: بناء المشروع، تشغيل اختبارات، تشغيل SAST
- CD: نشر إلى بيئة staging ثم production بعد نجاح الاختبارات اليدوية

### بنية اقتراحية
- Dockerize للخادم والواجهة.
- إعداد docker-compose مع قواعد بيانات dev و service configurations.
- إعداد pipeline في GitHub Actions لنشر إلى Azure App Service أو DigitalOcean App Platform.

### متغيرات البيئة الحسّاسة
- DATABASE_URL, JWT_SECRET, NODE_ENV, SENTRY_DSN (اختياري للتتبع)

---

## 3.12 المراقبة والتشخيص (Monitoring & Observability)

- Health Check endpoints: `/api/health`
- Logging: structured logs عبر winston أو pino، مع طبقات مستوى log.
- Metrics: export via Prometheus or use application insights for Azure.
- Error Tracking: Sentry أو حلول مماثلة.

---

## 3.13 نسخة احتياطية وخطط التعافي من الكوارث

- نسخ يومية/أسبوعية للـ Database، مع اختبار عملية الاستعادة بشكل دوري.
- تخزين backups مشفّرة في أماكن متعددة (S3/Blob Storage).

---

## 3.14 ملحقات تنفيذية: أمثلة على Prisma وSQL
- راجع `chapter3_sql_prisma.md` للحصول على استعلامات مفصلة، نصائح للفهرسة، واستخدام materialized views.

---

## 3.15 مستندات وقوائم تحقق (Checklists)

### Pre-release Checklist
- كل الـ PRs مراجعون ✔
- اختبارات الوحدة والتكامل ناجحة ✔
- فحص أمان SAST/DAST تم ✔
- وثائق الاستخدام محدثة ✔

### Accessibility Checklist
- عناصر ARIA مضافة للمكونات التفاعلية
- دعم لوحة المفاتيح والتنقل
- التباينات اللونية متوافقة

---

## 3.16 قياسات نجاح المشروع (KPIs)

- نجاح الوظائف: نسبة الوظائف التي تم تسليمها مقابل الخطة
- أداء النظام: متوسط زمن الاستجابة تحت الحدّ المحدد
- جودة المنتج: عدد الأخطاء الحرجة بعد الإصدار
- تأثير المستخدم: معدل الاحتفاظ بعد 30 يوم (Target: > 50%)

---

## 3.17 ملاحظات عملية للفرق المستقبلية والتوسع

- فصل الخدمات ذات الأحمال العالية إلى microservices مستقلة (Notifications, Analytics)
- النظر في استخدام event-driven architecture (Kafka/RabbitMQ) للعمليات غير التزامنية
- اعتماد بنية مختبرة جيداً للتعامل مع التوسع

---

## 3.18 خاتمة الفصل

يغطي هذا الفصل المتطلبات التحليلية والتصميمية والتقنية للنظام مع تركيز عملي على القابلية للتنفيذ، الأمان، والأداء. يوفّر الأدلة اللازمة للمطورين والباحثين لمتابعة التنفيذ والتوسع لاحقًا.

---

**ملاحظة:** يوجد ملاحق عملية ونماذج إضافية في الملفات المرافقة (`chapter3_sql_prisma.md`, `security_threat_model.md`, وملفات PlantUML في مجلد `diagrams/`).

