import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma';
import { z } from 'zod';
import { seedUserData } from '../services/userService';
import { getJwtSecret } from '../lib/jwt';

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().optional(),
  incomePattern: z.string().optional(),
  currency: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const googleAuthSchema = z.object({
  token: z.string(),
  email: z.string().email(),
  name: z.string().optional(),
  picture: z.string().optional(),
});

export const register = async (req: Request, res: Response) => {
  try {
    const { email, password, name, incomePattern, currency } = registerSchema.parse(req.body);

    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        name,
        incomePattern,
        currency: currency || 'USD',
      },
    });

    // Seed default data for new user experience
    await seedUserData(user.id);

    const token = jwt.sign(
      { userId: user.id },
      getJwtSecret(),
      { expiresIn: '24h' }
    );

    res.status(201).json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', '),
        details: error.issues 
      });
    }
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.passwordHash) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { userId: user.id },
      getJwtSecret(),
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', '),
        details: error.issues 
      });
    }
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const googleAuth = async (req: Request, res: Response) => {
  try {
    console.log('Google Auth Request:', req.body);
    
    const { email, name, picture, token: googleToken } = req.body;

    // Validate required fields
    if (!email || !name) {
      return res.status(400).json({ 
        error: 'Missing required fields: email and name are required' 
      });
    }

    // Check if user exists
    let user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      // Create new user for Google OAuth
      user = await prisma.user.create({
        data: {
          email,
          name: name || email.split('@')[0],
          passwordHash: '', // No password for OAuth users
          currency: 'USD',
          incomePattern: 'regular',
        },
      });

      console.log('Created new Google user:', user.id);
      // Seed default data for new user
      await seedUserData(user.id);
    } else {
      console.log('Existing Google user logged in:', user.id);
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id },
      getJwtSecret(),
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

import { AuthRequest } from '../middleware/authMiddleware';

export const getProfile = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        currency: true,
        incomePattern: true,
        createdAt: true,
      },
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Provide default values for optional fields
    res.json({
      id: user.id,
      email: user.email,
      name: user.name || 'User',
      currency: user.currency || 'USD',
      incomePattern: user.incomePattern || 'fixed',
      createdAt: user.createdAt,
    });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' });
  }
};

export const updateProfile = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const updateSchema = z.object({
      name: z.string().optional(),
      email: z.string().email().optional(),
      currency: z.string().optional(),
      incomePattern: z.string().optional(),
      currentPassword: z.string().optional(),
      newPassword: z.string().min(6).optional(),
    });

    const data = updateSchema.parse(req.body);

    // If changing password, verify current password
    if (data.newPassword && data.currentPassword) {
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user || !user.passwordHash) {
        return res.status(400).json({ error: 'Cannot change password' });
      }

      const isMatch = await bcrypt.compare(data.currentPassword, user.passwordHash);
      if (!isMatch) {
        return res.status(401).json({ error: 'Current password is incorrect' });
      }

      const passwordHash = await bcrypt.hash(data.newPassword, 10);
      await prisma.user.update({
        where: { id: userId },
        data: { passwordHash },
      });
    }

    // Update other fields
    const updateData: any = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.email !== undefined) {
      // Check if email is already taken
      const existingUser = await prisma.user.findUnique({ where: { email: data.email } });
      if (existingUser && existingUser.id !== userId) {
        return res.status(400).json({ error: 'Email already in use' });
      }
      updateData.email = data.email;
    }
    if (data.currency !== undefined) updateData.currency = data.currency;
    if (data.incomePattern !== undefined) updateData.incomePattern = data.incomePattern;

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        email: true,
        name: true,
        currency: true,
        incomePattern: true,
        createdAt: true,
      },
    });

    res.json(updatedUser);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', '),
        details: error.issues 
      });
    }
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
