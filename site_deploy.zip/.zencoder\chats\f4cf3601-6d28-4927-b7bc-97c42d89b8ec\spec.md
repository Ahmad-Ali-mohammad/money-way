# Technical Specification - Transaction Advanced Filtering & Search

## 1. Overview
Enhance the transaction management system by adding advanced filtering capabilities (date ranges, specific categories/accounts) and a keyword search functionality.

## 2. Technical Context
- **Language**: TypeScript
- **Frontend**: React, Tailwind CSS
- **Backend**: Express.js, Prisma ORM
- **API**: REST

## 3. Implementation Approach

### Backend Changes (`backend/src/controllers/transactionController.ts`)
- Update `getAllTransactions` to handle new query parameters:
  - `startDate`, `endDate` (ISO dates)
  - `categoryId` (number)
  - `accountId` (number)
  - `search` (string - searches in notes and tags)
- Modify Prisma `where` clause to include these filters dynamically.
- Use `contains` with `insensitive` mode for the search functionality.

### Frontend Changes (`frontend/src/pages/Transactions.tsx`)
- Add new state variables for:
  - `startDate`, `endDate`
  - `selectedCategoryId`, `selectedAccountId`
  - `searchQuery`
- Implement a search bar component.
- Enhance the filter section with:
  - Date range pickers (or preset buttons like "Last 7 days", "This Month").
  - Dropdowns for Category and Account filtering.
- Update `fetchData` to pass these filters as query parameters to `transactionService.getAll()`.

## 4. Source Code Structure Changes
No new files required. Existing files will be modified.

## 5. Data Model / API Changes
### Updated API: `GET /api/transactions`
**Query Parameters:**
- `limit` (default: 50)
- `offset` (default: 0)
- `type` (optional: income, expense, transfer)
- `startDate` (optional: ISO string)
- `endDate` (optional: ISO string)
- `categoryId` (optional: number)
- `accountId` (optional: number)
- `search` (optional: string)

## 6. Delivery Phases
1. **Phase 1 (Backend)**: Update controller and test filtering with Postman/Curl.
2. **Phase 2 (Frontend - Logic)**: Update service and state management to handle filters.
3. **Phase 3 (Frontend - UI)**: Add filter components (Date range, Dropdowns, Search bar).
4. **Phase 4 (Verification)**: Comprehensive testing of filter combinations.

## 7. Verification Approach
- **Linting**: Run `npm run lint` in both frontend and backend.
- **Manual Testing**:
  - Filter by specific date range and verify results.
  - Search for a keyword in notes and verify only matching transactions appear.
  - Combine multiple filters (e.g., "Expense" + "Category: Food" + "This Month").
