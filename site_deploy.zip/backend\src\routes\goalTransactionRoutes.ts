import { Router } from 'express';
import {
  getAllGoalTransactions,
  getGoalTransactionById,
  createGoalTransaction,
  updateGoalTransaction,
  deleteGoalTransaction,
} from '../controllers/goalTransactionController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

// Apply authentication middleware to all routes
router.use(authMiddleware);

// GET /api/goal-transactions - Get all goal transactions (optional goalId query param)
router.get('/', getAllGoalTransactions);

// GET /api/goal-transactions/:id - Get goal transaction by ID
router.get('/:id', getGoalTransactionById);

// POST /api/goal-transactions - Create new goal transaction
router.post('/', createGoalTransaction);

// PUT /api/goal-transactions/:id - Update goal transaction
router.put('/:id', updateGoalTransaction);

// DELETE /api/goal-transactions/:id - Delete goal transaction
router.delete('/:id', deleteGoalTransaction);

export default router;
