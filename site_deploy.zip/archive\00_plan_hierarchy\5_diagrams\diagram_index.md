فهرس المخططات وربطها بأقسام الخطة

- `erd.puml` (في /diagrams)  → يوضح الجداول الأساسية: users, accounts, transactions, categories, budgets, goals, projects, alerts
  • مرتبط مباشرة بملف `6_database/schema.sql` و`6_database/erd.puml`

- `transaction_flow.puml` → يطابق سير العمل اليومي لإدخال المعاملات (`4_workflows/4.2_daily_transaction_workflow.md`)

- `alerts_engine_sequence.puml` → يطابق تصميم محرك التنبيهات (`4_workflows/4.3_alerts_workflow.md`)

- `auth_sequence.puml`, `bank_linking_sequence.puml` → مرتبطة بعمليات التسجيل وربط الحسابات في `4_workflows/4.1_registration_workflow.md` و `2_analysis/2.1_functional_requirements.md`

تعليمات: استخدم ملفات `.puml` في مجلد `diagrams/` كمصدر حقيقي. الملفات في هذا المجلد تعمل كفهرس ونُسخ مُبسطة قابلة للتعديل لتوليد ERD مُحدث.