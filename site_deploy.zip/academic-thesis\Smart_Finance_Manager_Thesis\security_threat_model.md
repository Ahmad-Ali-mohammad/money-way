# نموذج التهديدات والأمن (Threat Model & Security) — موسّع

## مقدمة
يهدف هذا المستند إلى تقديم تحليل منهجي للتهديدات وتأثيرها على نظام "مدير المال الذكي"، واقتراح تدابير عملية للحدّ من المخاطر مع التركيز على حماية البيانات المالية والشخصية للمستخدمين.

---

## 1. تعريف الأصول والأولويات
- **البيانات الحساسة (High):** كلمات المرور، رموز المصادقة (Tokens)، معلومات البطاقات (إن وُجدت لاحقًا).
- **بيانات العمليات (Medium):** سجلات المعاملات، أرصدة الحسابات، سجلات الميزانيات.
- **البنية التحتية (Medium):** قواعد البيانات، خوادم API، مخزن الملفات.
- **الوظائف الحرجة (High):** آليات الدفع، إضافة/تحرير المعاملات، صدق وإمكانية التتبع (Audit).

---

## 2. نموذج بيانات التدفق (Data Flow Diagram) — نقاط الدخول والحساسيات
- Actors: User, Attacker, Admin
- Processes: Frontend, Backend API, Scheduler, Notification Service
- Data Stores: Database, File Storage

النقاط الساخنة:
- مصادقة المستخدم (login) — تعرض لمحاولات brute-force
- رفع الملفات — تعريض لخطر تحميل ملفات ضارة
- عمليات التعديل على البيانات المالية — خطر تجاوز الصلاحيات

---

## 3. تحليل STRIDE (تهديدات حسب الصنف)

S - Spoofing (انتحال الهوية)
- Threat: محاولة استخدام توكن مسروق للوصول لحساب مستخدم.
- Mitigation: توقيت الانقضاء القصير للتوكن، استخدام Refresh tokens مع تدوير، تشفير النقل.

T - Tampering (العبث بالبيانات)
- Threat: تعديل الرصيد بطرق غير مصرح بها عبر API.
- Mitigation: التحقق من الملكية، استخدام DB transactions، توقيع الأحداث المهمة في السجلات.

R - Repudiation (الإنكار)
- Threat: إنكار إجراء معاملة.
- Mitigation: تسجيل audit logs مفصّلة مع طابع زمني وID المعرّف للمستخدم.

I - Information disclosure (كشف المعلومات)
- Threat: كشف بيانات المستخدمين من خلال exposure أو أخطاء في التكوين.
- Mitigation: تشفير الحقول الحساسة، تدوير المفاتيح، سياسات وصول صارمة.

D - Denial of Service (حرمان من الخدمة)
- Threat: هجوم DDoS على نقاط API.
- Mitigation: Rate limiting, WAF, auto-scaling.

E - Elevation of Privilege (رفع الصلاحيات)
- Threat: استغلال ثغرة للوصول لصلاحيات أعلى.
- Mitigation: principle of least privilege, review access control rules, penetration testing.

---

## 4. تقييم المخاطر (Risk Assessment Matrix)
- صنف المخاطر حسب احتمالية الحدوث والتأثير (High/Medium/Low).
- مثال:
  - مصادقة مخترقة: احتمال Medium — تأثير High → Priority: High
  - كشف بيانات (exposed logs): احتمال Low — تأثير High → Priority: Medium

---

## 5. متطلبات أمان معمّقة (Security Requirements)
- جميع الاتصالات تُجري عبر TLS.
- استعمال Zod للتحقق من صحة المدخلات في كل endpoint.
- عدم تسجيل كلمات المرور أو التوكنات في الـ logs.
- تنفيذ CSP والـ HTTP security headers.
- تنفيذ rate limiting وaccount lockout بعد محاولات فاشلة متكررة.

---

## 6. التصميم الأمني للتوثيق (Authentication & Authorization)
### 6.1 Flow مقترح للمصادقة
1. Login → Backend verifies credentials → Issues Access Token (short) and Refresh Token (long).
2. Access Token يستخدم في Authorization header للوصول للموارد.
3. Refresh Token مخزّن في DB مع rotation لتحقيق أمان أعلى.

### 6.2 Authorization Patterns
- Resource-based ACLs: تحقق من أن كل طلب يتبع قواعد الملكية (ownerId === token.userId).
- Role-based checks for admin-only endpoints.

---

## 7. إدارة الأسرار والمفاتيح
- استخدم secret manager (Azure Key Vault / AWS Secrets Manager / HashiCorp Vault).
- تدوير المفاتيح بشكل دوري وتقييد الوصول عبر IAM policies.

---

## 8. تدابير حماية الواجهات وصقلها
- Input Sanitization & Output Encoding للحماية من XSS.
- CSP header وFeature-Policy.
- جعل ملفات الاستضافة static content محمية عبر CDN مع إعدادات CORS صارمة.

---

## 9. Logging، المراقبة والتنبيهات
- Structured logs مع مستويات (info/warn/error)
- إرسال الأحداث الحرجة (login failures, token refreshes، suspicious IPs) إلى SIEM
- إعداد تنبيهات في حالة زيادة معدلات الخطأ أو حدوث سلوك غير اعتيادي

---

## 10. اختبار الأمان (Security Testing Plan)
- SAST: static code analysis on each PR (Codacy/ESLint security plugins)
- DAST: scheduled OWASP ZAP scans on staging
- Dependency Scans: Trivy on dependency changes
- Penetration Testing: دورية سنوية أو قبل إطلاق ميزات مالية حساسة

---

## 11. خطة الاستجابة للحوادث (Incident Response)
- اكتشاف: مراقبة تنبيهات SIEM
- تقييم: تصنيف الحادث (تسريب بيانات، اختراق جلسة، DoS)
- احتواء: تعطيل الحسابات المتأثرة، إغلاق النقاط الأمنية الملتهمة
- معاودة العمل/الإصلاح: سحب الإصلاح، تحديث الوثائق، إخطار المتأثرين
- Post-mortem: إجراء RCA ونشر تقرير داخلي

التوقيتات المستهدفة:
- Detect: < 1 hour
- Contain: < 4 hours
- Recover: < 48 hours (يعتمد على نوع الحادث)

---

## 12. قائمة تحقق أمني قبل الإطلاق (Security Checklist)
- ✅ TLS enforced
- ✅ No secrets in repo
- ✅ SAST/DAST scheduled and green
- ✅ Rate limiting and WAF configured
- ✅ Logging with alerts for security events

---

## 13. تدريب الفريق وعمليات الأمن (Operations)
- دورات دورية حول secure coding
- سيناريوهات tabletop للاختبار والجاهزية
- توثيق سياسات الوصول وإدارة الحوادث

---

## 14. خاتمة
يُعد الأمن جزءًا لا يتجزأ من دورة حياة التطوير؛ الاعتماد على التحليل الدوري للتهديدات، الأتمتة في الفحوصات الأمنية، وتدريب الفريق سيقلل بشكل كبير من مخاطر التعرض لحوادث أمنية جسيمة.