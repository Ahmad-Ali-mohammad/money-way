قسم 6 — قاعدة البيانات (Database)

المحتوى:
- `schema.sql` — تعريف الجداول الأساسية وقيود العلاقات (DDL)
- `erd.puml` — مخطط كيان-علاقة UML مبسّط مُطابق لملف SQL

الجداول الأساسية المقترحة:
- users
- accounts
- transactions
- categories
- tags
- budgets
- budget_rules
- goals
- projects
- alerts
- receipts
- roles, permissions

تعليمات: هذا مخطط مبدئي قابل للتعديل قبل التنفيذ. إن قاعدة المشروع الحالية تحتوي على سكريبتات تهيئة في `backend/scripts/init-mysql.sql` و seed، راجعها للتوافق.

أوامر مفيدة:
- لتوليد ERD كصورة (يتطلب Docker و image `plantuml/plantuml`):
  - Linux/Mac: `./generate_erd.sh png` أو `./generate_erd.sh svg`
  - Windows: `generate_erd.bat png`

- لتشغيل الترحيل المحلي (مثال بسيط):
  - استخدم MySQL CLI: `mysql -u root -p < migrations/V1__init_schema.sql`
  - ثم نفذ: `mysql -u root -p < migrations/seed_example.sql`

ملاحظة: يمكنك استخدام أدوات ترحيل مثل Flyway أو Liquibase أو Knex.js بدلاً من السكربت اليدوي.