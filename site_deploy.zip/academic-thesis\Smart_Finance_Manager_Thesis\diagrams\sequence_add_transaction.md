# مخطط تسلسل: إضافة معاملة (Add Transaction)

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant API
    participant DB

    User->>Frontend: يملأ نموذج المعاملة (amount, category, account)
    Frontend->>API: POST /api/transactions {payload}
    API->>DB: INSERT transaction
    DB-->>API: OK
    API-->>Frontend: 201 Created + transaction
    Frontend-->>User: عرض المعاملة المضافة وتحديث الـ Dashboard
```

> يُظهر المخطط عملية بسيطة لالتقاط تسلسل الطلب من المستخدم وحتى تخزين المعاملة وتحديث الواجهة.
