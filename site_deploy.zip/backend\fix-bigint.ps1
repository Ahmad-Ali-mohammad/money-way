# Fix BigInt to String conversion for MongoDB
Write-Host "Converting BigInt to String for MongoDB compatibility..." -ForegroundColor Cyan

$controllersPath = "C:\Users\User\Desktop\adaptivefi---financial-freedom\backend\src\controllers"

$files = Get-ChildItem -Path $controllersPath -Filter "*.ts" -Recurse

foreach ($file in $files) {
    Write-Host "Processing: $($file.Name)" -ForegroundColor Yellow
    
    $content = Get-Content -Path $file.FullName -Raw
    $originalContent = $content
    
    # Replace BigInt( with String conversions (just remove BigInt wrapper since IDs are already strings)
    $content = $content -replace 'const userId = BigInt\(req\.user!\.userId\);', 'const userId = req.user!.userId;'
    $content = $content -replace 'const transactionId = BigInt\(req\.params\.id as string\);', 'const transactionId = req.params.id as string;'
    $content = $content -replace 'const accountId = BigInt\(req\.params\.id as string\);', 'const accountId = req.params.id as string;'
    $content = $content -replace 'const categoryId = BigInt\(req\.params\.id as string\);', 'const categoryId = req.params.id as string;'
    $content = $content -replace 'const budgetId = BigInt\(req\.params\.id as string\);', 'const budgetId = req.params.id as string;'
    $content = $content -replace 'const goalId = BigInt\(req\.params\.id as string\);', 'const goalId = req.params.id as string;'
    $content = $content -replace 'const projectId = BigInt\(req\.params\.id as string\);', 'const projectId = req.params.id as string;'
    $content = $content -replace 'const alertId = BigInt\(req\.params\.id as string\);', 'const alertId = req.params.id as string;'
    $content = $content -replace 'const tagId = BigInt\(req\.params\.id as string\);', 'const tagId = req.params.id as string;'
    
    # Replace in data assignments
    $content = $content -replace 'accountId: data\.accountId \? BigInt\(data\.accountId\) : account\.id', 'accountId: data.accountId ? data.accountId : account.id'
    $content = $content -replace 'categoryId: data\.categoryId \? BigInt\(data\.categoryId\) : null', 'categoryId: data.categoryId ? data.categoryId : null'
    $content = $content -replace '\.\.\.\(data\.categoryId && \{ categoryId: BigInt\(data\.categoryId\) \}\)', '...(data.categoryId && { categoryId: data.categoryId })'
    $content = $content -replace '\.\.\.\(data\.parentId && \{ parentId: BigInt\(data\.parentId\) \}\)', '...(data.parentId && { parentId: data.parentId })'
    $content = $content -replace 'parentId: data\.parentId \? BigInt\(data\.parentId\) : null', 'parentId: data.parentId ? data.parentId : null'
    
    # Replace in tag controller
    $content = $content -replace 'id: BigInt\(transactionId\)', 'id: transactionId'
    $content = $content -replace 'id: BigInt\(tagId\)', 'id: tagId'
    $content = $content -replace 'transactionId: BigInt\(transactionId\)', 'transactionId: transactionId'
    $content = $content -replace 'tagId: BigInt\(tagId\)', 'tagId: tagId'
    
    if ($content -ne $originalContent) {
        Set-Content -Path $file.FullName -Value $content -NoNewline
        Write-Host "  ✅ Updated!" -ForegroundColor Green
    } else {
        Write-Host "  ⏭️  No changes needed" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "✅ Conversion complete!" -ForegroundColor Green
Write-Host "Now run: npm run dev" -ForegroundColor Cyan
