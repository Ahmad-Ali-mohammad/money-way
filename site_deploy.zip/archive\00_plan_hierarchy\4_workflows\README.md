قسم 4 — سير العمل التفصيلي

ملفات في هذا المجلد:
- 4.1_registration_workflow.md
- 4.2_daily_transaction_workflow.md
- 4.3_alerts_workflow.md