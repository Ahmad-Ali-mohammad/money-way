import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const categorySchema = z.object({
  name: z.string().min(1),
  type: z.enum(['expense', 'income', 'transfer']).optional(),
  parentId: z.number().optional(),
});

export const getAllCategories = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const categories = await prisma.category.findMany({
      where: {
        OR: [{ userId }, { userId: null }],
      },
      include: {
        parent: true,
        children: true,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(categories, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createCategory = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = categorySchema.parse(req.body);

    const category = await prisma.category.create({
      data: {
        userId,
        name: data.name,
        type: data.type || 'expense',
        parentId: data.parentId ? data.parentId : null,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(category, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getCategoryById = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(req.params.id as string);

    const category = await prisma.category.findFirst({
      where: {
        id: categoryId,
        OR: [{ userId }, { userId: null }],
      },
      include: {
        parent: true,
        children: true,
      },
    });

    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    const serialized = JSON.parse(
      JSON.stringify(category, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateCategory = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(req.params.id as string);
    const data = categorySchema.partial().parse(req.body);

    const existing = await prisma.category.findFirst({
      where: { id: categoryId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Category not found' });
    }

    const updated = await prisma.category.update({
      where: { id: categoryId },
      data: {
        ...(data.name !== undefined && { name: data.name }),
        ...(data.type !== undefined && { type: data.type }),
        ...(data.parentId !== undefined && { parentId: data.parentId }),
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(updated, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error updating category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteCategory = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(req.params.id as string);

    const existing = await prisma.category.findFirst({
      where: { id: categoryId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Category not found' });
    }

    await prisma.category.delete({
      where: { id: categoryId },
    });

    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    console.error('Error deleting category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};



