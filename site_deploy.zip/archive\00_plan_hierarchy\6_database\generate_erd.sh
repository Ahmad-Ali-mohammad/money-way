#!/usr/bin/env bash
# Generate ERD image(s) from erd.puml using PlantUML Docker image
# Usage: ./generate_erd.sh [png|svg]

FORMAT=${1:-png}
DIR="$(cd "$(dirname "$0")" && pwd)"
PUML="$DIR/erd.puml"
OUT="$DIR/erd.$FORMAT"

if [ ! -f "$PUML" ]; then
  echo "ERROR: $PUML not found"
  exit 1
fi

echo "Generating ERD ($FORMAT)..."
# Requires Docker and the plantuml/plantuml image
docker run --rm -v "$DIR":/work -w /work plantuml/plantuml:latest plantuml -t$FORMAT erd.puml

if [ -f "$OUT" ]; then
  echo "Generated: $OUT"
else
  echo "Generation failed. Ensure Docker is running and image plantuml/plantuml:latest is available."
fi