import { Router } from 'express';
import {
  getAllBudgets,
  createBudget,
  getBudgetById,
  updateBudget,
  deleteBudget,
  getBudgetProgress,
  recalculateBudgets,
  processSurplusTransfer,
} from '../controllers/budgetController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.use(authMiddleware);

router.get('/', getAllBudgets);
router.post('/', createBudget);
router.get('/recalculate', recalculateBudgets);
router.post('/surplus-transfer', processSurplusTransfer);
router.get('/:id', getBudgetById);
router.put('/:id', updateBudget);
router.delete('/:id', deleteBudget);
router.get('/:id/progress', getBudgetProgress);

export default router;
