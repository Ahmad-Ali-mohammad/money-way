import { Router } from 'express';
import { authenticate } from '../middleware/authMiddleware';
import {
  getAllBudgetCategories,
  getBudgetCategoryById,
  createBudgetCategory,
  updateBudgetCategory,
  deleteBudgetCategory,
  getBudgetCategoryStats,
} from '../controllers/budgetCategoryController';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Budget Category routes
router.get('/', getAllBudgetCategories);
router.get('/:id', getBudgetCategoryById);
router.post('/', createBudgetCategory);
router.put('/:id', updateBudgetCategory);
router.delete('/:id', deleteBudgetCategory);
router.get('/:id/stats', getBudgetCategoryStats);

export default router;
