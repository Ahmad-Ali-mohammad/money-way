import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';
import { 
  calculateAdaptiveBudgetAmount, 
  recalculateAllAdaptiveBudgets,
  checkBudgetSurplusTransfer 
} from '../services/adaptiveBudgetService';

// Schema with proper type coercion for numeric strings
const budgetSchema = z.object({
  categoryId: z.number().optional().nullable(),
  name: z.string().min(1, 'Budget name is required'),
  amount: z.union([z.number(), z.string()]).optional().transform(val => {
    if (val === undefined || val === null) return undefined;
    const num = typeof val === 'string' ? parseFloat(val) : val;
    if (isNaN(num) || num <= 0) throw new Error('Amount must be a positive number');
    return num;
  }),
  period: z.enum(['daily', 'weekly', 'monthly', 'yearly']).default('monthly'),
  startDate: z.string().datetime().optional().nullable(),
  endDate: z.string().datetime().optional().nullable(),
  isAdaptive: z.boolean().default(false),
  isPercentage: z.boolean().default(false),
  percentage: z.union([z.number(), z.string()]).optional().transform(val => {
    if (val === undefined || val === null) return undefined;
    const num = typeof val === 'string' ? parseFloat(val) : val;
    if (isNaN(num) || num < 0 || num > 100) throw new Error('Percentage must be between 0 and 100');
    return num;
  }),
  adaptiveRule: z.string().optional().nullable(),
});

// Enriched Read: Fetch budgets with dynamically calculated spent amount
export const getAllBudgets = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const budgets = await prisma.budget.findMany({
      where: { userId },
      include: {
        category: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Enrich each budget with calculated spent amount from transactions
    const enrichedBudgets = await Promise.all(
      budgets.map(async (budget) => {
        // Calculate spent amount by aggregating EXPENSE transactions for this budget's period
        const startDate = budget.startDate || new Date(new Date().getFullYear(), new Date().getMonth(), 1);
        const endDate = budget.endDate || new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);

        const transactions = await prisma.transaction.findMany({
          where: {
            userId: userId,
            type: 'expense',
            ...(budget.categoryId && { categoryId: budget.categoryId }),
            occurredAt: {
              gte: startDate,
              lte: endDate,
            },
          },
          select: {
            amount: true,
          },
        });

        const calculatedSpent = transactions.reduce((sum, t) => sum + Number(t.amount), 0);

        // Update budget spent amount if different
        if (Math.abs(calculatedSpent - Number(budget.spent)) > 0.01) {
          await prisma.budget.update({
            where: { id: budget.id },
            data: { spent: calculatedSpent },
          });
        }

        return {
          ...budget,
          spent: calculatedSpent,
          remaining: Number(budget.amount) - calculatedSpent,
          percentage: budget.amount > 0 ? (calculatedSpent / Number(budget.amount)) * 100 : 0,
          isOverBudget: calculatedSpent > Number(budget.amount),
        };
      })
    );

    const serialized = JSON.parse(
      JSON.stringify(enrichedBudgets, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching budgets:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Create budget with explicit field mapping
export const createBudget = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = budgetSchema.parse(req.body);

    // Validate category if provided
    if (data.categoryId) {
      const categoryExists = await prisma.category.findFirst({
        where: {
          id: data.categoryId,
          OR: [
            { userId: userId },
            { userId: null } // System categories
          ]
        }
      });

      if (!categoryExists) {
        return res.status(400).json({ error: 'Invalid category ID' });
      }
    }

    // Calculate initial amount for percentage-based budgets
    let initialAmount = data.amount || 0;
    if (data.isPercentage && data.percentage && !data.amount) {
      // Will be calculated on first income
      initialAmount = 0;
    }

    // Explicit data mapping to prevent field injection
    const budget = await prisma.budget.create({
      data: {
        userId: userId,
        categoryId: data.categoryId || null,
        name: data.name,
        amount: initialAmount,
        spent: 0,
        period: data.period || 'monthly',
        startDate: data.startDate ? new Date(data.startDate) : new Date(),
        endDate: data.endDate ? new Date(data.endDate) : null,
        isAdaptive: data.isAdaptive || false,
        isPercentage: data.isPercentage || false,
        percentage: data.percentage || null,
        adaptiveRule: data.adaptiveRule || null,
        active: true,
      },
      include: {
        category: true,
      },
    });

    const response = {
      ...budget,
      remaining: Number(budget.amount) - Number(budget.spent),
      percentage: budget.amount > 0 ? (Number(budget.spent) / Number(budget.amount)) * 100 : 0,
      isOverBudget: Number(budget.spent) > Number(budget.amount),
    };

    const serialized = JSON.parse(
      JSON.stringify(response, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: error.issues.map((e: z.ZodIssue) => ({ field: e.path.join('.'), message: e.message }))
      });
    }
    console.error('Error creating budget:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Enriched read for single budget
export const getBudgetById = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const budgetId = parseInt(req.params.id as string);

    if (isNaN(budgetId)) {
      return res.status(400).json({ error: 'Invalid budget ID' });
    }

    const budget = await prisma.budget.findFirst({
      where: {
        id: budgetId,
        userId,
      },
      include: {
        category: true,
      },
    });

    if (!budget) {
      return res.status(404).json({ error: 'Budget not found or access denied' });
    }

    // Calculate spent amount dynamically from transactions
    const startDate = budget.startDate || new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const endDate = budget.endDate || new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);

    const transactions = await prisma.transaction.findMany({
      where: {
        userId: userId,
        type: 'expense',
        ...(budget.categoryId && { categoryId: budget.categoryId }),
        occurredAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      select: {
        amount: true,
      },
    });

    const calculatedSpent = transactions.reduce((sum, t) => sum + Number(t.amount), 0);

    // Update budget if spent amount changed
    if (Math.abs(calculatedSpent - Number(budget.spent)) > 0.01) {
      await prisma.budget.update({
        where: { id: budget.id },
        data: { spent: calculatedSpent },
      });
    }

    const response = {
      ...budget,
      spent: calculatedSpent,
      remaining: Number(budget.amount) - calculatedSpent,
      percentage: budget.amount > 0 ? (calculatedSpent / Number(budget.amount)) * 100 : 0,
      isOverBudget: calculatedSpent > Number(budget.amount),
      transactionCount: transactions.length,
    };

    const serialized = JSON.parse(
      JSON.stringify(response, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching budget:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update budget with explicit field mapping
export const updateBudget = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const budgetId = parseInt(req.params.id as string);

    if (isNaN(budgetId)) {
      return res.status(400).json({ error: 'Invalid budget ID' });
    }

    // Verify ownership
    const existing = await prisma.budget.findFirst({
      where: { id: budgetId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Budget not found or access denied' });
    }

    const data = budgetSchema.partial().parse(req.body);

    // Validate category if being updated
    if (data.categoryId !== undefined && data.categoryId !== null) {
      const categoryExists = await prisma.category.findFirst({
        where: {
          id: data.categoryId,
          OR: [
            { userId: userId },
            { userId: null }
          ]
        }
      });

      if (!categoryExists) {
        return res.status(400).json({ error: 'Invalid category ID' });
      }
    }

    // Explicit data mapping to prevent field injection
    const updateData: any = {};
    
    if (data.name !== undefined) {
      updateData.name = data.name;
    }
    if (data.categoryId !== undefined) {
      updateData.categoryId = data.categoryId;
    }
    if (data.amount !== undefined) {
      updateData.amount = data.amount;
    }
    if (data.period !== undefined) {
      updateData.period = data.period;
    }
    if (data.startDate !== undefined) {
      updateData.startDate = data.startDate ? new Date(data.startDate) : null;
    }
    if (data.endDate !== undefined) {
      updateData.endDate = data.endDate ? new Date(data.endDate) : null;
    }
    if (data.isAdaptive !== undefined) {
      updateData.isAdaptive = data.isAdaptive;
    }
    if (data.isPercentage !== undefined) {
      updateData.isPercentage = data.isPercentage;
    }
    if (data.percentage !== undefined) {
      updateData.percentage = data.percentage;
    }
    if (data.adaptiveRule !== undefined) {
      updateData.adaptiveRule = data.adaptiveRule;
    }

    const updated = await prisma.budget.update({
      where: { id: budgetId },
      data: updateData,
      include: {
        category: true,
      },
    });

    const response = {
      ...updated,
      remaining: Number(updated.amount) - Number(updated.spent),
      percentage: updated.amount > 0 ? (Number(updated.spent) / Number(updated.amount)) * 100 : 0,
      isOverBudget: Number(updated.spent) > Number(updated.amount),
    };

    const serialized = JSON.parse(
      JSON.stringify(response, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: error.issues.map((e: z.ZodIssue) => ({ field: e.path.join('.'), message: e.message }))
      });
    }
    console.error('Error updating budget:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Securely delete budget after verifying ownership
export const deleteBudget = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const budgetId = parseInt(req.params.id as string);

    if (isNaN(budgetId)) {
      return res.status(400).json({ error: 'Invalid budget ID' });
    }

    // Verify ownership before deletion
    const existing = await prisma.budget.findFirst({
      where: { id: budgetId, userId },
      include: { category: true },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Budget not found or access denied' });
    }

    await prisma.budget.delete({
      where: { id: budgetId },
    });

    res.json({ 
      message: 'Budget deleted successfully',
      deletedBudget: {
        id: existing.id.toString(),
        name: existing.name,
        category: existing.category?.name || null
      }
    });
  } catch (error) {
    console.error('Error deleting budget:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getBudgetProgress = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const budgetId = parseInt(req.params.id as string);

    // Fetch budget
    const budget = await prisma.budget.findFirst({
      where: { id: budgetId, userId },
      include: { category: true },
    });

    if (!budget) {
      return res.status(404).json({ error: 'Budget not found' });
    }

    // Calculate current amount if adaptive
    let currentAmount = Number(budget.amount);
    if (budget.isAdaptive) {
      currentAmount = await calculateAdaptiveBudgetAmount(userId, budgetId);
    }

    const percentage = currentAmount > 0 ? (Number(budget.spent) / currentAmount) * 100 : 0;
    const remaining = currentAmount - Number(budget.spent);

    res.json({
      budgetId: budget.id.toString(),
      category: budget.category?.name || budget.name,
      amount: currentAmount,
      spent: Number(budget.spent),
      remaining,
      percentage: Math.round(percentage * 100) / 100,
      isOverBudget: Number(budget.spent) > currentAmount,
      isAdaptive: budget.isAdaptive,
      isPercentage: budget.isPercentage,
    });
  } catch (error) {
    console.error('Error fetching budget progress:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const recalculateBudgets = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    
    const results = await recalculateAllAdaptiveBudgets(userId);
    
    res.json({
      message: 'Budgets recalculated successfully',
      results,
    });
  } catch (error) {
    console.error('Error recalculating budgets:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const processSurplusTransfer = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    
    await checkBudgetSurplusTransfer(userId);
    
    res.json({ message: 'Surplus transfer processed successfully' });
  } catch (error) {
    console.error('Error processing surplus transfer:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};



