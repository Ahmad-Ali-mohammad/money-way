import { prisma } from '../lib/prisma';

export interface RiskMetrics {
  debtToIncomeRatio: number;
  savingsRate: number;
  liquidityRatio: number;
  financialStressIndex: number;
  riskLevel: 'low' | 'medium' | 'high';
  recommendations: string[];
}

export async function calculateRiskMetrics(userId: number): Promise<RiskMetrics> {
  // Get last 12 months of data
  const twelveMonthsAgo = new Date();
  twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);

  const transactions = await prisma.transaction.findMany({
    where: {
      userId,
      occurredAt: { gte: twelveMonthsAgo },
    },
  });

  const accounts = await prisma.account.findMany({
    where: { userId },
  });

  // Calculate monthly income and expenses
  const monthlyIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + Number(t.amount), 0) / 12;

  const monthlyExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + Number(t.amount), 0) / 12;

  // Debt-to-Income Ratio (DTI)
  // Assuming debts are tracked as negative balances or specific categories
  const totalDebt = accounts
    .filter(a => a.balance < 0)
    .reduce((sum, a) => sum + Math.abs(Number(a.balance)), 0);

  const debtToIncomeRatio = monthlyIncome > 0 ? (totalDebt / monthlyIncome) * 100 : 0;

  // Savings Rate
  const savingsRate = monthlyIncome > 0 ? ((monthlyIncome - monthlyExpenses) / monthlyIncome) * 100 : 0;

  // Liquidity Ratio (cash and equivalents / monthly expenses)
  const liquidAssets = accounts
    .filter(a => a.type === 'checking' || a.type === 'savings')
    .reduce((sum, a) => sum + Number(a.balance), 0);

  const liquidityRatio = monthlyExpenses > 0 ? liquidAssets / monthlyExpenses : 0;

  // Financial Stress Index (composite score)
  let stressIndex = 0;
  if (debtToIncomeRatio > 36) stressIndex += 30;
  else if (debtToIncomeRatio > 28) stressIndex += 20;
  else if (debtToIncomeRatio > 20) stressIndex += 10;

  if (savingsRate < 10) stressIndex += 25;
  else if (savingsRate < 20) stressIndex += 15;

  if (liquidityRatio < 3) stressIndex += 25;
  else if (liquidityRatio < 6) stressIndex += 15;

  // Determine risk level
  let riskLevel: 'low' | 'medium' | 'high';
  if (stressIndex < 20) riskLevel = 'low';
  else if (stressIndex < 40) riskLevel = 'medium';
  else riskLevel = 'high';

  // Generate recommendations
  const recommendations: string[] = [];

  if (debtToIncomeRatio > 36) {
    recommendations.push('Your debt-to-income ratio is high. Consider debt consolidation or increasing income.');
  }

  if (savingsRate < 20) {
    recommendations.push('Aim to save at least 20% of your income for better financial security.');
  }

  if (liquidityRatio < 3) {
    recommendations.push('Build an emergency fund covering at least 3 months of expenses.');
  }

  if (stressIndex > 40) {
    recommendations.push('Consider consulting a financial advisor for personalized guidance.');
  }

  return {
    debtToIncomeRatio: Math.round(debtToIncomeRatio * 100) / 100,
    savingsRate: Math.round(savingsRate * 100) / 100,
    liquidityRatio: Math.round(liquidityRatio * 100) / 100,
    financialStressIndex: Math.round(stressIndex * 100) / 100,
    riskLevel,
    recommendations,
  };
}
