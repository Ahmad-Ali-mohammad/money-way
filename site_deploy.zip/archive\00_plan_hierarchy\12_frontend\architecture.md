معمارية الواجهة المقترحة

التقنيات الأساسية:
- Framework: React (المرئي الحالي يستخدم Vite)
- State: React Context + useReducer أو Zustand للـ global state، React Query / TanStack Query للـ server state
- Styling: Tailwind CSS (مذكور في repo)، مع دعم RTL باستخدام `tailwindcss-rtl` أو إعدادات مخصصة
- Bundling & Dev: Vite (حاليًا موجود)
- Testing: Jest + React Testing Library، E2E: Playwright أو Cypress
- i18n: react-i18next أو formatjs لدعم تعدد اللهجات واللغات

هيكل الملفات المقترح (مبدئي):
- src/
  - components/  (قابلة لإعادة الاستخدام)
  - features/    (مثل transactions/, accounts/, auth/)
  - pages/       (Routes mapped components)
  - services/    (API clients)
  - hooks/       (custom hooks)
  - styles/      (design tokens و utilities)
  - i18n/        (ترجمات)

CI/CD:
- على كل PR: lint + unit tests + storybook build (إن وُجد)
- على merge إلى main: build + deploy to staging

Accessibility & Performance:
- التحقق من WCAG لواجهات رئيسية
- استخدام lazy loading و code-splitting للصفحات الثقيلة
- إعداد image optimization و caching