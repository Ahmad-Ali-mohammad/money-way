---
description: how to run the Money Way application
---
# Running the Money Way Application

To start both the backend and frontend of the application, follow these steps:

1. Open a terminal in the project root.
2. Run the following command:
// turbo
```powershell
./Run_MoneyWay.bat
```
Alternatively, you can just double-click the `Run_MoneyWay.bat` file in your file explorer.
