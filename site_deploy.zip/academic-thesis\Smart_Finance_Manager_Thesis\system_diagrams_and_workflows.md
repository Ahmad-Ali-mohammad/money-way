# مخططات النظام، نمذجة، وسير العمل — Smart Finance Manager

> هذا الملف يجمع مخططات هندسية شاملة للمشروع: سياق النظام، مكونات معمارية، نشر، مخططات استخدام، وسير العمل لكل صفحة (UI flows) مع أمثلة Mermaid/PlantUML قابلة للترجمة إلى صور.

---

## فهرس المخططات
1. ملخّص السياق (System Context Diagram)
2. مخطط المكوّنات (Component Diagram)
3. مخطّط النشر (Deployment Diagram)
4. ERD (مرجع سريع)
5. مخطّط حالات الاستخدام (Use Case Diagram)
6. سير العمل/تدفق الواجهات لكل صفحة (UI flows)
7. مخططات تسلسلية رئيسية (Sequence Diagrams)
8. نشاط المعالجة الدورية (Activity Diagram)
9. مخطط DFD لبيانات تدفق النظام
10. مخطط CICD، مراقبة، وسجلات
11. ملاحظات أمنية على المخططات

---

## 1) System Context (Mermaid)

```mermaid
flowchart LR
  User["User (Mobile/Web)"] -->|Uses| Frontend["Frontend (React SPA)"]
  Frontend -->|API calls (REST/JSON)| Backend["Backend API (Node/Express)"]
  Backend -->|Reads/Writes| DB[("Database (Postgres)")]
  Backend -->|Stores files| Storage[("Object Storage / S3")]
  Backend -->|Sends| NotificationSvc[("Notification Service (Push/Email)")]
  ExternalAPI[("External Services (Exchange rates, Banks)")] -->|Optional| Backend

  style User fill:#f9f,stroke:#333
  style Frontend fill:#ccf,stroke:#333
  style Backend fill:#cfc,stroke:#333
```

**ملاحظات:** يبيّن هذا الرسم الحدود الأساسية للنظام والاعتمادات على خدمات خارجية.

---

## 2) Component Diagram (PlantUML - مرجع)

- الملف المرجعي: `academic-thesis/Smart_Finance_Manager_Thesis/uml_component.puml`

محتوى نموذجي (PlantUML):

```
@startuml
package "Frontend" {
  component "React SPA" as SPA
}
package "Backend" {
  component "Auth Service" as Auth
  component "Transactions Service" as Tx
  component "Budget Service" as Bud
  component "Reports Service" as Rep
  component "Scheduler" as Sched
}
component "Postgres" as DB
component "Object Storage" as S3
SPA --> Auth : login / token
SPA --> Tx : /api/transactions
Tx --> DB : CRUD
Sched --> Tx : create recurring entries
@enduml
```

> يمكنك تحويل الملف أعلاه إلى `.png` باستخدام PlantUML CLI أو عبر VSCode PlantUML extension.

---

## 3) Deployment Diagram (Mermaid)

```mermaid
graph TD
  subgraph Cloud
    LB["Load Balancer"]
    subgraph AppNodes
      BE1["Backend (Node) - instance 1"]
      BE2["Backend (Node) - instance 2"]
    end
    DB["Postgres (Managed)"]
    Storage["S3 / Object Storage"]
  end
  User --> LB --> BE1
  LB --> BE2
  BE1 --> DB
  BE1 --> Storage
  BE2 --> DB
  BE2 --> Storage
```

**مواصفات نشر موصى بها:** auto-scaling للـ backend، use managed Postgres، استخدام CDN للواجهة.

---

## 4) ERD (مرجع سريع)
- راجع الملف `erd_database.md` المفصل. (مرمز كـ Mermaid وبه جداول وحقول وفهارس مقترحة.)

---

## 5) Use Case Diagram (Mermaid)

```mermaid
usecaseDiagram
  actor User
  User --> (Register)
  User --> (Login)
  User --> (Add Transaction)
  User --> (Create Budget)
  User --> (Create Goal)
  User --> (View Dashboard)
  User --> (Upload Receipt)
  User --> (Configure Alerts)
```

**ملاحظات:** يمكن إضافة أدوار إضافية مثل Admin أو Integrator (for bank integration).

---

## 6) UI Flows per Page (تفصيلي)

لكل صفحة أدناه: وصف الهدف، عناصر رئيسية، نقاط النهاية (Endpoints) المتوقعة، وسير العمل.

### Landing Page
- Goal: عرض القيمة المقترحة، روابط تسجيل/تسجيل دخول.
- UI: CTA (Signup/Login), feature highlights, screenshots.
- API: none (static)
- Flow (Mermaid):

```mermaid
flowchart TD
  A[Landing] --> B{User Action}
  B -->|Login| Login
  B -->|Signup| Signup
  B -->|Explore| Features
```

---

### Login / Register
- Goal: Authenticate and create account.
- UI fields: email, password, password confirmation, TOS checkbox.
- Endpoints:
  - POST /api/auth/register
  - POST /api/auth/login
  - POST /api/auth/refresh
- Flow (Sequence simplified):

```mermaid
sequenceDiagram
  participant U as User
  participant F as Frontend
  participant B as Backend
  U->>F: fill creds
  F->>B: POST /api/auth/login
  B-->>F: {accessToken, refreshToken}
  F-->>U: redirect Dashboard
```

**Errors:** invalid creds -> show inline error; locked account -> show retry/instructions.

---

### Dashboard
- Goal: Overview: balances, recent transactions, spending trends, quick actions.
- Components: balances widget, chart (series), recent tx table, notify alerts.
- Endpoints:
  - GET /api/dashboard/overview
  - GET /api/transactions?limit=20
- Flow (Mermaid):

```mermaid
flowchart LR
  Dashboard --> Widgets
  Widgets --> API[GET /api/dashboard/overview]
  Widgets --> Chart[GET /api/reports/spending]
```

---

### Transactions Page
- Goal: CRUD transactions, filters, tags, receipts.
- Key endpoints:
  - GET /api/transactions
  - POST /api/transactions
  - PUT /api/transactions/:id
  - DELETE /api/transactions/:id
  - POST /api/transactions/:id/receipt
- Flow (Sequence add transaction):

```mermaid
sequenceDiagram
  User->>UI: Add Transaction form
  UI->>API: POST /api/transactions
  API->>DB: insert transaction
  API-->>UI: 201 Created
  UI-->>User: show success, update balance
```

**Edge cases:** invalid account balance, negative amounts, validation errors.

---

### Budgets Page
- Goal: Create budgets by category, view spent/available.
- Endpoints:
  - POST /api/budgets
  - GET /api/budgets?userId=:id
- Flow: create -> calculate spent via query -> schedule alerts.

---

### Goals Page
- Goal: set savings goals, contribute to goal.
- Endpoints: POST/GET on /api/goals and /api/goals/:id/contribute

---

### Alerts, Receipts, Settings, Reports
- Alerts: GET /api/alerts, PATCH /api/alerts/:id/read
- Receipts: GET/POST /api/receipts (upload files to storage + store path)
- Settings/Profile: GET/PUT /api/users/:id
- Reports: GET /api/reports/spending?from=&to=

---

## 7) Sequence Diagrams (Key Scenarios)

### 7.1 Login (already above)

### 7.2 Add Transaction
(covered in Transactions section sequence diagram)

### 7.3 Transfer Between Accounts

```mermaid
sequenceDiagram
  User->>UI: Fill transfer (from, to, amount)
  UI->>API: POST /api/transactions {type: 'transfer', from, to, amount}
  API->>DB: Begin TX
  API->>DB: decrement fromAccount
  API->>DB: increment toAccount
  API->>DB: commit
  API-->>UI: 201 Created
```

### 7.4 Recurring Transaction Processing (Scheduler)

```mermaid
sequenceDiagram
  Scheduler->>API: GET /api/transactions/recurring/due
  API->>DB: select recurring rows
  API-->>Scheduler: list
  Scheduler->>API: POST /api/transactions (create instances)
```

---

## 8) Activity Diagram: Recurring Transaction Worker

```mermaid
stateDiagram-v2
  [*] --> CheckRecurring
  CheckRecurring --> ForEach{hasDue}
  ForEach --> CreateInstance: create transaction
  CreateInstance --> UpdateNextOccurrence
  UpdateNextOccurrence --> [*]
```

---

## 9) Data Flow Diagram (DFD Level 1)

```mermaid
flowchart TD
  User --> Frontend
  Frontend --> Backend
  Backend --> DB
  Backend --> Storage
  Backend --> ExternalAPI
  Backend --> Notification
```

---

## 10) CI/CD & Monitoring
- CI Steps: lint -> tests -> build -> SAST (Codacy) -> package
- CD: deploy to staging -> run migrations -> smoke tests -> promote to prod
- Observability: metrics (Prometheus), logs (ELK or Grafana Loki), tracing (Jaeger)

Mermaid pipeline snippet:

```mermaid
flowchart TD
  Repo --> CI["CI (GitHub Actions)"]
  CI --> Tests
  Tests --> SAST
  SAST --> Build
  Build --> Deploy["Deploy (staging/prod)"]
```

---

## 11) Security annotations on diagrams
- All API calls require TLS; tokens via Authorization header; critical endpoints rate-limited.
- Sensitive operations (withdrawals, transfers) require additional checks (2FA or confirmation).

---

## 12) ملاحق وملفات PlantUML/Mermaid
- PlantUML sources:
  - `uml_class.puml` — نموذج الكائنات/الكلاس
  - `uml_component.puml` — مكونات النظام
  - `sequence_add_transaction.puml` — سيناريو إضافة معاملة
  - `sequence_budget_alert.puml` — تنبيهات تجاوز الميزانية
  - `uml_threat_model.puml` — مخطط تهديد الاستراتيجية
- Mermaid snippets مضمنة أعلاه قابلة للعرض مباشرة في ملفات Markdown مدعومة.

---

## 13) تعليمات تحويل المخططات إلى صور ودمجها
- Mermaid → استخدم `mmdc` (mermaid-cli) أو محرّكات تحويل داخل VSCode.
- PlantUML → استخدم Plugin VSCode PlantUML أو `plantuml.jar` (requires Graphviz) لتصدير PNG/SVG.
- عند رغبتك، أستطيع توليد الصور وإدخالها داخل الملفات Markdown تلقائيًا.

---

## 14) عمل إضافي مقترح
- توليد صور PNG لكل PlantUML ودمجها داخل `diagrams/` في الأطروحة.
- توليد PDF شامل للمخططات مع تسميات ومخططات قابلة للطباعة.


---

هل أبدأ الآن بتوليد صور PNG لكل ملفات PlantUML وضمّها داخل المجلد `diagrams/` وإدراج الصور داخل هذا الملف؟ (أجب: نعم/لا)