import { Router } from 'express';
import { authenticate } from '../middleware/authMiddleware';
import { getDashboardOverview, getDashboardStats } from '../controllers/dashboardController';

const router = Router();

router.use(authenticate);
router.get('/', getDashboardOverview);
router.get('/overview', getDashboardOverview); // Same endpoint, two paths
router.get('/stats', getDashboardStats);

export default router;
