هيكل المسارات المقترح

- / (Dashboard) — `DashboardPage`
- /auth/login — `LoginForm`
- /auth/register — `RegistrationForm`
- /accounts — `AccountList`
- /accounts/:id — `AccountDetail` (مع معاملات الحساب)
- /transactions — `TransactionList`
- /transactions/new — `TransactionForm`
- /budgets — `BudgetsPage`
- /goals — `GoalsPage`
- /reports — `ReportsPage`
- /settings — `SettingsPage`

ملاحظات:
- حماية المسارات الحساسة عبر الـ route guards (auth checks)
- دعم deep-linking للمعاملات والتقارير المفصّلة