$loginData = @{ email = 'ahmed@example.com'; password = 'password123' } | ConvertTo-Json
$login = Invoke-RestMethod -Uri 'http://localhost:4000/api/auth/login' -Method Post -Body $loginData -ContentType 'application/json'
Write-Host 'TOKEN:' $login.token
$headers = @{ Authorization = "Bearer $($login.token)" }
$stats = Invoke-RestMethod -Uri 'http://localhost:4000/api/dashboard/stats?period=month' -Method Get -Headers $headers
Write-Host 'STATS:'
$stats | ConvertTo-Json -Depth 5
$analysisData = @{ name = 'Smoke Project'; initialInvestment = 10000; monthlyRevenue = 2000; monthlyExpenses = 1000 } | ConvertTo-Json
$analysis = Invoke-RestMethod -Uri 'http://localhost:4000/api/projects/analyze' -Method Post -Headers @{ Authorization = "Bearer $($login.token)"; 'Content-Type' = 'application/json' } -Body $analysisData
Write-Host 'ANALYSIS:'
$analysis | ConvertTo-Json -Depth 5

# Check currencies endpoint
$currencies = Invoke-RestMethod -Uri 'http://localhost:4000/api/currencies' -Method Get
Write-Host 'CURRENCIES COUNT:' $($currencies.length)

# Check alerts and mark one as read
$alerts = Invoke-RestMethod -Uri 'http://localhost:4000/api/alerts' -Method Get -Headers $headers
Write-Host 'ALERTS COUNT:' $($alerts.length)
if ($alerts.length -gt 0) {
    $first = $alerts[0]
    Write-Host 'First alert id:' $first.id
    $res = Invoke-RestMethod -Uri "http://localhost:4000/api/alerts/$($first.id)/read" -Method Patch -Headers $headers
    Write-Host 'Marked as read response:'; $res | ConvertTo-Json -Depth 3
}
