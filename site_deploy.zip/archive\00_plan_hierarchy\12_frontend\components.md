قائمة المكونات الأساسية المقترحة

1) Layout
- `MainLayout` — شريط جانبي، ترويسة، منطقة المحتوى. مسؤول عن الـ navigation وrtl handling.

2) Auth
- `RegistrationForm` — حقول التسجيل، اختيار نمط الدخل، أسئلة مبدئية.
- `LoginForm` — بريد + كلمة مرور، forgot password.

3) Accounts & Balances
- `AccountList` — عرض الحسابات وأرصدتها.
- `AccountCard` — بطاقة حساب فردي مع عمليات سريعة (إضافة معاملة).

4) Transactions
- `TransactionForm` — نموذج إدخال معاملة سريع ودقيق (يدعم الإيصالات والوسوم)
- `TransactionList` — قائمة قابلة للفلترة والبحث
- `TransactionItem` — سطر عرض مع تفاصيل وسهولة تحرير

5) Budgets & Goals
- `BudgetEditor` — إنشاء/تعديل الميزانية الذكية
- `GoalProgress` — شريط تقدم للأهداف

6) Reports & Dashboard
- `DashboardPage` — ملخصات، رسومات بيانية (charts)
- `ReportsPage` — إنشاء وتنزيل تقارير

7) Alerts & Notifications
- `AlertsCenter` — قائمة التنبيهات، فلترة بحسب الأهمية

8) Shared
- `Modal`, `Button`, `Input`, `Select`, `Table`, `Tag`, `Avatar`

مواصفات قصيرة لكل مكوّن (props, events) مذكورة ضمن ملف مكوّن منفصل في عميل التنفيذ عند بدء البرمجة.