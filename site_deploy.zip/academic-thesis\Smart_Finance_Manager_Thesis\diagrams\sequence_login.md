# مخطط تسلسل: تسجيل الدخول (Login)

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant AuthAPI

    User->>Frontend: يرسل بيانات تسجيل الدخول (email, password)
    Frontend->>AuthAPI: POST /api/auth/login
    AuthAPI->>AuthAPI:ตรวจสอบ كلمة المرور وIssue JWT
    AuthAPI-->>Frontend: 200 OK + { token }
    Frontend-->>User: يخزن التوكن ويعيد توجيه إلى Dashboard
```
