# توثيق المخططات والتحليل الهندسي للنظام (Comprehensive Engineering Diagrams)

يوفر هذا الملحق نظرة هندسية شاملة على بنية نظام "مدير المال الذكي"، متضمناً مخططات نمذجة البيانات، وسير العمل، والتحليل السلوكي للأنظمة الفرعية.

## 1. مخطط حالات الاستخدام الشامل (Comprehensive Use Case Diagram)

يصف هذا المخطط كافة التفاعلات الممكنة للمستخدم مع ميزات النظام المختلفة.

```mermaid
useCaseDiagram
    actor "المستخدم المسجل" as User
    
    package "نظام الهوية والأمان" {
        usecase "UC1: إنشاء حساب" as Register
        usecase "UC2: تسجيل الدخول" as Login
        usecase "UC3: إدارة الملف الشخصي" as Profile
    }

    package "إدارة المال الأساسية" {
        usecase "UC4: إدارة الحسابات المالية" as Acc
        usecase "UC5: إضافة/تعديل المعاملات" as Trans
        usecase "UC6: التحويل بين الحسابات" as Transfer
    }

    package "الذكاء المالي والتخطيط" {
        usecase "UC7: إعداد ميزانية تكيفية" as Budget
        usecase "UC8: متابعة الأهداف المالية" as Goal
        usecase "UC9: إدارة المشاريع الاستثمارية" as Project
    }

    package "التقارير والتنبيهات" {
        usecase "UC10: استعراض التقارير الذكية" as Report
        usecase "UC11: إدارة التنبيهات" as Alert
        usecase "UC12: رفع وأرشفة الإيصالات" as Receipt
    }

    User --> Register
    User --> Login
    User --> Profile
    User --> Acc
    User --> Trans
    User --> Transfer
    User --> Budget
    User --> Goal
    User --> Project
    User --> Report
    User --> Alert
    User --> Receipt
```

## 2. المخطط العلائقي لقاعدة البيانات (Entity Relationship Diagram - ERD)

يعكس هذا المخطط البنية الفعلية لجداول قاعدة البيانات والعلاقات بينها كما هي محددة في ملف `schema.prisma`.

```mermaid
erDiagram
    USER ||--o{ ACCOUNT : "owns"
    USER ||--o{ TRANSACTION : "records"
    USER ||--o{ CATEGORY : "defines"
    USER ||--o{ BUDGET : "sets"
    USER ||--o{ GOAL : "pursues"
    USER ||--o{ PROJECT : "manages"
    USER ||--o{ ALERT : "receives"
    USER ||--o{ TAG : "creates"
    USER ||--o{ RECEIPT : "uploads"

    ACCOUNT ||--o{ TRANSACTION : "source/destination"
    CATEGORY ||--o{ TRANSACTION : "classifies"
    CATEGORY ||--o{ BUDGET : "limits"
    
    TRANSACTION ||--o{ TRANSACTION_TAG : "has"
    TAG ||--o{ TRANSACTION_TAG : "linked to"
    GOAL ||--o{ GOAL_TRANSACTION : "tracked by"

    USER {
        int id PK
        string email UK
        string passwordHash
        string currency
        string incomePattern
        datetime createdAt
    }

    ACCOUNT {
        int id PK
        int userId FK
        string name
        string type
        float balance
        string currency
    }

    TRANSACTION {
        int id PK
        int userId FK
        int accountId FK
        float amount
        string type
        int categoryId FK
        boolean isRecurring
        datetime occurredAt
    }

    BUDGET {
        int id PK
        int userId FK
        int categoryId FK
        string name
        float amount
        float spent
        boolean isAdaptive
    }

    GOAL {
        int id PK
        int userId FK
        string name
        float targetAmount
        float currentAmount
        datetime deadline
    }

    PROJECT {
        int id PK
        int userId FK
        string name
        float initialInvestment
        float monthlyRevenue
        string status
    }
```

## 3. خريطة الموقع والتدفق الملاحي (Site Map & Navigation Flow)

يوضح هذا المخطط كيفية تنقل المستخدم بين صفحات النظام المختلفة والترابط المنطقي بينها.

```mermaid
graph LR
    Start((البداية)) --> Landing[صفحة الهبوط]
    Landing --> Login{تسجيل الدخول}
    Login -- فشل --> Login
    Login -- نجاح --> Dashboard[لوحة التحكم Dashboard]

    subgraph "النظام الأساسي"
        Dashboard --> Accounts[إدارة الحسابات]
        Dashboard --> Transactions[سجل المعاملات]
        Dashboard --> Reports[التقارير المالية]
    }

    subgraph "التخطيط المالي"
        Dashboard --> Budgets[الميزانيات الذكية]
        Dashboard --> Goals[الأهداف المالية]
        Dashboard --> Projects[المشاريع الاستثمارية]
    }

    subgraph "الإعدادات"
        Dashboard --> Profile[الملف الشخصي]
        Dashboard --> Tags[إدارة الوسوم]
        Dashboard --> Alerts[مركز التنبيهات]
    }
```

## 4. مخططات سير العمل (Activity Diagrams)

### 4.1 دورة حياة المعاملة المالية (Transaction Lifecycle)

يوضح المخطط العمليات البرمجية التي تتم عند إضافة معاملة جديدة (دخل أو مصروف).

```mermaid
stateDiagram-v2
    [*] --> InputData: إدخال البيانات (المبلغ، الحساب، التصنيف)
    InputData --> Validation: التحقق من صحة المدخلات (Zod)
    
    state Validation {
        [*] --> CheckAmount: هل المبلغ موجب؟
        CheckAmount --> CheckAccount: هل الحساب موجود؟
        CheckAccount --> [*]
    }
    
    Validation --> DatabaseTransaction: بدء عملية ذرية (Prisma Transaction)
    DatabaseTransaction --> UpdateAccount: تحديث رصيد الحساب المرتبط
    UpdateAccount --> CreateRecord: إنشاء سجل المعاملة الجديد
    CreateRecord --> CheckBudget: هل المعاملة تتبع لميزانية مفعلة؟
    
    CheckBudget --> UpdateBudgetSpent: تحديث حقل "المصروف" في الميزانية
    UpdateBudgetSpent --> ThresholdCheck: هل تجاوز الصرف 80% أو 100%؟
    
    ThresholdCheck --> CreateAlert: توليد تنبيه للمستخدم (إن لزم)
    CreateAlert --> Commit: تثبيت التغييرات (Commit)
    
    CheckBudget --> Commit: (في حال لا توجد ميزانية)
    
    Commit --> RefreshUI: تحديث واجهة React (React Query)
    RefreshUI --> [*]: انتهاء العملية
```

### 4.2 محرك الميزانية التكيفي (Adaptive Budget Engine Workflow)

يوضح كيفية عمل النظام في الخلفية لتعديل الميزانيات تلقائياً.

```mermaid
graph TD
    A[بداية الشهر المالي] --> B[جمع بيانات الدخل لآخر 3 أشهر]
    B --> C[حساب متوسط الدخل الحقيقي]
    C --> D{هل الميزانية تكيفية؟}
    D -- لا --> E[البقاء على القيمة اليدوية]
    D -- نعم --> F[تطبيق نسبة الميزانية من المتوسط]
    F --> G[مقارنة القيمة الجديدة بالحدود الدنيا والقصوى]
    G --> H[تحديث جدول Budgets]
    H --> I[إرسال تنبيه للمستخدم بالتعديل الحاصل]
    E --> J[نهاية]
    I --> J
```

## 5. معمارية النظام التقنية (System Architecture Diagram)

يوضح هذا المخطط المكونات البرمجية والربط الفيزيائي والمنطقي بينها.

```mermaid
graph TD
    subgraph "Client Side (Frontend - React)"
        UI[User Interface Components]
        Stores[State Management - Context API]
        Charts[Data Visualization - Recharts]
        Axios[API Client]
    end

    subgraph "Server Side (Backend - Node.js)"
        Routes[Express Routes]
        Middleware[Auth & Validation Middleware]
        Services[Business Logic & AI Engines]
        Prisma[Prisma Client ORM]
    end

    subgraph "Data Storage"
        DB[(PostgreSQL Database)]
        ENV[Environment Variables]
    end

    Axios <-->|HTTP/REST + JWT| Routes
    Routes --> Middleware
    Middleware --> Services
    Services --> Prisma
    Prisma <--> DB
    ENV --> Services
```
