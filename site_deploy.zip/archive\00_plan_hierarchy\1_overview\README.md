قسم 1 — نظرة عامة شاملة على المشروع

ملفات في هذا المجلد:
- 1.1_vision_and_mission.md
- 1.2_problem_and_solution.md
- 1.3_target_groups.md