# لقطات واجهة المستخدم (UI Screenshots)

> ضع هنا لقطات الشاشة الفعلية عند التقاطها من البيئة المحلية.

- Landing Page: `diagrams/screenshots/landing.png`
- Login Page: `diagrams/screenshots/login.png`
- Dashboard: `diagrams/screenshots/dashboard.png`
- Add Transaction: `diagrams/screenshots/add_transaction.png`

**تعليمات**:
1. شغّل الواجهة (`cd frontend && npm run dev`).
2. افتح كل صفحة والتقط لقطة شاشة (Windows: Snipping Tool أو Win+Shift+S).
3. احفظ الملفات داخل `academic-thesis/Smart_Finance_Manager_Thesis/diagrams/screenshots/`.
4. حرر هذا الملف وأضف الصور بالمسار أعلاه.
