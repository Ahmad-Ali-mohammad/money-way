# مخطط العلاقات (ERD)

```mermaid
erDiagram
    USERS ||--o{ ACCOUNTS : owns
    USERS ||--o{ CATEGORIES : creates
    USERS ||--o{ TRANSACTIONS : performs
    USERS ||--o{ TAGS : defines
    USERS ||--o{ BUDGETS : defines
    USERS ||--o{ GOALS : creates
    USERS ||--o{ PROJECTS : manages
    USERS ||--o{ ALERTS : receives
    USERS ||--o{ RECEIPTS : uploads

    ACCOUNTS ||--o{ TRANSACTIONS : "from/to"
    CATEGORIES ||--o{ TRANSACTIONS : categorizes
    TRANSACTIONS ||--o{ TRANSACTION_TAGS : has
    TAGS ||--o{ TRANSACTION_TAGS : tag_for
    BUDGETS }o--|| CATEGORIES : "optional for"
    GOALS ||--o{ GOAL_TRANSACTIONS : records

    %% Attributes (partial)
    USERS {
      int id PK
      string email
      string password_hash
      string name
      datetime created_at
    }
    ACCOUNTS {
      int id PK
      int user_id FK
      string name
      float balance
    }
    TRANSACTIONS {
      int id PK
      int user_id FK
      int account_id FK
      float amount
      datetime occurred_at
    }
```

> ملاحظة: تم استخراج المخطط من ملف `backend/prisma/schema.prisma` وتضمينه هنا لتسهيل توليد مخططات ERD أكثر تفصيلاً باستخدام أدوات مثل dbdiagram أو draw.io.
