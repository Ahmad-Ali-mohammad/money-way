import { Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import {
  getAllReceipts,
  getReceiptById,
  createReceipt,
  updateReceipt,
  deleteReceipt,
} from '../controllers/receiptController';

const router = Router();

// All routes require authentication
router.use(authMiddleware);

router.get('/', getAllReceipts);
router.get('/:id', getReceiptById);
router.post('/', createReceipt);
router.put('/:id', updateReceipt);
router.delete('/:id', deleteReceipt);

export default router;
