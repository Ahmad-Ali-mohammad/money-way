import { Router } from 'express';
import {
  getAllTags,
  createTag,
  updateTag,
  deleteTag,
  addTagToTransaction,
  removeTagFromTransaction,
} from '../controllers/tagController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.use(authMiddleware);

router.get('/', getAllTags);
router.post('/', createTag);
router.put('/:id', updateTag);
router.delete('/:id', deleteTag);
router.post('/link', addTagToTransaction);
router.delete('/link/:transactionId/:tagId', removeTagFromTransaction);

export default router;
