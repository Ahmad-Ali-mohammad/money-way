import { Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import {
  getSupportedCurrencies,
  getUserCurrency,
  setUserCurrency,
  convertCurrency,
} from '../controllers/currencyController';

const router = Router();

// Public routes - get supported currencies
router.get('/', getSupportedCurrencies);
router.get('/supported', getSupportedCurrencies);

// Protected routes - require authentication
router.use(authMiddleware);

router.get('/user', getUserCurrency);
router.put('/user', setUserCurrency);
router.get('/convert', convertCurrency);

export default router;
