# 💰 مدير المال الذكي - Smart Finance Manager

نظام متكامل لإدارة الأموال الشخصية مع تحليلات ذكية وتنبيهات استباقية

## ✨ المميزات الرئيسية

### 🎨 التصميم
- تصميم عصري بتقنية **Glassmorphism** (الزجاج الشفاف)
- واجهة مستخدم احترافية وسهلة الاستخدام
- تصميم متجاوب يعمل على جميع الأجهزة
- تأثيرات حركية سلسة وجذابة
- دعم كامل للغة العربية (RTL)

### 💼 الوظائف الأساسية
- ✅ إدارة الحسابات المالية المتعددة
- ✅ تتبع المعاملات (دخل / مصروفات)
- ✅ إنشاء وإدارة الميزانيات
- ✅ تحديد الأهداف المالية ومتابعتها
- ✅ تقارير وتحليلات تفاعلية
- ✅ تنبيهات ذكية واستباقية
- ✅ إدارة الفئات والعلامات
- ✅ نظام مشاريع متقدم

## 🚀 التقنيات المستخدمة

### Frontend
- **React 18** - مكتبة بناء واجهات المستخدم
- **TypeScript** - للكتابة الآمنة والمنظمة
- **React Router** - للتنقل بين الصفحات
- **Tailwind CSS** - لتصميم واجهة المستخدم
- **Vite** - أداة البناء السريعة

### Backend
- **Node.js** - بيئة تشغيل JavaScript
- **Express.js** - إطار عمل الخادم
- **TypeScript** - للكتابة الآمنة
- **Prisma** - ORM للتعامل مع قاعدة البيانات
- **PostgreSQL** - قاعدة البيانات الرئيسية
- **JWT** - نظام المصادقة

## 📁 هيكل المشروع

```
باك جاهز/
├── frontend/                 # تطبيق React
│   ├── src/
│   │   ├── components/      # المكونات المشتركة
│   │   ├── contexts/        # Context API للحالة العامة
│   │   ├── pages/          # صفحات التطبيق
│   │   ├── services/       # خدمات API
│   │   ├── App.tsx         # المكون الرئيسي
│   │   └── index.css       # الأنماط العامة
│   ├── index.html
│   └── package.json
│
├── backend/                 # خادم Node.js
│   ├── src/
│   │   ├── controllers/    # معالجات الطلبات
│   │   ├── middleware/     # الوسائط
│   │   ├── routes/         # المسارات
│   │   ├── services/       # خدمات الأعمال
│   │   └── index.ts        # نقطة الدخول
│   ├── prisma/
│   │   └── schema.prisma   # مخطط قاعدة البيانات
│   └── package.json
│
└── 00_plan_hierarchy/      # الوثائق والتخطيط
```

## 🔧 التثبيت والإعداد

### المتطلبات
- Node.js (الإصدار 18 أو أحدث)
- PostgreSQL (الإصدار 14 أو أحدث)
- npm أو yarn

### 1. إعداد قاعدة البيانات

```bash
# إنشاء قاعدة بيانات PostgreSQL
createdb finance_manager
```

### 2. إعداد Backend

```bash
cd backend

# تثبيت المكتبات
npm install

# إنشاء ملف .env
cp .env.example .env

# تحديث ملف .env بمعلومات قاعدة البيانات
# DATABASE_URL="postgresql://user:password@localhost:5432/finance_manager"
# JWT_SECRET="your-secret-key"

# تطبيق الـ migrations
npx prisma migrate dev

# تشغيل الخادم
npm run dev
```

سيعمل الخادم على: `http://localhost:3000`

### 3. إعداد Frontend

```bash
cd frontend

# تثبيت المكتبات
npm install

# إنشاء ملف .env
# VITE_API_URL=http://localhost:3000/api

# تشغيل التطبيق
npm run dev
```

سيعمل التطبيق على: `http://localhost:5173`

## 📱 الصفحات الرئيسية

### 1. صفحة الهبوط (Landing Page)
- تصميم عصري جذاب
- عرض المميزات الرئيسية
- أزرار التسجيل وتسجيل الدخول
- إحصائيات المنصة

### 2. صفحة تسجيل الدخول (Login)
- تصميم Glassmorphism
- حقول البريد الإلكتروني وكلمة المرور
- خيار "تذكرني"
- رابط "نسيت كلمة المرور"
- خيار تسجيل الدخول عبر Google

### 3. صفحة التسجيل (Register)
- نموذج شامل للتسجيل
- التحقق من صحة البيانات
- شروط الاستخدام والخصوصية
- خيار التسجيل عبر Google

### 4. لوحة التحكم (Dashboard)
- نظرة عامة على الحالة المالية
- إحصائيات الدخل والمصروفات
- الرصيد الإجمالي
- آخر المعاملات
- إجراءات سريعة

## 🎨 التصميم والأنماط

### Glassmorphism Design
استخدمنا تقنية الزجاج الشفاف لإنشاء واجهة عصرية:
- خلفية شفافة مع blur effect
- حدود شفافة
- ظلال ناعمة
- تأثيرات hover جذابة

### الألوان
- **Primary**: من البنفسجي إلى الزهري (Purple to Pink Gradient)
- **Background**: تدرج من البنفسجي الداكن إلى الأزرق النيلي
- **Accent**: وردي وأزرق فاتح
- **Text**: أبيض مع شفافية متدرجة

### الرسوم المتحركة
- `fade-in`: ظهور تدريجي
- `slide-up`: انزلاق من الأسفل
- `float-animation`: حركة طفو للعناصر الخلفية
- `hover-lift`: رفع العنصر عند التمرير

## 🔐 الأمان

- تشفير كلمات المرور باستخدام bcrypt
- مصادقة JWT للجلسات
- حماية CORS
- التحقق من صحة البيانات
- حماية من XSS و SQL Injection

## 📊 API Endpoints

### Authentication
- `POST /api/auth/register` - تسجيل مستخدم جديد
- `POST /api/auth/login` - تسجيل الدخول
- `GET /api/auth/profile` - الحصول على بيانات المستخدم

### Dashboard
- `GET /api/dashboard/overview` - نظرة عامة
- `GET /api/dashboard/stats` - إحصائيات

### Transactions
- `GET /api/transactions` - قائمة المعاملات
- `POST /api/transactions` - إضافة معاملة
- `PUT /api/transactions/:id` - تحديث معاملة
- `DELETE /api/transactions/:id` - حذف معاملة

### Accounts
- `GET /api/accounts` - قائمة الحسابات
- `POST /api/accounts` - إضافة حساب
- `PUT /api/accounts/:id` - تحديث حساب

### Budgets
- `GET /api/budgets` - قائمة الميزانيات
- `POST /api/budgets` - إنشاء ميزانية
- `PUT /api/budgets/:id` - تحديث ميزانية

### Goals
- `GET /api/goals` - قائمة الأهداف
- `POST /api/goals` - إنشاء هدف
- `PUT /api/goals/:id` - تحديث هدف

## 🌐 المتصفحات المدعومة

- Chrome (آخر إصدارين)
- Firefox (آخر إصدارين)
- Safari (آخر إصدارين)
- Edge (آخر إصدارين)

## 📝 الترخيص

هذا المشروع مرخص تحت MIT License

## 👨‍💻 المطورون

تم تطوير هذا المشروع بواسطة فريق مدير المال الذكي

## 📧 الدعم

لأي استفسارات أو مشاكل، يرجى التواصل عبر:
- البريد الإلكتروني: support@smartfinance.com
- GitHub Issues

## 🎯 خطط المستقبل

- [ ] تطبيق الهاتف المحمول (React Native)
- [ ] التكامل مع البنوك
- [ ] تقارير PDF
- [ ] نظام الفواتير
- [ ] الذكاء الاصطناعي للتوصيات
- [ ] دعم عملات متعددة
- [ ] نظام الإشعارات Push
- [ ] وضع Dark Mode
- [ ] التصدير والاستيراد

---

**صنع بـ ❤️ في 2026**
