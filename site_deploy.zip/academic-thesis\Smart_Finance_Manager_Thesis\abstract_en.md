# Abstract (English)

This project, "Smart Finance Manager", provides a comprehensive solution for personal financial management. The system helps users track income and expenses, create budgets, set financial goals, and receive smart visual analytics and proactive alerts. The application is built with React and TypeScript on the frontend, and Node.js, Express and Prisma (with SQLite during development and PostgreSQL in production) on the backend. The thesis documents the development methodology, system architecture, data models, sequence and use-case diagrams, testing strategy, and results. The conclusion discusses findings, challenges, and future work such as bank integration and a native mobile app.

---
