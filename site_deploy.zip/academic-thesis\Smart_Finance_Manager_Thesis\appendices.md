# الملحق (Appendices)

## A. مقتطفات من ملفات المشروع

### A.1 جزء من `backend/prisma/schema.prisma`
```prisma
model Transaction {
  id        Int    @id @default(autoincrement())
  userId    Int    @map("user_id")
  accountId Int    @map("account_id")
  amount    Float
  occurredAt DateTime @map("occurred_at")
}
```

### A.2 مثال على مسار API لإضافة معاملة
```
POST /api/transactions
Body: { accountId, amount, categoryId, occurredAt }
```

## B. ملف التهيئة وعمليات الـ Migration
- المجلد: `backend/prisma/migrations/`
- لتنفيذ migrations: `npm run prisma:migrate`

## C. كيفية توليد المخططات ولقطات الشاشة
1. شغّل الواجهة الأمامية `npm run dev` داخل `frontend` (عادة على http://localhost:5173)
2. افتح صفحات: Landing, Dashboard, Transactions
3. التقط لقطات شاشة (PNG) واحفظها داخل `academic-thesis/Smart_Finance_Manager_Thesis/diagrams/screenshots/`
4. أضف الصور في الملفات المناسبة باستخدام الصيغة:

```markdown
![Dashboard Screenshot](diagrams/screenshots/dashboard.png)
```

## D. تحويل ملفات Markdown إلى PDF
- استخدم `pandoc` أو أدوات مثل `mdBook`/`MkDocs` لتحويل المجلد إلى وثيقة PDF/HTML.
- مثال باستخدام `pandoc`:
```
pandoc chapter1_overview.md chapter2_theoretical.md chapter3_analysis_design.md \
  chapter4_testing_practical.md chapter5_results_future.md -o Thesis_SmartFinanceManager.pdf
```

---
