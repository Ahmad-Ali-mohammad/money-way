import { prisma } from '../src/lib/prisma';

(async () => {
  try {
    const result = await prisma.$transaction(async (tx) => {
      const created = await tx.goalTransaction.create({
        data: {
          goalId: 110,
          amount: 200,
          description: 'cli test',
          occurredAt: new Date(),
        },
      });

      await tx.goal.update({
        where: { id: 110 },
        data: { currentAmount: { increment: 200 } as any },
      });

      return created;
    });

    console.log('CREATED:', result);
  } catch (e) {
    console.error('ERROR in testGoalTx:', e);
    if (e instanceof Error && (e as any).stack) {
      console.error((e as any).stack);
    }
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
})();
