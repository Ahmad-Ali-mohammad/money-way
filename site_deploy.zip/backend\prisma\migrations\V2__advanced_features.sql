-- Migration: Add Tags Support and Adaptive Budget Features
-- Created: January 13, 2026

-- Add new columns to Budget table
ALTER TABLE budgets 
  ADD COLUMN category_id BIGINT REFERENCES categories(id) ON DELETE SET NULL,
  ADD COLUMN name VARCHAR(255) NOT NULL DEFAULT 'Unnamed Budget',
  ADD COLUMN amount DECIMAL(20, 4) NOT NULL DEFAULT 0,
  ADD COLUMN spent DECIMAL(20, 4) NOT NULL DEFAULT 0,
  ADD COLUMN start_date DATE,
  ADD COLUMN end_date DATE,
  ADD COLUMN is_adaptive BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN is_percentage BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN percentage DECIMAL(5, 2),
  ADD COLUMN adaptive_rule TEXT,
  ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  DROP COLUMN IF EXISTS rules;

-- Update Transaction table for recurring support
ALTER TABLE transactions
  ADD COLUMN next_occurrence TIMESTAMP,
  ADD COLUMN recurring_parent_id BIGINT REFERENCES transactions(id) ON DELETE SET NULL,
  DROP COLUMN IF EXISTS tags;

-- Create index for recurring transactions
CREATE INDEX IF NOT EXISTS idx_transactions_recurring ON transactions(is_recurring, next_occurrence);

-- Create Tags table
CREATE TABLE IF NOT EXISTS tags (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(50) NOT NULL,
  color VARCHAR(50),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT unique_user_tag UNIQUE(user_id, name)
);

-- Create TransactionTag junction table
CREATE TABLE IF NOT EXISTS transaction_tags (
  transaction_id BIGINT NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  tag_id BIGINT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (transaction_id, tag_id)
);

-- Update Project table structure
ALTER TABLE projects
  ADD COLUMN description TEXT,
  ADD COLUMN initial_investment DECIMAL(20, 4) NOT NULL DEFAULT 0,
  ADD COLUMN monthly_revenue DECIMAL(20, 4) NOT NULL DEFAULT 0,
  ADD COLUMN monthly_expenses DECIMAL(20, 4) NOT NULL DEFAULT 0,
  ADD COLUMN start_date DATE,
  ADD COLUMN end_date DATE,
  ADD COLUMN status VARCHAR(50) NOT NULL DEFAULT 'planning',
  ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  DROP COLUMN IF EXISTS type,
  DROP COLUMN IF EXISTS initial_cost,
  DROP COLUMN IF EXISTS expected_revenue;

-- Update Alert table
ALTER TABLE alerts
  ADD COLUMN message TEXT NOT NULL DEFAULT '',
  ADD COLUMN severity VARCHAR(20) NOT NULL DEFAULT 'medium',
  ADD COLUMN is_read BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN metadata JSON,
  DROP COLUMN IF EXISTS level,
  DROP COLUMN IF EXISTS payload,
  DROP COLUMN IF EXISTS sent_via,
  DROP COLUMN IF EXISTS read;

-- Rename column in alerts table
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'alerts' AND column_name = 'read') THEN
    ALTER TABLE alerts RENAME COLUMN read TO is_read;
  END IF;
END $$;

-- Create index for alerts
CREATE INDEX IF NOT EXISTS idx_alerts_user_read ON alerts(user_id, is_read);

-- Migrate existing tag data from JSON to separate table (if any exists)
-- This is a data migration script - adjust as needed
DO $$
DECLARE
  trans_record RECORD;
  tag_name TEXT;
  tag_id_var BIGINT;
BEGIN
  FOR trans_record IN SELECT id, user_id, tags FROM transactions WHERE tags IS NOT NULL AND tags::text != 'null'
  LOOP
    IF jsonb_typeof(trans_record.tags::jsonb) = 'array' THEN
      FOR tag_name IN SELECT jsonb_array_elements_text(trans_record.tags::jsonb)
      LOOP
        -- Insert or get tag
        INSERT INTO tags (user_id, name)
        VALUES (trans_record.user_id, tag_name)
        ON CONFLICT (user_id, name) DO NOTHING;
        
        -- Get tag id
        SELECT id INTO tag_id_var FROM tags WHERE user_id = trans_record.user_id AND name = tag_name;
        
        -- Link transaction to tag
        INSERT INTO transaction_tags (transaction_id, tag_id)
        VALUES (trans_record.id, tag_id_var)
        ON CONFLICT DO NOTHING;
      END LOOP;
    END IF;
  END LOOP;
END $$;

-- Add comment to tables
COMMENT ON TABLE tags IS 'User-defined tags for categorizing transactions';
COMMENT ON TABLE transaction_tags IS 'Many-to-many relationship between transactions and tags';
COMMENT ON COLUMN budgets.is_adaptive IS 'Whether the budget automatically adjusts based on income';
COMMENT ON COLUMN budgets.is_percentage IS 'Whether the budget amount is calculated as percentage of income';
COMMENT ON COLUMN transactions.next_occurrence IS 'Next scheduled date for recurring transactions';
COMMENT ON COLUMN transactions.recurring_parent_id IS 'Reference to the parent recurring transaction template';
