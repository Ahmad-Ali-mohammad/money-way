# ملحق: استعلامات SQL وPrisma وأمثلة تحسين الأداء (موسّع)

## نظرة عامة
يقدم هذا الملحق شرحًا عمليًا ومفصلاً لاستراتيجيات تحسين استعلامات قواعد البيانات، أمثلة SQL وPrisma لنماذج التقارير والتحليلات، نصائح للفهرسة، إدارة الأرشفة والنسخ الاحتياطي، وطرق لمراقبة أداء قواعد البيانات في بيئة الإنتاج.

> الهدف: تزويد الفريق بمرجع عملي لتسريع استعلامات التقارير، الحفاظ على استجابة خدمات الـ API، وتقليل تكلفة العمليات على DB مع الحفاظ على دقّة بيانات مالية حسّاسة.

---

## 1. نمذجة الأموال: Float vs Decimal vs Integer (Cents)

الاختيار الصحيح لنوع حقل المبلغ حاسم لحفظ الدقة:
- Float: عرضة لمشاكل الدقة العشرية عند العمليات الحسابية؛ غير موصى به للمبالغ المالية.
- Decimal / Numeric: مناسب للحسابات المالية، يسمح بتحديد الدقة (مثلاً NUMERIC(15,2)).
- Integer (cents): تخزين المبلغ كأصغر وحدة (مثل سنت) في `BIGINT` أو `INTEGER` يمنع أي مشاكل تقريب.

توصية عملية: استخدم `Decimal` أو تخزين القيم بوحدة أصغر (cents) واستخدام مكتبة `Decimal` في الطبقة التطبيقية. في Prisma يفضّل استخدام نوع `Decimal` للحقل وتمثيله بـ `Prisma.Decimal` في TypeScript.

---

## 2. الفهرسة (Indexing) — استراتيجيات متقدمة

### 2.1 فهارس أساسية
- فهارس على الحقول التالية: `user_id`, `occurred_at`, `category_id`, `account_id`.
- استخدام فهارس مركبة للاستعلامات المشتركة: `(user_id, occurred_at)` أو `(user_id, category_id, occurred_at)`.

SQL مثال:
```sql
CREATE INDEX idx_tx_user_occurred ON transactions (user_id, occurred_at DESC);
```

### 2.2 فهارس تغطية (Covering Indexes)
لتحسين استعلامات التجميع البسيطة، إنشاء فهرس يغطي الأعمدة المستخدمة في WHERE وSELECT يقلّل الوصول إلى الصفوف الفعلية.

```sql
CREATE INDEX idx_tx_user_category_amount ON transactions (user_id, category_id) INCLUDE (amount);
```
> *ملحوظة:* دعم INCLUDE يختلف بين قواعد البيانات (Postgres يدعمه في v11+).

### 2.3 فهارس جزئية (Partial Indexes)
إنشاء فهارس جزئية للصفوف النشطة فقط (مثلاً المعاملات خلال العام الأخير) يقلّل من حجم الفهرس:
```sql
CREATE INDEX idx_recent_tx_user ON transactions (user_id, occurred_at) WHERE occurred_at >= now() - interval '1 year';
```

### 2.4 فهارس نصية وGIN
للبحث في أسماء التجار أو الوصف استخدم `GIN` مع `to_tsvector`:
```sql
CREATE INDEX idx_transactions_merchant_search ON transactions USING GIN (to_tsvector('english', notes));
```

---

## 3. Partitioning (تقسيم الجداول)

تقسيم جدول `transactions` حسب `occurred_at` (range partitioning) يساعد على تحسين الأداء والاحتفاظ بالبيانات:

```sql
-- مثال PostgreSQL
CREATE TABLE transactions (
  id serial PRIMARY KEY,
  user_id int NOT NULL,
  occurred_at date NOT NULL,
  amount numeric(15,2) NOT NULL,
  -- ...
) PARTITION BY RANGE (occurred_at);

CREATE TABLE transactions_2025 PARTITION OF transactions FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
```

فوائد:
- عمليات الحذف والأرشفة السريعة عبر استبدال/إسقاط Partition.
- تقليص حجم الفهارس على الأقسام الفعالة.

---

## 4. استعلامات تقارير متقدّمة (SQL + Prisma)

### 4.1 مجموع الإنفاق الشهري لكل فئة (SQL)
```sql
SELECT category_id,
       DATE_TRUNC('month', occurred_at) AS month,
       SUM(amount) AS total
FROM transactions
WHERE user_id = $1
  AND occurred_at >= $2
  AND occurred_at < $3
GROUP BY category_id, month
ORDER BY month DESC, total DESC;
```

Prisma (مثال باستخدام raw query):
```ts
const res = await prisma.$queryRaw`
  SELECT category_id, DATE_TRUNC('month', occurred_at) AS month, SUM(amount) as total
  FROM transactions
  WHERE user_id = ${userId} AND occurred_at >= ${start} AND occurred_at < ${end}
  GROUP BY category_id, month
  ORDER BY month DESC, total DESC;
`;
```

### 4.2 حساب الرصيد التراكمي (Running Balance) — SQL window function
```sql
SELECT id, occurred_at, amount,
       SUM(amount) OVER (PARTITION BY account_id ORDER BY occurred_at ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_balance
FROM transactions
WHERE user_id = $1 AND account_id = $2
ORDER BY occurred_at DESC
LIMIT 100;
```

> عمليًا: Window functions قوية للتقارير التفاعلية ولكنها قد تكون مكلفة على جداول ضخمة—تأكد من إضافة WHERE وLIMIT مناسب.

### 4.3 اكتشاف الشذوذ البسيط (z-score) في SQL
```sql
WITH stats AS (
  SELECT AVG(amount) AS avg, STDDEV(amount) AS std
  FROM transactions WHERE user_id = $1
)
SELECT t.*,
       (t.amount - s.avg)/NULLIF(s.std,0) AS z_score
FROM transactions t, stats s
WHERE t.user_id = $1
  AND ABS((t.amount - s.avg)/NULLIF(s.std,0)) > 3;
```

---

## 5. Pagination (Cursor vs Offset)

- Offset-based pagination مناسب للصفحات السطحية لكنه يصبح بطيئًا مع OFFSET كبير.
- Cursor-based pagination (باستخدام occurred_at أو id مرجعي) أسرع وأكثر استقرارًا.

SQL مثال (cursor):
```sql
SELECT * FROM transactions
WHERE user_id = $1
  AND (occurred_at < $cursor)
ORDER BY occurred_at DESC
LIMIT 50;
```

Prisma:
```ts
const results = await prisma.transaction.findMany({
  where: { userId },
  orderBy: { occurredAt: 'desc' },
  take: 50,
  cursor: cursor ? { occurredAt: cursor } : undefined,
  skip: cursor ? 1 : 0,
});
```

---

## 6. Batch Operations وBulk Inserts

- استخدم `createMany` لإدخالات كبيرة: يدعمها Postgres ويكون أسرع من create داخل حلقة.
- استخدم `prisma.$transaction([...])` للقيام بعمليات مُجمّعة تضمن التوافقية.

Prisma example:
```ts
await prisma.$transaction([
  prisma.transaction.createMany({ data: bulkTransactions }),
  prisma.account.update({ where: { id: accountId }, data: { balance: { increment: total } } })
]);
```

---

## 7. Materialized Views وPre-Computed Tables

لمهمات التقارير الثقيلة، إنشاء Materialized View يقلّل زمن الاستعلام:
```sql
CREATE MATERIALIZED VIEW monthly_category_totals AS
SELECT user_id, category_id, DATE_TRUNC('month', occurred_at) AS month, SUM(amount) AS total
FROM transactions
GROUP BY user_id, category_id, month;

-- تحديث العرض عند الحاجة
REFRESH MATERIALIZED VIEW CONCURRENTLY monthly_category_totals;
```

تلميح: جدولة عملية التحديث بعد فترات منخفضة النشاط (daily/nightly) أو عند تغيّر البيانات المهمة.

---

## 8. مراقبة الأداء: EXPLAIN ANALYZE وpg_stat_statements

- استخدم `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` لفهم خطة التنفيذ وتحديد النقاط الساخنة.
- فعّل `pg_stat_statements` لجمع إحصاءات استعلامات الإنتاج ومعرفة ما هي الاستعلامات الأكثر تكلفة.

مثال EXPLAIN:
```sql
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT category_id, SUM(amount) as total
FROM transactions
WHERE user_id = 1
  AND occurred_at >= '2026-01-01'
  AND occurred_at < '2026-02-01'
GROUP BY category_id;
```

تحليل الخطوات الناتجة يعطيك مؤشرًا على ما إن كا