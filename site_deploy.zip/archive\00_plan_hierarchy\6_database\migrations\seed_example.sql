-- Seed example data for local testing

INSERT INTO users (email, password_hash, name, currency, income_pattern) VALUES
('alice@example.com', NULL, 'Alice', 'USD', 'variable'),
('bob@example.com', NULL, 'Bob', 'USD', 'fixed');

INSERT INTO accounts (user_id, name, type, balance, currency) VALUES
(1, 'Cash', 'wallet', 1000.00, 'USD'),
(1, 'Bank Account', 'bank', 2500.00, 'USD'),
(2, 'Main Account', 'bank', 500.00, 'USD');

INSERT INTO categories (user_id, name, type) VALUES
(1, 'Groceries', 'expense'),
(1, 'Freelance Income', 'income'),
(2, 'Utilities', 'expense');

INSERT INTO transactions (user_id, account_id, amount, currency, type, category_id, notes, occurred_at) VALUES
(1, 1, -50.0, 'USD', 'expense', 1, 'Grocery shopping', NOW()),
(1, 2, 1200.0, 'USD', 'income', 2, 'Client payment', NOW()),
(2, 3, -70.0, 'USD', 'expense', 3, 'Electricity bill', NOW());