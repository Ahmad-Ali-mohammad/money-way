-- AlterTable
ALTER TABLE "goals" ADD COLUMN "icon" TEXT;
