Short checklist to deploy backend to production:

1. Create a MySQL database and user on your chosen provider.
2. Set `DATABASE_URL` in production environment to: mysql://USER:PASSWORD@HOST:3306/finance_db
3. Set `JWT_SECRET` in environment secrets.
4. Either run migrations manually in the host or rely on container startup (the Dockerfile runs `prisma migrate deploy`).
5. Use `docker-compose -f ../docker-compose.prod.yml up -d --build` or deploy containers to your provider.
