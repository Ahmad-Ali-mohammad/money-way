import { prisma } from '../lib/prisma';

interface AdaptiveRule {
  basePercentage: number;
  minAmount?: number;
  maxAmount?: number;
  condition?: 'always' | 'emergency' | 'prosperity';
}

function parseAdaptiveRule(rule: string | null): AdaptiveRule {
  if (!rule) {
    return { basePercentage: 10 };
  }
  try {
    return JSON.parse(rule);
  } catch {
    return { basePercentage: 10 };
  }
}

async function getTotalIncomeForPeriod(userId: number, startDate: Date, endDate: Date): Promise<number> {
  const result = await prisma.transaction.aggregate({
    where: {
      userId,
      type: 'income',
      occurredAt: {
        gte: startDate,
        lte: endDate,
      },
    },
    _sum: {
      amount: true,
    },
  });

  return Number(result._sum.amount || 0);
}

async function getAverageMonthlyIncome(userId: number, months: number = 3): Promise<number> {
  const endDate = new Date();
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months);

  const totalIncome = await getTotalIncomeForPeriod(userId, startDate, endDate);
  return totalIncome / months;
}

export async function calculateAdaptiveBudgetAmount(
  userId: number,
  budgetId: number
): Promise<number> {
  const budget = await prisma.budget.findUnique({
    where: { id: budgetId },
  });

  if (!budget || !budget.isAdaptive) {
    return Number(budget?.amount || 0);
  }

  // If it's percentage-based adaptive budget
  if (budget.isPercentage && budget.percentage) {
    const currentMonthStart = new Date();
    currentMonthStart.setDate(1);
    currentMonthStart.setHours(0, 0, 0, 0);

    const currentMonthEnd = new Date();
    currentMonthEnd.setMonth(currentMonthEnd.getMonth() + 1);
    currentMonthEnd.setDate(0);
    currentMonthEnd.setHours(23, 59, 59, 999);

    const currentMonthIncome = await getTotalIncomeForPeriod(
      userId,
      currentMonthStart,
      currentMonthEnd
    );

    const calculatedAmount = (currentMonthIncome * Number(budget.percentage)) / 100;
    
    const rule = parseAdaptiveRule(budget.adaptiveRule);
    
    // Apply min/max constraints
    let finalAmount = calculatedAmount;
    if (rule.minAmount && calculatedAmount < rule.minAmount) {
      finalAmount = rule.minAmount;
    }
    if (rule.maxAmount && calculatedAmount > rule.maxAmount) {
      finalAmount = rule.maxAmount;
    }

    return finalAmount;
  }

  // For fixed amount budgets with adaptive rules
  const rule = parseAdaptiveRule(budget.adaptiveRule);
  const avgMonthlyIncome = await getAverageMonthlyIncome(userId);
  
  // Calculate suggested amount based on income
  const suggestedAmount = (avgMonthlyIncome * rule.basePercentage) / 100;
  
  // Apply constraints
  let finalAmount = suggestedAmount;
  if (rule.minAmount && suggestedAmount < rule.minAmount) {
    finalAmount = rule.minAmount;
  }
  if (rule.maxAmount && suggestedAmount > rule.maxAmount) {
    finalAmount = rule.maxAmount;
  }

  return finalAmount;
}

export async function recalculateAllAdaptiveBudgets(userId: number) {
  console.log(`[Adaptive Budget] Recalculating budgets for user ${userId}`);

  const adaptiveBudgets = await prisma.budget.findMany({
    where: {
      userId,
      isAdaptive: true,
      active: true,
    },
  });

  const results = [];

  for (const budget of adaptiveBudgets) {
    try {
      const newAmount = await calculateAdaptiveBudgetAmount(userId, budget.id);
      
      if (Math.abs(newAmount - Number(budget.amount)) > 0.01) {
        await prisma.budget.update({
          where: { id: budget.id },
          data: { amount: newAmount },
        });

        // Create alert about budget adjustment
        await prisma.alert.create({
          data: {
            userId,
            type: 'custom',
            message: `Budget "${budget.name}" adjusted to ${newAmount.toFixed(2)} based on your income`,
            severity: 'low',
            metadata: JSON.stringify({
              budgetId: budget.id,
              oldAmount: Number(budget.amount),
              newAmount,
            }),
          },
        });

        results.push({
          budgetId: budget.id,
          name: budget.name,
          oldAmount: Number(budget.amount),
          newAmount,
          adjusted: true,
        });
      } else {
        results.push({
          budgetId: budget.id,
          name: budget.name,
          amount: Number(budget.amount),
          adjusted: false,
        });
      }
    } catch (error) {
      console.error(`[Adaptive Budget] Error processing budget ${budget.id}:`, error);
    }
  }

  console.log(`[Adaptive Budget] Processed ${results.length} budgets`);
  return results;
}

export async function checkBudgetSurplusTransfer(userId: number) {
  console.log(`[Budget Surplus] Checking for surplus transfer for user ${userId}`);

  const budgets = await prisma.budget.findMany({
    where: {
      userId,
      active: true,
    },
    include: {
      category: true,
    },
  });

  for (const budget of budgets) {
    const remaining = Number(budget.amount) - Number(budget.spent);
    
    if (remaining > 0 && remaining > Number(budget.amount) * 0.1) { // More than 10% remaining
      // Find savings goal to transfer to
      const savingsGoal = await prisma.goal.findFirst({
        where: { userId },
        orderBy: { targetAmount: 'desc' },
      });

      if (savingsGoal && Number(savingsGoal.currentAmount) < Number(savingsGoal.targetAmount)) {
        const transferAmount = Math.min(remaining, Number(savingsGoal.targetAmount) - Number(savingsGoal.currentAmount));
        
        await prisma.goal.update({
          where: { id: savingsGoal.id },
          data: {
            currentAmount: {
              increment: transferAmount,
            },
          },
        });

        await prisma.alert.create({
          data: {
            userId,
            type: 'goal_milestone',
            message: `Surplus of ${transferAmount.toFixed(2)} from "${budget.name}" transferred to goal "${savingsGoal.name}"`,
            severity: 'low',
            metadata: JSON.stringify({
              budgetId: budget.id,
              goalId: savingsGoal.id,
              amount: transferAmount,
            }),
          },
        });

        console.log(`[Budget Surplus] Transferred ${transferAmount} from budget ${budget.id} to goal ${savingsGoal.id}`);
      }
    }
  }
}
