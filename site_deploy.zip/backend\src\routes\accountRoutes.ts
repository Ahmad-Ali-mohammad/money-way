import { Router } from 'express';
import {
  getAllAccounts,
  createAccount,
  getAccountById,
  updateAccount,
  deleteAccount,
  getAccountBalance,
} from '../controllers/accountController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.use(authMiddleware);

router.get('/', getAllAccounts);
router.post('/', createAccount);
router.get('/:id', getAccountById);
router.put('/:id', updateAccount);
router.delete('/:id', deleteAccount);
router.get('/:id/balance', getAccountBalance);

export default router;
