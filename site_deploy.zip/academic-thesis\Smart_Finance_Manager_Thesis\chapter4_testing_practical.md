# الفصل الرابع: الاختبار والتطبيق العملي (تفصيلي)

## 4.1 استراتيجية الاختبار الشاملة

تشمل استراتيجية الاختبار مستويات عدة لضمان جودة المنهجيات الوظيفية وغير الوظيفية:  
- Unit Tests (الوحدات)
- Integration Tests (التكامل)
- Contract Tests (عقود API)
- End-to-End Tests (E2E)
- Performance & Load Tests
- Security Tests (SAST/DAST/Dependency Scans)
- Regression Tests

### غرض الاستراتيجية
- ضمان أن كل وحدة منطقية تعمل بشكل مستقل.
- التأكد من عمل التكامل بين الطبقات (Frontend ↔ Backend ↔ DB).
- التحقق من أن تحليلات الأداء تعمل ضمن المستويات المقبولة تحت أحمال متوقعة.
- اكتشاف المشكلات الأمنية مبكراً خلال دورة التطوير.

---

## 4.2 بيئات الاختبار وإعدادها

### بيئات مخصصة
- Local Dev: SQLite أو PostgreSQL محلياً باستخدام بيانات تجريبية صغيرة.
- CI: بيئة معزولة تُشغّل اختبارات الوحدة والتكامل لكل PR.
- Staging: نسخة مطابقة للإنتاج لاختبارات القبول والـ E2E.
- Production: مراقبة مستمرة وخطة استجابة للحوادث.

### إعداد البيانات (Test Data)
- استخدام seed scripts مُنفصلة للبيئات (backend/prisma/seed.ts) لإنشاء بيانات اختبارية موحدة.
- عزل بيانات الاختبار: كل اختبار يعيد قاعدة البيانات لحالة معروفة (transactions.rollback أو re-seed).
- توليد بيانات حمولة (bulkTransactions) لاختبارات الأداء.

---

## 4.3 أنواع الاختبارات وتفاصيل التنفيذ

### 4.3.1 Unit Tests
- المكتبة: Vitest
- أمثلة: اختبار دوال `calculateBudgetUsage`, `formatCurrency`، وخدمات مثل `userService`.
- قواعد: كل اختبار يجب أن يختبر حالة واحدة ويعزل الاعتمادات عبر mocks.

مثال بسيط:
```ts
import { describe, it, expect } from 'vitest';
import { calculateBudgetUsage } from '../services/budgetService';

describe('calculateBudgetUsage', () => {
  it('computes correct usage percentage', () => {
    const result = calculateBudgetUsage(200, 50);
    expect(result).toBe(25);
  });
});
```

### 4.3.2 Integration Tests
- المكتبة: Supertest + Vitest
- الأهداف: اختبار نقاط النهاية مع DB اختبارية (SQLite in-memory أو test Postgres).

مثال:
```ts
import request from 'supertest';
import app from '../src/index';

test('register and login flow', async () => {
  await request(app).post('/api/auth/register').send({ email: 'a@b.com', password: 'P@ssw0rd' }).expect(201);
  const res = await request(app).post('/api/auth/login').send({ email: 'a@b.com', password: 'P@ssw0rd' }).expect(200);
  expect(res.body.token).toBeDefined();
});
```

### 4.3.3 End-to-End Tests (E2E)
- الأداة المقترحة: Playwright
- تغطية سيناريوهات: تسجيل مستخدم، إضافة معاملة، إنشاء ميزانية، استقبال تنبيه.
- E2E تستخدم بيئة staging مع بيانات معروفة.

### 4.3.4 Performance & Load Tests
- الأداة المقترحة: k6 أو Locust
- سيناريوهات: حمل قراءة Dashboard (60% من الزيارات)، إضافة معاملات (30%)، عمليات الحساب والتقارير (10%).
- أهداف الأداء: p95 latency < 800ms تحت 100 RPS للـ API.

مثال k6 script:
```js
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = { vus: 50, duration: '1m' };

export default function () {
  const res = http.get(`${__ENV.API_URL}/api/dashboard/overview`);
  check(res, { 'status is 200': (r) => r.status === 200 });
  sleep(1);
}
```

### 4.3.5 Security Tests
- SAST: استخدام Codacy/GitHub Actions لالتقاط مشاكل الكود.
- DAST: OWASP ZAP لفحص التطبيق من الطبقة الخارجية.
- Dependency scanning: Trivy أو npm audit لتحديد ثغرات الحزم.

---

## 4.4 خطة الاختبار التفصيلية وحالات الاختبار (Test Cases)

### مجموعة حالات قاعدةية (Critical Paths)
1. التسجيل وتسجيل الدخول
2. إنشاء حساب مالي
3. إضافة/تعديل/حذف معاملة
4. إنشاء ميزانية ثم تغطية تجاوز الميزانية → تحقق الإشعار
5. إنشاء هدف وإضافة دفعات إليه
6. استدعاء تقارير الفترة الزمنية

### حالات اختبار حدودية (Edge Cases)
- إدخال مبالغ سالبة أو صفرية
- حذف حساب مرتبط بمعاملات
- تحميل ملف إيصال كبير جدًا أو به نوع غير مدعوم
- شبكات متقطعة أثناء إرسال معاملة

### حالات اختبار الأمان
- محاولة SQL Injection عبر حقل الوصف
- Cross-site scripting أثناء عرض الملاحظات
- تجاوز صلاحيات الوصول لمحاولة قراءة بيانات مستخدم آخر

### Acceptance Criteria لكل حالة
- ّكل حالة تحتوي على خطوات تفصيلية، بيانات الإدخال، النتيجة المتوقعة، وبيئة الاختبار.

---

## 4.5 أتمتة الاختبار وCI/CD

- تشغيل Unit/Integration/Tiered SAST على كل Pull Request.
- نشر تقارير الاختبار (Coverage badge) في README.
- إعداد Gate في GitHub Actions يمنع الدمج إذا فشلت اختبارات حرجة.

نماذج خطوات CI:
1. Checkout
2. Install dependencies
3. Run lint
4. Run unit tests
5. Run integration tests (with test DB)
6. Run SAST/Dependency scan

---

## 4.6 إدارة التقارير وتحليل النتائج

- استخدام التقرير التلقائي (Vitest reporter، cobertura) لحساب التغطية.
- تخزين نتائج الأداء (k6) في Grafana/InfluxDB لمراقبة تغيّر الأداء عبر الزمن.

---

## 4.7 سجل العيوب (Bug Triage)

- تصنيف العيوب: Critical / Major / Minor
- تحديد الإجراءات: hotfix، backlog, wontfix
- تتبع زمن الإصلاح (MTTR) وتحليل الأسباب الجذرية (RCA)

---

## 4.8 دليل التشغيل للاختبار اليدوي

1. قم بعمل seed للبيانات مع `npm run prisma:seed`.
2. شغّل الخادم في بيئة staging.
3. اتبع قائمة اختبارات القبول (Acceptance Test Checklist).

---

## 4.9 ملاحق الاختبارات وأمثلة الشيفرات

- تجميع نماذج الاختبارات في مجلد `backend/src/__tests__/`.
- أمثلة k6 scripts، Playwright scenarios، وملفات configuration لـ GitHub Actions متاحة للنسخ.

---

## 4.10 خاتمة الفصل

تضمن استراتيجية الاختبار هذه مزيجًا متوازنًا بين السرعة والعمق: اختبارات تلقائية يومية وتقييم شامل قبل أي عملية نشر إلى بيئة الإنتاج. تنفيذ الخطة بدقة يضمن جودة المنتج وموثوقيته على المدى الطويل.
