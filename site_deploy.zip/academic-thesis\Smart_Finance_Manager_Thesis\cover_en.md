# Cover Page (Model 2 - English)

**Syrian Arab Republic**  
**Private AlJazeera University**  
**Faculty of Engineering**  
**Informatics Engineering Department**  

---
<br><br>
<center>
<h1>Smart Finance Manager</h1>
<h3>An integrated system for personal money management with smart analytics and proactive alerts</h3>
<h3>Graduation Project prepared to obtain bachelor's degree of Informatics Engineering</h3>
<br>
</center>

**Prepared by:**

* [Student Name 1]
* [Student Name 2]

**Supervised by:**

* **Dr. [Supervisor's Name]**

**Academic Year:**

* 2025-2026

---
