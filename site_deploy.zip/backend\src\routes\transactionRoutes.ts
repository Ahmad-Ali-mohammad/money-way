import { Router } from 'express';
import {
  getAllTransactions,
  createTransaction,
  getTransactionById,
  updateTransaction,
  deleteTransaction,
  getTransactionStats,
} from '../controllers/transactionController';
import { authenticate } from '../middleware/authMiddleware';

const router = Router();

// All transaction routes require authentication
router.use(authenticate);

router.get('/', getAllTransactions);
router.post('/', createTransaction);
router.get('/stats', getTransactionStats);
router.get('/:id', getTransactionById);
router.put('/:id', updateTransaction);
router.delete('/:id', deleteTransaction);

export default router;
