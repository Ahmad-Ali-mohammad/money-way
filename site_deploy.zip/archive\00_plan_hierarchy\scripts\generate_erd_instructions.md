How to generate ERD images (instructions)

1) Ensure Docker is installed and running.
2) From the `00_plan_hierarchy/6_database` directory run:
   - Linux/Mac: `./generate_erd.sh png` or `./generate_erd.sh svg`
   - Windows: `generate_erd.bat png`
3) If you prefer not to use Docker, install PlantUML and Graphviz locally and run:
   `plantuml -tpng erd.puml`