# قائمة الاختصارات (Abbreviations)

| الاختصار | المعنى الكامل |
| :--- | :--- |
| SDLC | System Development Life Cycle |
| API | Application Programming Interface |
| JWT | JSON Web Token |
| ERD | Entity Relationship Diagram |
| UI | User Interface |

---
