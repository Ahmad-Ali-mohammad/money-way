import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const tagSchema = z.object({
  name: z.string().min(1).max(50),
  color: z.string().optional(),
});

export const getAllTags = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const tags = await prisma.tag.findMany({
      where: { userId },
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { transactions: true },
        },
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(tags, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching tags:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createTag = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = tagSchema.parse(req.body);

    // Check if tag already exists
    const existing = await prisma.tag.findFirst({
      where: {
        userId,
        name: data.name,
      },
    });

    if (existing) {
      return res.status(400).json({ error: 'Tag already exists' });
    }

    const tag = await prisma.tag.create({
      data: {
        userId,
        name: data.name,
        color: data.color,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(tag, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateTag = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const tagId = parseInt(req.params.id as string);
    const data = tagSchema.partial().parse(req.body);

    const existing = await prisma.tag.findFirst({
      where: { id: tagId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Tag not found' });
    }

    const updated = await prisma.tag.update({
      where: { id: tagId },
      data: {
        ...(data.name && { name: data.name }),
        ...(data.color !== undefined && { color: data.color }),
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(updated, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error updating tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteTag = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const tagId = parseInt(req.params.id as string);

    const existing = await prisma.tag.findFirst({
      where: { id: tagId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Tag not found' });
    }

    await prisma.tag.delete({
      where: { id: tagId },
    });

    res.json({ message: 'Tag deleted successfully' });
  } catch (error) {
    console.error('Error deleting tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const addTagToTransaction = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const transactionId = parseInt(req.body.transactionId);
    const tagId = parseInt(req.body.tagId);

    // Verify transaction ownership
    const transaction = await prisma.transaction.findFirst({
      where: {
        id: transactionId,
        userId,
      },
    });

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    // Verify tag ownership
    const tag = await prisma.tag.findFirst({
      where: {
        id: tagId,
        userId,
      },
    });

    if (!tag) {
      return res.status(404).json({ error: 'Tag not found' });
    }

    // Check if already linked
    const existing = await prisma.transactionTag.findUnique({
      where: {
        transactionId_tagId: {
          transactionId: transactionId,
          tagId: tagId,
        },
      },
    });

    if (existing) {
      return res.status(400).json({ error: 'Tag already linked to transaction' });
    }

    const link = await prisma.transactionTag.create({
      data: {
        transactionId: transactionId,
        tagId: tagId,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(link, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    console.error('Error adding tag to transaction:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const removeTagFromTransaction = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const transactionId = parseInt(req.params.transactionId as string);
    const tagId = parseInt(req.params.tagId as string);

    // Verify transaction ownership
    const transaction = await prisma.transaction.findFirst({
      where: {
        id: transactionId,
        userId,
      },
    });

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    await prisma.transactionTag.delete({
      where: {
        transactionId_tagId: {
          transactionId: transactionId,
          tagId: tagId,
        },
      },
    });

    res.json({ message: 'Tag removed from transaction' });
  } catch (error) {
    console.error('Error removing tag from transaction:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};



