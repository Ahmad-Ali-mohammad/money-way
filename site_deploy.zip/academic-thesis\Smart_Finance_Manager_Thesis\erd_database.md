# ERD وقاعدة البيانات — Smart Finance Manager

> هذا الملف يقدّم ERD كاملًا، وصف الجداول، استعلامات نموذجية (SQL)، أمثلة Prisma، واستراتيجيات أداء ونشر لقاعدة البيانات.

---

## 1. ملخّص ومقدمة
- قاعدة البيانات في المشروع تستخدم `Prisma` كـ ORM. النموذج الحالي مبني على نموذج علاقات تقليدي (relational) مع جداول للمستخدمين والحسابات والمعاملات والوسوم (tags)، الميزانيات، الأهداف، المشاريع، الإشعارات، والإيصالات.
- للاستخدام الإنتاجي ننصح PostgreSQL (`NUMERIC`/`DECIMAL` للمبالغ) بدل SQLite لميزات الأداء، الفهرسة، والنسخ الاحتياطي.

---

## 2. ERD (Mermaid)

```mermaid
erDiagram
  USERS ||--o{ ACCOUNTS : owns
  USERS ||--o{ CATEGORIES : defines
  USERS ||--o{ TRANSACTIONS : records
  USERS ||--o{ TAGS : owns
  USERS ||--o{ BUDGETS : owns
  USERS ||--o{ GOALS : owns
  USERS ||--o{ PROJECTS : owns
  USERS ||--o{ ALERTS : receives
  USERS ||--o{ RECEIPTS : uploads

  ACCOUNTS ||--o{ TRANSACTIONS : "from_account"
  ACCOUNTS ||--o{ TRANSACTIONS : "to_account"

  TRANSACTIONS ||--o{ TRANSACTION_TAGS : tags
  TAGS ||--o{ TRANSACTION_TAGS : tagged_by

  CATEGORIES ||--o{ BUDGETS : categorized
  GOALS ||--o{ GOAL_TRANSACTIONS : records

  %% Tables details (abbreviated display in ERD)
  USERS { 
    int id PK
    string email
  }
  ACCOUNTS {
    int id PK
    int user_id FK
    float balance
  }
  TRANSACTIONS {
    int id PK
    int user_id FK
    int account_id FK
    float amount
    datetime occurred_at
  }
  TAGS { int id; string name }
  TRANSACTION_TAGS { int id; int transaction_id FK; int tag_id FK }
```

> ملاحظة: استخدم أدوات مثل `mermaid-cli` أو مولدات PlantUML لتحويل الـ mermaid إلى صور قابلة للطباعة.

---

## 3. وصف الجداول (Fields, Constraints, Indexes, Relations)

> الجدولة التالية تعتمد على `backend/prisma/schema.prisma` (راجع الملف للحصول على الحقول الكاملة).

### 3.1 users
- الحقول الأساسية: `id (PK)`, `email (unique)`, `passwordHash`, `name`, `currency`, `created_at`, `updated_at`.
- قيود: `email` فريد.
- ملاحظات: لا تخزن كلمات المرور نصيًا؛ خزّن hash فقط.

### 3.2 accounts
- الحقول: `id`, `user_id (FK users.id)`, `name`, `type`, `balance`, `currency`, `created_at`, `updated_at`.
- فهرس مقترح: `idx_accounts_user_id` على `user_id`.
- ملاحظة: لا تعتمد على `balance` فقط لحساب الرصيد التاريخي — قم بحساب الرصيد من تراكم المعاملات عند الحاجة لأغراض المراجعة.

### 3.3 transactions
- الحقول: `id`, `user_id (FK)`, `account_id (FK)`, `to_account_id (FK?)`, `amount`, `currency`, `type`, `category_id`, `notes`, `receipt_id`, `is_recurring`, `recurrence_rule`, `next_occurrence`, `recurring_parent_id`, `occurred_at`, `created_at`.
- فهارس مقترحة:
  - `idx_tx_user_occurred_at (user_id, occurred_at DESC)` — لتحميل قائمة المعاملات حسب المستخدم والفترات الزمنية.
  - `idx_tx_account_id (account_id)` — لعمليات حساب رصيد الحساب.
  - `idx_tx_category_id (category_id)` — لتقارير الفئات.
- ملاحظة: المعاملات التي تمثل تحويلًا بين حسابين تسجَّل باستخدام `to_account_id` و`type = 'transfer'`.

### 3.4 tags, transaction_tags
- عقدة many-to-many: `transaction_tags` تربط `transactions` و `tags`.
- قيد فريد على `transaction_tags (transaction_id, tag_id)`.

### 3.5 budgets
- الحقول الأساسية: `id`, `user_id`, `category_id`, `amount`, `period`, `spent`, `start_date`, `end_date`.
- ملاحظة: `spent` يمكن تحديثه عبر مواد مجمّعة أو محاسبة عبر triggers/materialized views.

### 3.6 goals, goal_transactions
- نموذج هدف مع سجل للدفعات المرتبطة بالهدف.

### 3.7 alerts, receipts, projects
- سجلات تنبيهات وإيصالات وبيانات مشاريع تُسجَّل مع FK إلى المستخدم.

---

## 4. استعلامات SQL نموذجية (Postgres syntax)

### 4.1 جلب معاملات مستخدم في فترة زمنية مع الفئات والوسوم

```sql
SELECT t.id, t.amount, t.currency, t.type, t.occurred_at, c.name AS category, array_agg(json_build_object('id', tg.id, 'name', g.name)) AS tags
FROM transactions t
LEFT JOIN categories c ON c.id = t.category_id
LEFT JOIN transaction_tags tg ON tg.transaction_id = t.id
LEFT JOIN tags g ON g.id = tg.tag_id
WHERE t.user_id = $1
  AND t.occurred_at BETWEEN $2 AND $3
GROUP BY t.id, c.name
ORDER BY t.occurred_at DESC
LIMIT 100;
```

### 4.2 تجميع المصروفات الشهرية حسب الفئة (report)

```sql
SELECT date_trunc('month', t.occurred_at) AS month, c.name AS category, SUM(t.amount) FILTER (WHERE t.type = 'expense') AS total_spent
FROM transactions t
LEFT JOIN categories c ON c.id = t.category_id
WHERE t.user_id = $1
GROUP BY month, c.name
ORDER BY month DESC, total_spent DESC;
```

### 4.3 إجراء تحويل بين حسابين في معاملة آمنة (transaction)

```sql
BEGIN;
UPDATE accounts SET balance = balance - 100 WHERE id = $from_account_id AND user_id = $user_id;
UPDATE accounts SET balance = balance + 100 WHERE id = $to_account_id AND user_id = $user_id;
INSERT INTO transactions (user_id, account_id, to_account_id, amount, type, occurred_at) VALUES ($user_id, $from_account_id, $to_account_id, 100, 'transfer', now());
COMMIT;
```

> ملاحظة: يجب التحقق من عدم السماح بالسحب من حساب بقيمة سالبة إن كان ذلك شرطًا.

### 4.4 استعلام لاختيار المعاملات المتكررة التي يجب معالجتها الآن

```sql
SELECT * FROM transactions WHERE is_recurring = true AND next_occurrence <= now();
```

---

## 5. EXPLAIN ANALYZE — كيف تقرأ النتيجة

مثال لتشخيص استعلام التجميع الشهري:

```sql
EXPLAIN ANALYZE
SELECT date_trunc('month', t.occurred_at) AS month, c.name AS category, SUM(t.amount) AS total_spent
FROM transactions t
LEFT JOIN categories c ON c.id = t.category_id
WHERE t.user_id = 1
GROUP BY month, c.name;
```

- الهدف: التحقق ما إذا كان الاستعلام يستخدم فهارس أو يقوم بـ Sequential Scan.
- إذا كانت نتائج EXPLAIN تُظهر Sequential Scan على `transactions` ولديك ملايين صفوف، فكّر في إضافة فهرس على `(user_id, occurred_at)` أو استخدام partitioning حسب `occurred_at`.

---

## 6. أمثلة Prisma (TypeScript)

### 6.1 إنشاء معاملة بسيطة

```ts
const tx = await prisma.transaction.create({
  data: {
    userId: userId,
    accountId: accountId,
    amount: 250.0,
    currency: 'USD',
    type: 'expense',
    occurredAt: new Date(),
  }
});
```

### 6.2 عملية تحويل بين حسابين باستخدام prisma.$transaction

```ts
await prisma.$transaction(async (prismaTx) => {
  await prismaTx.account.update({ where: { id: fromAccountId }, data: { balance: { decrement: 100 } } });
  await prismaTx.account.update({ where: { id: toAccountId }, data: { balance: { increment: 100 } } });
  await prismaTx.transaction.create({ data: { userId, accountId: fromAccountId, toAccountId, amount: 100, type: 'transfer', occurredAt: new Date() } });
});
```

### 6.3 Pagination (cursor-based)

```ts
const page = await prisma.transaction.findMany({
  where: { userId: userId },
  orderBy: { occurredAt: 'desc' },
  take: 20,
  cursor: { id: lastSeenId },
  skip: 1
});
```

### 6.4 تجميع (Group by) شهريًا

```ts
const monthly = await prisma.transaction.groupBy({
  by: ['month'], // Prisma v4+ supports groupBy with raw SQL or using db views
  _sum: { amount: true },
  where: { userId }
});
```

> ملاحظة: عند الحاجة لمرونة أعلى في التقارير استخدم `prisma.$queryRaw` مع استعلامات SQL المخصصة أو أنشئ materialized views.

---

## 7. Migrations و Seed

### 7.1 إنشاء ومعالجة التغييرات
- تنفيذ التغيير محليًا: `npx prisma migrate dev --name add-some-field`.
- توليد ملف الشيفرة: `npx prisma generate`.

### 7.2 seed
- استخدم `prisma db seed` أو سكربت Node (backend/prisma/seed.ts) لإنشاء مستخدمين وحسابات ومعاملات تجريبية.

---

## 8. النسخ الاحتياطي والاسترجاع
- PostgreSQL: `pg_dump -Fc -f backup.dump $DATABASE_URL` و`pg_restore --dbname=$DB_URL backup.dump`.
- SQLite: نسخ ملف `dev.db` أو استخدام `sqlite3 dbfile .dump > backup.sql`.
- جدولة نسخ يومية وتخزينها مشفّرة في مكان آمن.

---

## 9. أداء، فهارس، وتقنيات التدرج
- فهارس مقترحة:
  - `CREATE INDEX idx_tx_user_occurred_at ON transactions (user_id, occurred_at DESC);`
  - `CREATE INDEX idx_tx_account_id ON transactions (account_id);`
  - `CREATE INDEX idx_budgets_user_category ON budgets (user_id, category_id);`
- Partitioning: افصل جدول `transactions` بحسب السنة/الشهر إذا تجاوز حجم البيانات حدودًا كبيرة.
- Materialized Views: استخدمها لتقارير Dashboard كتجميعات شهرية (`CREATE MATERIALIZED VIEW monthly_category_spend AS ...`).
- Caching: Cache نتائج التقارير الثقيلة في Redis مع صلاحية زمنية قصيرة.
- Avoid N+1: استخدم `include` و`select` في Prisma لجلب العلاقات المطلوبة دفعة واحدة.

---

## 10. قواعد بيانات الوثائق لبيانات metadata
- خزّن بيانات غير منتظمة في حقل `metadata` (JSONB في PostgreSQL) مع فهرس GIN إذا كنت ستجري بحثًا داخل الحقل.

---

## 11. تدقيق (Auditing) والنظام المالي
- طرق:
  - triggers في DB تدرج سجلًا في `audit_logs` عند CRUD على `transactions`, `accounts`.
  - أو طبقة التطبيق تسجّل الأحداث الحرجة وتُلحقها بسجل الأحداث.

مثال Trigger (Postgres):
```sql
CREATE TABLE audit_logs (id serial primary key, table_name text, record_id int, action text, changed_at timestamptz default now(), payload jsonb);

CREATE FUNCTION log_transaction_changes() RETURNS trigger AS $$
BEGIN
  INSERT INTO audit_logs (table_name, record_id, action, payload) VALUES ('transactions', NEW.id, TG_OP, row_to_json(NEW));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_transaction_audit AFTER INSERT OR UPDATE OR DELETE ON transactions
  FOR EACH ROW EXECUTE FUNCTION log_transaction_changes();
```

---

## 12. صيانة دورية
- `VACUUM ANALYZE` لPostgres دوريًا.
- مراقبة نمو الجدول `transactions` وتهيئة أرشفة للبيانات الأقدم من X سنوات.
- مراقبة مؤشرات الأداء (p95 latency, query timeouts).

---

## 13. نقاط تنفيذية (Checklist) قبل الانتقال للإنتاج
- [ ] تحويل المخزون إلى PostgreSQL
- [ ] مراجعة أنواع الحقول للمبالغ (`NUMERIC(p,s)`)
- [ ] إضافة الفهارس الموصى بها
- [ ] إعداد النسخ الاحتياطي الآلي والمراقبة
- [ ] إعداد SRE للـ DB (alerts, autoscaling rules)
- [ ] إعداد أذونات صارمة وقواعد RLS إن لزم

---

## 14. ملحق: ملفات ومواقع ذات صلة
- `backend/prisma/schema.prisma` — المصدر الرئيسي لنموذج البيانات.
- `backend/prisma/seed.ts` — سكربت البيانات التجريبية.
- `backend/src/services/*` — طرق إنشاء/تحديث المعاملات وحساب الرصيد.

---

إذا رغبت، أستطيع:
- توليد ERD بصيغة صورة (`.png`) من الـ Mermaid وضمها في الفصل المناسب.
- إنشاء أمثلة `EXPLAIN ANALYZE` حقيقية باستخدام نسخة Postgres تجريبية وضم النتائج إلى الملف.

هل تريدني أن أُدخل رسم الـ ERD كصورة مباشرة، أم تكتفي بملف الـ Markdown مع كود الـ Mermaid؟ ✨