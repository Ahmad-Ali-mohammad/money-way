declare function processRecurringTransactions(): Promise<void>;
export declare function startRecurringTransactionsScheduler(): void;
export { processRecurringTransactions };
