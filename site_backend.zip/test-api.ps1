# Test Backend API
Write-Host "`n🧪 Testing Backend API..." -ForegroundColor Cyan

# 1. Test Login
Write-Host "`n1️⃣ Testing Login..." -ForegroundColor Yellow
$body = @{
    email = "ahmed@example.com"
    password = "password123"
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "http://localhost:4000/api/auth/login" `
        -Method Post `
        -Body $body `
        -ContentType "application/json"
    
    Write-Host "✅ Login Successful!" -ForegroundColor Green
    Write-Host "   User: $($response.user.name)" -ForegroundColor White
    Write-Host "   Email: $($response.user.email)" -ForegroundColor White
    Write-Host "   ID: $($response.user.id)" -ForegroundColor White
    
    $token = $response.token
    Write-Host "   Token: $($token.Substring(0,50))..." -ForegroundColor Gray
    
    # Save token for subsequent requests
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type" = "application/json"
    }
    
    # 2. Test Get Accounts
    Write-Host "`n2️⃣ Testing Get Accounts..." -ForegroundColor Yellow
    $accounts = Invoke-RestMethod -Uri "http://localhost:4000/api/accounts" `
        -Method Get `
        -Headers $headers
    
    Write-Host "✅ Retrieved $($accounts.Count) accounts:" -ForegroundColor Green
    foreach ($account in $accounts) {
        Write-Host "   - $($account.name): $($account.balance) $($account.currency)" -ForegroundColor White
    }
    
    # 3. Test Get Transactions
    Write-Host "`n3️⃣ Testing Get Transactions..." -ForegroundColor Yellow
    $transactions = Invoke-RestMethod -Uri "http://localhost:4000/api/transactions" `
        -Method Get `
        -Headers $headers
    
    Write-Host "✅ Retrieved $($transactions.Count) transactions" -ForegroundColor Green
    
    # 4. Test Get Budgets
    Write-Host "`n4️⃣ Testing Get Budgets..." -ForegroundColor Yellow
    $budgets = Invoke-RestMethod -Uri "http://localhost:4000/api/budgets" `
        -Method Get `
        -Headers $headers
    
    Write-Host "✅ Retrieved $($budgets.Count) budgets:" -ForegroundColor Green
    foreach ($budget in $budgets) {
        Write-Host "   - $($budget.name): $($budget.amount) (spent: $($budget.spent))" -ForegroundColor White
    }
    
    # 5. Test Get Goals
    Write-Host "`n5️⃣ Testing Get Goals..." -ForegroundColor Yellow
    $goals = Invoke-RestMethod -Uri "http://localhost:4000/api/goals" `
        -Method Get `
        -Headers $headers
    
    Write-Host "✅ Retrieved $($goals.Count) goals" -ForegroundColor Green
    
    # 6. Test Get Tags
    Write-Host "`n6️⃣ Testing Get Tags..." -ForegroundColor Yellow
    $tags = Invoke-RestMethod -Uri "http://localhost:4000/api/tags" `
        -Method Get `
        -Headers $headers
    
    Write-Host "✅ Retrieved $($tags.Count) tags" -ForegroundColor Green
    
    Write-Host "`n🎉 All API tests passed successfully!`n" -ForegroundColor Green
    
} catch {
    Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails) {
        Write-Host "Details: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
    exit 1
}
