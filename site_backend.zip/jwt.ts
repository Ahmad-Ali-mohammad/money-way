export function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    console.error('FATAL: JWT_SECRET environment variable is not set. Authentication requires a JWT_SECRET.');
    // Exit to avoid running with insecure default
    process.exit(1);
  }
  return secret;
}
