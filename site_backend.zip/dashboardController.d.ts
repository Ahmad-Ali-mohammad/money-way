import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getDashboardOverview: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getDashboardStats: (req: AuthRequest, res: Response) => Promise<void>;
