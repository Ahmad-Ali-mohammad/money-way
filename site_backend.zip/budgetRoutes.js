"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const budgetController_1 = require("../controllers/budgetController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/', budgetController_1.getAllBudgets);
router.post('/', budgetController_1.createBudget);
router.get('/recalculate', budgetController_1.recalculateBudgets);
router.post('/surplus-transfer', budgetController_1.processSurplusTransfer);
router.get('/:id', budgetController_1.getBudgetById);
router.put('/:id', budgetController_1.updateBudget);
router.delete('/:id', budgetController_1.deleteBudget);
router.get('/:id/progress', budgetController_1.getBudgetProgress);
exports.default = router;
//# sourceMappingURL=budgetRoutes.js.map