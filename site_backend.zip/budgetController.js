"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processSurplusTransfer = exports.recalculateBudgets = exports.getBudgetProgress = exports.deleteBudget = exports.updateBudget = exports.getBudgetById = exports.createBudget = exports.getAllBudgets = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const adaptiveBudgetService_1 = require("../services/adaptiveBudgetService");
// Schema with proper type coercion for numeric strings
const budgetSchema = zod_1.z.object({
    categoryId: zod_1.z.number().optional().nullable(),
    name: zod_1.z.string().min(1, 'Budget name is required'),
    amount: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).optional().transform(val => {
        if (val === undefined || val === null)
            return undefined;
        const num = typeof val === 'string' ? parseFloat(val) : val;
        if (isNaN(num) || num <= 0)
            throw new Error('Amount must be a positive number');
        return num;
    }),
    period: zod_1.z.enum(['daily', 'weekly', 'monthly', 'yearly']).default('monthly'),
    startDate: zod_1.z.string().datetime().optional().nullable(),
    endDate: zod_1.z.string().datetime().optional().nullable(),
    isAdaptive: zod_1.z.boolean().default(false),
    isPercentage: zod_1.z.boolean().default(false),
    percentage: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).optional().transform(val => {
        if (val === undefined || val === null)
            return undefined;
        const num = typeof val === 'string' ? parseFloat(val) : val;
        if (isNaN(num) || num < 0 || num > 100)
            throw new Error('Percentage must be between 0 and 100');
        return num;
    }),
    adaptiveRule: zod_1.z.string().optional().nullable(),
});
// Enriched Read: Fetch budgets with dynamically calculated spent amount
const getAllBudgets = async (req, res) => {
    try {
        const userId = req.user.userId;
        const budgets = await prisma_1.prisma.budget.findMany({
            where: { userId },
            include: {
                category: true,
            },
            orderBy: { createdAt: 'desc' },
        });
        // Enrich each budget with calculated spent amount from transactions
        const enrichedBudgets = await Promise.all(budgets.map(async (budget) => {
            // Calculate spent amount by aggregating EXPENSE transactions for this budget's period
            const startDate = budget.startDate || new Date(new Date().getFullYear(), new Date().getMonth(), 1);
            const endDate = budget.endDate || new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
            const transactions = await prisma_1.prisma.transaction.findMany({
                where: {
                    userId: userId,
                    type: 'expense',
                    ...(budget.categoryId && { categoryId: budget.categoryId }),
                    occurredAt: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
                select: {
                    amount: true,
                },
            });
            const calculatedSpent = transactions.reduce((sum, t) => sum + Number(t.amount), 0);
            // Update budget spent amount if different
            if (Math.abs(calculatedSpent - Number(budget.spent)) > 0.01) {
                await prisma_1.prisma.budget.update({
                    where: { id: budget.id },
                    data: { spent: calculatedSpent },
                });
            }
            return {
                ...budget,
                spent: calculatedSpent,
                remaining: Number(budget.amount) - calculatedSpent,
                percentage: budget.amount > 0 ? (calculatedSpent / Number(budget.amount)) * 100 : 0,
                isOverBudget: calculatedSpent > Number(budget.amount),
            };
        }));
        const serialized = JSON.parse(JSON.stringify(enrichedBudgets, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching budgets:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllBudgets = getAllBudgets;
// Create budget with explicit field mapping
const createBudget = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = budgetSchema.parse(req.body);
        // Validate category if provided
        if (data.categoryId) {
            const categoryExists = await prisma_1.prisma.category.findFirst({
                where: {
                    id: data.categoryId,
                    OR: [
                        { userId: userId },
                        { userId: null } // System categories
                    ]
                }
            });
            if (!categoryExists) {
                return res.status(400).json({ error: 'Invalid category ID' });
            }
        }
        // Calculate initial amount for percentage-based budgets
        let initialAmount = data.amount || 0;
        if (data.isPercentage && data.percentage && !data.amount) {
            // Will be calculated on first income
            initialAmount = 0;
        }
        // Explicit data mapping to prevent field injection
        const budget = await prisma_1.prisma.budget.create({
            data: {
                userId: userId,
                categoryId: data.categoryId || null,
                name: data.name,
                amount: initialAmount,
                spent: 0,
                period: data.period || 'monthly',
                startDate: data.startDate ? new Date(data.startDate) : new Date(),
                endDate: data.endDate ? new Date(data.endDate) : null,
                isAdaptive: data.isAdaptive || false,
                isPercentage: data.isPercentage || false,
                percentage: data.percentage || null,
                adaptiveRule: data.adaptiveRule || null,
                active: true,
            },
            include: {
                category: true,
            },
        });
        const response = {
            ...budget,
            remaining: Number(budget.amount) - Number(budget.spent),
            percentage: budget.amount > 0 ? (Number(budget.spent) / Number(budget.amount)) * 100 : 0,
            isOverBudget: Number(budget.spent) > Number(budget.amount),
        };
        const serialized = JSON.parse(JSON.stringify(response, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: 'Validation failed',
                details: error.issues.map((e) => ({ field: e.path.join('.'), message: e.message }))
            });
        }
        console.error('Error creating budget:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createBudget = createBudget;
// Enriched read for single budget
const getBudgetById = async (req, res) => {
    try {
        const userId = req.user.userId;
        const budgetId = parseInt(req.params.id);
        if (isNaN(budgetId)) {
            return res.status(400).json({ error: 'Invalid budget ID' });
        }
        const budget = await prisma_1.prisma.budget.findFirst({
            where: {
                id: budgetId,
                userId,
            },
            include: {
                category: true,
            },
        });
        if (!budget) {
            return res.status(404).json({ error: 'Budget not found or access denied' });
        }
        // Calculate spent amount dynamically from transactions
        const startDate = budget.startDate || new Date(new Date().getFullYear(), new Date().getMonth(), 1);
        const endDate = budget.endDate || new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
        const transactions = await prisma_1.prisma.transaction.findMany({
            where: {
                userId: userId,
                type: 'expense',
                ...(budget.categoryId && { categoryId: budget.categoryId }),
                occurredAt: {
                    gte: startDate,
                    lte: endDate,
                },
            },
            select: {
                amount: true,
            },
        });
        const calculatedSpent = transactions.reduce((sum, t) => sum + Number(t.amount), 0);
        // Update budget if spent amount changed
        if (Math.abs(calculatedSpent - Number(budget.spent)) > 0.01) {
            await prisma_1.prisma.budget.update({
                where: { id: budget.id },
                data: { spent: calculatedSpent },
            });
        }
        const response = {
            ...budget,
            spent: calculatedSpent,
            remaining: Number(budget.amount) - calculatedSpent,
            percentage: budget.amount > 0 ? (calculatedSpent / Number(budget.amount)) * 100 : 0,
            isOverBudget: calculatedSpent > Number(budget.amount),
            transactionCount: transactions.length,
        };
        const serialized = JSON.parse(JSON.stringify(response, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching budget:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getBudgetById = getBudgetById;
// Update budget with explicit field mapping
const updateBudget = async (req, res) => {
    try {
        const userId = req.user.userId;
        const budgetId = parseInt(req.params.id);
        if (isNaN(budgetId)) {
            return res.status(400).json({ error: 'Invalid budget ID' });
        }
        // Verify ownership
        const existing = await prisma_1.prisma.budget.findFirst({
            where: { id: budgetId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Budget not found or access denied' });
        }
        const data = budgetSchema.partial().parse(req.body);
        // Validate category if being updated
        if (data.categoryId !== undefined && data.categoryId !== null) {
            const categoryExists = await prisma_1.prisma.category.findFirst({
                where: {
                    id: data.categoryId,
                    OR: [
                        { userId: userId },
                        { userId: null }
                    ]
                }
            });
            if (!categoryExists) {
                return res.status(400).json({ error: 'Invalid category ID' });
            }
        }
        // Explicit data mapping to prevent field injection
        const updateData = {};
        if (data.name !== undefined) {
            updateData.name = data.name;
        }
        if (data.categoryId !== undefined) {
            updateData.categoryId = data.categoryId;
        }
        if (data.amount !== undefined) {
            updateData.amount = data.amount;
        }
        if (data.period !== undefined) {
            updateData.period = data.period;
        }
        if (data.startDate !== undefined) {
            updateData.startDate = data.startDate ? new Date(data.startDate) : null;
        }
        if (data.endDate !== undefined) {
            updateData.endDate = data.endDate ? new Date(data.endDate) : null;
        }
        if (data.isAdaptive !== undefined) {
            updateData.isAdaptive = data.isAdaptive;
        }
        if (data.isPercentage !== undefined) {
            updateData.isPercentage = data.isPercentage;
        }
        if (data.percentage !== undefined) {
            updateData.percentage = data.percentage;
        }
        if (data.adaptiveRule !== undefined) {
            updateData.adaptiveRule = data.adaptiveRule;
        }
        const updated = await prisma_1.prisma.budget.update({
            where: { id: budgetId },
            data: updateData,
            include: {
                category: true,
            },
        });
        const response = {
            ...updated,
            remaining: Number(updated.amount) - Number(updated.spent),
            percentage: updated.amount > 0 ? (Number(updated.spent) / Number(updated.amount)) * 100 : 0,
            isOverBudget: Number(updated.spent) > Number(updated.amount),
        };
        const serialized = JSON.parse(JSON.stringify(response, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: 'Validation failed',
                details: error.issues.map((e) => ({ field: e.path.join('.'), message: e.message }))
            });
        }
        console.error('Error updating budget:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateBudget = updateBudget;
// Securely delete budget after verifying ownership
const deleteBudget = async (req, res) => {
    try {
        const userId = req.user.userId;
        const budgetId = parseInt(req.params.id);
        if (isNaN(budgetId)) {
            return res.status(400).json({ error: 'Invalid budget ID' });
        }
        // Verify ownership before deletion
        const existing = await prisma_1.prisma.budget.findFirst({
            where: { id: budgetId, userId },
            include: { category: true },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Budget not found or access denied' });
        }
        await prisma_1.prisma.budget.delete({
            where: { id: budgetId },
        });
        res.json({
            message: 'Budget deleted successfully',
            deletedBudget: {
                id: existing.id.toString(),
                name: existing.name,
                category: existing.category?.name || null
            }
        });
    }
    catch (error) {
        console.error('Error deleting budget:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteBudget = deleteBudget;
const getBudgetProgress = async (req, res) => {
    try {
        const userId = req.user.userId;
        const budgetId = parseInt(req.params.id);
        // Fetch budget
        const budget = await prisma_1.prisma.budget.findFirst({
            where: { id: budgetId, userId },
            include: { category: true },
        });
        if (!budget) {
            return res.status(404).json({ error: 'Budget not found' });
        }
        // Calculate current amount if adaptive
        let currentAmount = Number(budget.amount);
        if (budget.isAdaptive) {
            currentAmount = await (0, adaptiveBudgetService_1.calculateAdaptiveBudgetAmount)(userId, budgetId);
        }
        const percentage = currentAmount > 0 ? (Number(budget.spent) / currentAmount) * 100 : 0;
        const remaining = currentAmount - Number(budget.spent);
        res.json({
            budgetId: budget.id.toString(),
            category: budget.category?.name || budget.name,
            amount: currentAmount,
            spent: Number(budget.spent),
            remaining,
            percentage: Math.round(percentage * 100) / 100,
            isOverBudget: Number(budget.spent) > currentAmount,
            isAdaptive: budget.isAdaptive,
            isPercentage: budget.isPercentage,
        });
    }
    catch (error) {
        console.error('Error fetching budget progress:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getBudgetProgress = getBudgetProgress;
const recalculateBudgets = async (req, res) => {
    try {
        const userId = req.user.userId;
        const results = await (0, adaptiveBudgetService_1.recalculateAllAdaptiveBudgets)(userId);
        res.json({
            message: 'Budgets recalculated successfully',
            results,
        });
    }
    catch (error) {
        console.error('Error recalculating budgets:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.recalculateBudgets = recalculateBudgets;
const processSurplusTransfer = async (req, res) => {
    try {
        const userId = req.user.userId;
        await (0, adaptiveBudgetService_1.checkBudgetSurplusTransfer)(userId);
        res.json({ message: 'Surplus transfer processed successfully' });
    }
    catch (error) {
        console.error('Error processing surplus transfer:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.processSurplusTransfer = processSurplusTransfer;
//# sourceMappingURL=budgetController.js.map