"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getJwtSecret = getJwtSecret;
function getJwtSecret() {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        console.error('FATAL: JWT_SECRET environment variable is not set. Authentication requires a JWT_SECRET.');
        // Exit to avoid running with insecure default
        process.exit(1);
    }
    return secret;
}
//# sourceMappingURL=jwt.js.map