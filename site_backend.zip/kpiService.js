"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateProjectKPIs = calculateProjectKPIs;
exports.calculateOverallKPIs = calculateOverallKPIs;
const prisma_1 = require("../lib/prisma");
// Calculate ROI (Return on Investment)
function calculateROI(initialInvestment, currentValue) {
    if (initialInvestment === 0)
        return 0;
    return ((currentValue - initialInvestment) / initialInvestment) * 100;
}
// Calculate NPV (Net Present Value) - simplified version
function calculateNPV(cashFlows, discountRate = 0.1) {
    let npv = -cashFlows[0]; // Initial investment (negative)
    for (let i = 1; i < cashFlows.length; i++) {
        npv += cashFlows[i] / Math.pow(1 + discountRate, i);
    }
    return npv;
}
// Calculate IRR (Internal Rate of Return) - simplified approximation
function calculateIRR(cashFlows) {
    if (cashFlows.length < 2)
        return 0;
    // Simple approximation using trial and error
    let irr = 0.1; // Start with 10%
    let npv = calculateNPV(cashFlows, irr);
    let iterations = 0;
    const maxIterations = 100;
    while (Math.abs(npv) > 0.01 && iterations < maxIterations) {
        if (npv > 0) {
            irr += 0.01;
        }
        else {
            irr -= 0.01;
        }
        npv = calculateNPV(cashFlows, irr);
        iterations++;
    }
    return irr * 100; // Return as percentage
}
// Calculate Payback Period
function calculatePaybackPeriod(initialInvestment, cashFlows) {
    if (initialInvestment <= 0)
        return 0;
    let cumulativeCashFlow = -initialInvestment;
    let paybackPeriod = 0;
    for (let i = 0; i < cashFlows.length; i++) {
        cumulativeCashFlow += cashFlows[i];
        if (cumulativeCashFlow >= 0) {
            paybackPeriod = i + 1 - (cumulativeCashFlow - cashFlows[i]) / cashFlows[i];
            break;
        }
    }
    return paybackPeriod;
}
// Calculate Break-even Point
function calculateBreakEvenPoint(fixedCosts, variableCostPerUnit, pricePerUnit) {
    if (pricePerUnit - variableCostPerUnit === 0)
        return 0;
    return fixedCosts / (pricePerUnit - variableCostPerUnit);
}
async function calculateProjectKPIs(projectId) {
    const project = await prisma_1.prisma.project.findUnique({
        where: { id: projectId },
        include: {
            user: true,
        },
    });
    if (!project) {
        throw new Error('Project not found');
    }
    const initialInvestment = Number(project.initialInvestment);
    const monthlyRevenue = Number(project.monthlyRevenue);
    const monthlyExpenses = Number(project.monthlyExpenses);
    // Calculate current value (simplified - could be more complex)
    const monthsSinceStart = Math.max(1, Math.floor((Date.now() - project.startDate.getTime()) / (1000 * 60 * 60 * 24 * 30)));
    const totalRevenue = monthlyRevenue * monthsSinceStart;
    const totalExpenses = monthlyExpenses * monthsSinceStart;
    const currentValue = initialInvestment + (totalRevenue - totalExpenses);
    // ROI
    const roi = calculateROI(initialInvestment, currentValue);
    // NPV and IRR (simplified cash flow projection)
    const cashFlows = [initialInvestment]; // Initial investment (negative)
    for (let i = 1; i <= 12; i++) { // Project 12 months
        cashFlows.push(monthlyRevenue - monthlyExpenses);
    }
    const npv = calculateNPV(cashFlows);
    const irr = calculateIRR(cashFlows);
    // Profitability Ratio
    const profitabilityRatio = monthlyRevenue > 0 ? ((monthlyRevenue - monthlyExpenses) / monthlyRevenue) * 100 : 0;
    // Payback Period
    const paybackPeriod = calculatePaybackPeriod(initialInvestment, cashFlows.slice(1));
    // Break-even Point (simplified)
    const breakEvenPoint = calculateBreakEvenPoint(monthlyExpenses, monthlyExpenses * 0.3, monthlyRevenue); // Assuming 30% variable costs
    return {
        roi,
        irr,
        npv,
        profitabilityRatio,
        paybackPeriod,
        breakEvenPoint,
    };
}
async function calculateOverallKPIs(userId) {
    const projects = await prisma_1.prisma.project.findMany({
        where: { userId },
    });
    if (projects.length === 0) {
        return {
            totalROI: 0,
            averageIRR: 0,
            totalNPV: 0,
            portfolioProfitability: 0,
            riskAdjustedReturn: 0,
        };
    }
    let totalROI = 0;
    let totalIRR = 0;
    let totalNPV = 0;
    let totalInvestment = 0;
    for (const project of projects) {
        const kpis = await calculateProjectKPIs(project.id);
        totalROI += kpis.roi;
        totalIRR += kpis.irr;
        totalNPV += kpis.npv;
        totalInvestment += Number(project.initialInvestment);
    }
    const averageROI = totalROI / projects.length;
    const averageIRR = totalIRR / projects.length;
    const portfolioProfitability = totalInvestment > 0 ? (totalNPV / totalInvestment) * 100 : 0;
    // Risk-adjusted return (simplified - Sharpe ratio approximation)
    const riskAdjustedReturn = averageROI / 10; // Assuming 10% as benchmark risk
    return {
        totalROI: averageROI,
        averageIRR,
        totalNPV,
        portfolioProfitability,
        riskAdjustedReturn,
    };
}
//# sourceMappingURL=kpiService.js.map