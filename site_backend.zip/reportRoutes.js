"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const reportController_1 = require("../controllers/reportController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/summary', reportController_1.getFinancialSummary);
router.get('/category-breakdown', reportController_1.getCategoryBreakdown);
router.get('/monthly-trends', reportController_1.getMonthlyTrends);
router.get('/cash-flow', reportController_1.getCashFlow);
router.get('/risk-analysis', reportController_1.getRiskAnalysis);
router.get('/kpis', reportController_1.getProjectKPIs);
router.get('/kpis/:projectId', reportController_1.getProjectKPIs);
exports.default = router;
//# sourceMappingURL=reportRoutes.js.map