import { Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const receiptSchema = z.object({
  filePath: z.string().optional(),
  metadata: z.record(z.string(), z.any()).optional(),
});

export const getAllReceipts = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const receipts = await prisma.receipt.findMany({
      where: { userId },
      orderBy: { uploadedAt: 'desc' },
    });

    const serialized = JSON.parse(
      JSON.stringify(receipts, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching receipts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getReceiptById = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const receiptId = parseInt(req.params.id as string);

    const receipt = await prisma.receipt.findFirst({
      where: {
        id: receiptId,
        userId,
      },
    });

    if (!receipt) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    const serialized = JSON.parse(
      JSON.stringify(receipt, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching receipt:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createReceipt = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = receiptSchema.parse(req.body);

    const receipt = await prisma.receipt.create({
      data: {
        userId,
        filePath: data.filePath,
        metadata: data.metadata ? JSON.stringify(data.metadata) : null,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(receipt, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating receipt:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateReceipt = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const receiptId = parseInt(req.params.id as string);
    const data = receiptSchema.partial().parse(req.body);

    const existing = await prisma.receipt.findFirst({
      where: { id: receiptId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    const updated = await prisma.receipt.update({
      where: { id: receiptId },
      data: {
        ...(data.filePath !== undefined && { filePath: data.filePath }),
        ...(data.metadata !== undefined && { metadata: JSON.stringify(data.metadata) }),
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(updated, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error updating receipt:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteReceipt = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const receiptId = parseInt(req.params.id as string);

    const existing = await prisma.receipt.findFirst({
      where: { id: receiptId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    await prisma.receipt.delete({
      where: { id: receiptId },
    });

    res.json({ message: 'Receipt deleted successfully' });
  } catch (error) {
    console.error('Error deleting receipt:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
