import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getAllBudgetCategories: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getBudgetCategoryById: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createBudgetCategory: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateBudgetCategory: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteBudgetCategory: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getBudgetCategoryStats: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
