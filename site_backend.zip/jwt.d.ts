export declare function getJwtSecret(): string;
