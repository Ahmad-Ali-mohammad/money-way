"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const transactionController_1 = require("../controllers/transactionController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
// All transaction routes require authentication
router.use(authMiddleware_1.authenticate);
router.get('/', transactionController_1.getAllTransactions);
router.post('/', transactionController_1.createTransaction);
router.get('/stats', transactionController_1.getTransactionStats);
router.get('/:id', transactionController_1.getTransactionById);
router.put('/:id', transactionController_1.updateTransaction);
router.delete('/:id', transactionController_1.deleteTransaction);
exports.default = router;
//# sourceMappingURL=transactionRoutes.js.map