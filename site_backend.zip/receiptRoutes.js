"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMiddleware_1 = require("../middleware/authMiddleware");
const receiptController_1 = require("../controllers/receiptController");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(authMiddleware_1.authMiddleware);
router.get('/', receiptController_1.getAllReceipts);
router.get('/:id', receiptController_1.getReceiptById);
router.post('/', receiptController_1.createReceipt);
router.put('/:id', receiptController_1.updateReceipt);
router.delete('/:id', receiptController_1.deleteReceipt);
exports.default = router;
//# sourceMappingURL=receiptRoutes.js.map