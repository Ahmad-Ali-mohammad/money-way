import { beforeAll, afterAll } from 'vitest';
import bcrypt from 'bcrypt';
import { prisma } from '../lib/prisma';
import { seedUserData } from '../services/userService';

// Ensure test environment values
process.env.NODE_ENV = process.env.NODE_ENV || 'test';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-jwt-secret';

beforeAll(async () => {
  // Connect Prisma
  await prisma.$connect();

  // Ensure the seeded user exists for integration tests
  const email = 'ahmed@example.com';
  const password = 'password123';
  const passwordHash = await bcrypt.hash(password, 10);

  const user = await prisma.user.upsert({
    where: { email },
    update: { passwordHash },
    create: {
      email,
      passwordHash,
      name: 'أحمد محمد',
      currency: 'USD',
      incomePattern: 'salary',
    },
  });

  // Seed additional default data (categories, account, goal, etc.)
  try {
    await seedUserData(user.id);
  } catch (err) {
    // ignore if already seeded
    console.warn('Seeding user data may have failed or already run:', (err as Error).message);
  }
});

afterAll(async () => {
  // Disconnect Prisma after tests
  await prisma.$disconnect();
});
