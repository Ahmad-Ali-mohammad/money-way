# Test Authentication APIs
$baseUrl = "http://localhost:4000/api"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Testing Authentication APIs" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Test 1: Register New User
Write-Host "Test 1: Register New User" -ForegroundColor Yellow
Write-Host "----------------------------" -ForegroundColor Yellow

$registerData = @{
    email = "test@example.com"
    password = "password123"
    name = "Test User"
} | ConvertTo-Json

try {
    $registerResponse = Invoke-RestMethod -Uri "$baseUrl/auth/register" `
        -Method Post `
        -Body $registerData `
        -ContentType "application/json" `
        -ErrorAction Stop
    
    Write-Host "Registration Successful!" -ForegroundColor Green
    Write-Host "User ID: $($registerResponse.user.id)" -ForegroundColor Green
    Write-Host "Email: $($registerResponse.user.email)" -ForegroundColor Green
    Write-Host "Name: $($registerResponse.user.name)" -ForegroundColor Green
    Write-Host "Token: $($registerResponse.token.Substring(0, 20))..." -ForegroundColor Green
    
    $token = $registerResponse.token
} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    $errorBody = $_.ErrorDetails.Message | ConvertFrom-Json
    
    if ($statusCode -eq 400 -and $errorBody.error -eq "User already exists") {
        Write-Host "User already exists, will try to login instead" -ForegroundColor Yellow
        $userExists = $true
    } else {
        Write-Host "Registration Failed!" -ForegroundColor Red
        Write-Host "Status Code: $statusCode" -ForegroundColor Red
        Write-Host "Error: $($errorBody.error)" -ForegroundColor Red
        exit 1
    }
}

Write-Host ""

# Test 2: Login
Write-Host "Test 2: Login" -ForegroundColor Yellow
Write-Host "----------------" -ForegroundColor Yellow

$loginData = @{
    email = "test@example.com"
    password = "password123"
} | ConvertTo-Json

try {
    $loginResponse = Invoke-RestMethod -Uri "$baseUrl/auth/login" `
        -Method Post `
        -Body $loginData `
        -ContentType "application/json" `
        -ErrorAction Stop
    
    Write-Host "Login Successful!" -ForegroundColor Green
    Write-Host "User ID: $($loginResponse.user.id)" -ForegroundColor Green
    Write-Host "Email: $($loginResponse.user.email)" -ForegroundColor Green
    Write-Host "Name: $($loginResponse.user.name)" -ForegroundColor Green
    Write-Host "Token: $($loginResponse.token.Substring(0, 20))..." -ForegroundColor Green
    
    $token = $loginResponse.token
} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    try {
        $errorBody = $_.ErrorDetails.Message | ConvertFrom-Json
        Write-Host "Login Failed!" -ForegroundColor Red
        Write-Host "Status Code: $statusCode" -ForegroundColor Red
        Write-Host "Error: $($errorBody.error)" -ForegroundColor Red
    } catch {
        Write-Host "Login Failed!" -ForegroundColor Red
        Write-Host "Status Code: $statusCode" -ForegroundColor Red
        Write-Host "Error Details: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
    exit 1
}

Write-Host ""

# Test 3: Access Protected Route
Write-Host "Test 3: Access Protected Route" -ForegroundColor Yellow
Write-Host "---------------------------------------------------" -ForegroundColor Yellow

try {
    $headers = @{
        "Authorization" = "Bearer $token"
    }
    
    $profileResponse = Invoke-RestMethod -Uri "$baseUrl/users/profile" `
        -Method Get `
        -Headers $headers `
        -ErrorAction Stop
    
    Write-Host "Protected Route Access Successful!" -ForegroundColor Green
    Write-Host "User ID: $($profileResponse.id)" -ForegroundColor Green
    Write-Host "Email: $($profileResponse.email)" -ForegroundColor Green
    Write-Host "Name: $($profileResponse.name)" -ForegroundColor Green
} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    Write-Host "Protected Route Test: Status $statusCode" -ForegroundColor Yellow
    if ($statusCode -eq 404) {
        Write-Host "   Note: /users/profile endpoint may not be implemented yet" -ForegroundColor Gray
    } else {
        Write-Host "   Error: $($_.ErrorDetails.Message)" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Authentication Tests Completed!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Summary:" -ForegroundColor White
Write-Host "   - Backend running on: $baseUrl" -ForegroundColor White
Write-Host "   - Test user email: test@example.com" -ForegroundColor White
Write-Host "   - Test user password: password123" -ForegroundColor White
Write-Host ""
