"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const alertController_1 = require("../controllers/alertController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/', alertController_1.getAllAlerts);
router.post('/', alertController_1.createAlert);
router.get('/unread-count', alertController_1.getUnreadCount);
router.put('/:id/read', alertController_1.markAsRead);
router.patch('/:id/read', alertController_1.markAsRead);
router.put('/mark-all-read', alertController_1.markAllAsRead);
router.delete('/:id', alertController_1.deleteAlert);
// Smart alert generation endpoints
router.post('/check-budgets', alertController_1.checkBudgetAlerts);
router.post('/check-goals', alertController_1.checkGoalAlerts);
exports.default = router;
//# sourceMappingURL=alertRoutes.js.map