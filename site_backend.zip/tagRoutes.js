"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const tagController_1 = require("../controllers/tagController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/', tagController_1.getAllTags);
router.post('/', tagController_1.createTag);
router.put('/:id', tagController_1.updateTag);
router.delete('/:id', tagController_1.deleteTag);
router.post('/link', tagController_1.addTagToTransaction);
router.delete('/link/:transactionId/:tagId', tagController_1.removeTagFromTransaction);
exports.default = router;
//# sourceMappingURL=tagRoutes.js.map