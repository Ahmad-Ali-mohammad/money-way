import { describe, test, expect, vi, beforeEach, afterEach } from 'vitest';

import * as controller from '../../controllers/goalTransactionController';
import { prisma } from '../../lib/prisma';

vi.mock('../../lib/prisma', () => ({
  prisma: {
    goal: {
      findFirst: vi.fn(),
      update: vi.fn(),
    },
    goalTransaction: {
      findMany: vi.fn(),
      findFirst: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
    $transaction: vi.fn(),
  }
}));

const mockPrisma: any = prisma as any;

describe('Goal Transaction Controller (unit)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  test('createGoalTransaction calls prisma transaction and updates goal', async () => {
    const req: any = { user: { userId: 1 }, body: { goalId: 10, amount: 100 } };
    const res: any = { status: vi.fn().mockReturnThis(), json: vi.fn() };

    mockPrisma.goal.findFirst.mockResolvedValue({ id: 10, userId: 1 });

    // simulate $transaction calling callback with tx whose methods are proxied to prisma
    mockPrisma.$transaction.mockImplementation(async (cb: any) => {
      const tx = {
        goalTransaction: { create: mockPrisma.goalTransaction.create },
        goal: { update: mockPrisma.goal.update },
      };
      return cb(tx);
    });

    mockPrisma.goalTransaction.create.mockResolvedValue({ id: 1, goalId: 10, amount: 100 });
    mockPrisma.goal.update.mockResolvedValue({ id: 10, currentAmount: 100 });

    await controller.createGoalTransaction(req, res);

    expect(mockPrisma.goal.findFirst).toHaveBeenCalledWith({ where: { id: 10, userId: 1 } });
    expect(mockPrisma.$transaction).toHaveBeenCalled();
    expect(mockPrisma.goalTransaction.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ goalId: 10, amount: 100 }),
    });
    expect(mockPrisma.goal.update).toHaveBeenCalledWith({ where: { id: 10 }, data: { currentAmount: { increment: 100 } } });
    expect(res.status).toHaveBeenCalledWith(201);
  });

  test('updateGoalTransaction adjusts goal by delta', async () => {
    const req: any = { user: { userId: 1 }, params: { id: '5' }, body: { amount: 250 } };
    const res: any = { status: vi.fn().mockReturnThis(), json: vi.fn() };

    mockPrisma.$transaction.mockImplementation(async (cb: any) => {
      const tx = {
        goalTransaction: { findFirst: mockPrisma.goalTransaction.findFirst, update: mockPrisma.goalTransaction.update },
        goal: { update: mockPrisma.goal.update },
      };
      return cb(tx);
    });

    mockPrisma.goalTransaction.findFirst.mockResolvedValue({ id: 5, amount: 100, goalId: 10, goal: { userId: 1 } });
    mockPrisma.goal.update.mockResolvedValue({ id: 10, currentAmount: 250 });
    mockPrisma.goalTransaction.update.mockResolvedValue({ id: 5, amount: 250 });

    await controller.updateGoalTransaction(req, res);

    expect(mockPrisma.goalTransaction.findFirst).toHaveBeenCalledWith({ where: { id: 5 }, include: { goal: true } });
    expect(mockPrisma.goal.update).toHaveBeenCalledWith({ where: { id: 10 }, data: { currentAmount: { increment: 150 } } });
    expect(mockPrisma.goalTransaction.update).toHaveBeenCalled();
    expect(res.json).toHaveBeenCalled();
  });

  test('deleteGoalTransaction decrements and deletes', async () => {
    const req: any = { user: { userId: 1 }, params: { id: '6' } };
    const res: any = { status: vi.fn().mockReturnThis(), json: vi.fn() };

    mockPrisma.$transaction.mockImplementation(async (cb: any) => {
      const tx = {
        goalTransaction: { findFirst: mockPrisma.goalTransaction.findFirst, delete: mockPrisma.goalTransaction.delete },
        goal: { update: mockPrisma.goal.update },
      };
      return cb(tx);
    });

    mockPrisma.goalTransaction.findFirst.mockResolvedValue({ id: 6, amount: 150, goalId: 10, goal: { userId: 1 } });
    mockPrisma.goal.update.mockResolvedValue({ id: 10, currentAmount: 0 });
    mockPrisma.goalTransaction.delete.mockResolvedValue({ id: 6 });

    await controller.deleteGoalTransaction(req, res);

    expect(mockPrisma.goalTransaction.findFirst).toHaveBeenCalledWith({ where: { id: 6 }, include: { goal: true } });
    expect(mockPrisma.goal.update).toHaveBeenCalledWith({ where: { id: 10 }, data: { currentAmount: { decrement: 150 } } });
    expect(mockPrisma.goalTransaction.delete).toHaveBeenCalledWith({ where: { id: 6 } });
    expect(res.json).toHaveBeenCalledWith({ message: 'Goal transaction deleted successfully' });
  });
});
