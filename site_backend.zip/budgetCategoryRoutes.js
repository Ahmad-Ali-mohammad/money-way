"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMiddleware_1 = require("../middleware/authMiddleware");
const budgetCategoryController_1 = require("../controllers/budgetCategoryController");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(authMiddleware_1.authenticate);
// Budget Category routes
router.get('/', budgetCategoryController_1.getAllBudgetCategories);
router.get('/:id', budgetCategoryController_1.getBudgetCategoryById);
router.post('/', budgetCategoryController_1.createBudgetCategory);
router.put('/:id', budgetCategoryController_1.updateBudgetCategory);
router.delete('/:id', budgetCategoryController_1.deleteBudgetCategory);
router.get('/:id/stats', budgetCategoryController_1.getBudgetCategoryStats);
exports.default = router;
//# sourceMappingURL=budgetCategoryRoutes.js.map