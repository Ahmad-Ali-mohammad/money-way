# Advanced Features Implementation Guide
**تطبيق الميزات المتقدمة**

Date: January 13, 2026  
Version: 2.0.0

---

## 📋 Summary (الملخص)

تم تنفيذ **3 ميزات متقدمة رئيسية** في Backend:

1. **✅ Adaptive Budget System** - نظام ميزانية ذكي يتكيف تلقائياً
2. **✅ Recurring Transactions** - معاملات متكررة تلقائية
3. **✅ Tag System** - نظام تصنيف مرن منفصل

---

## 1. Adaptive Budget System 💡

### الوصف
نظام ميزانية ذكي يحسب المبالغ تلقائياً بناءً على الدخل الشهري مع دعم القيود (min/max).

### الميزات
- **Percentage-based Budgets**: ميزانيات بالنسبة المئوية من الدخل
- **Auto-calculation**: حساب تلقائي عند كل طلب
- **Min/Max Constraints**: قيود دنيا وعليا
- **Surplus Transfer**: تحويل الفائض (>10%) للأهداف الادخارية

### ملفات التنفيذ
```
backend/src/
├── services/adaptiveBudgetService.ts (NEW)
│   ├── calculateAdaptiveBudgetAmount()
│   ├── recalculateAllAdaptiveBudgets()
│   └── checkBudgetSurplusTransfer()
├── controllers/budgetController.ts (UPDATED)
│   ├── recalculateBudgets() endpoint
│   └── processSurplusTransfer() endpoint
└── routes/budgetRoutes.ts (UPDATED)
```

### Schema Changes
```prisma
model Budget {
  isAdaptive    Boolean   @default(false)
  isPercentage  Boolean   @default(false)
  percentage    Decimal?  @db.Decimal(5, 2)
  adaptiveRule  String?   // JSON: {basePercentage, minAmount, maxAmount}
}
```

### API Endpoints
```
GET  /api/budgets/recalculate        - إعادة حساب كل الميزانيات
POST /api/budgets/surplus-transfer   - تحويل الفائض للأهداف
GET  /api/budgets/:id/progress       - عرض التقدم مع الحساب التلقائي
```

### مثال استخدام

#### إنشاء ميزانية نسبية:
```json
POST /api/budgets
{
  "name": "Groceries",
  "categoryId": "1",
  "isAdaptive": true,
  "isPercentage": true,
  "percentage": 15,
  "adaptiveRule": "{\"basePercentage\":15,\"minAmount\":500,\"maxAmount\":2000}"
}
```

#### النتيجة:
- إذا كان الدخل الشهري = **5000$**
- الميزانية = 15% × 5000 = **750$**
- إذا أنفق المستخدم **600$**
- الفائض = 150$ (20%)
- يتم تحويله تلقائياً لأول هدف ادخاري

### الخوارزمية
```typescript
if (budget.isPercentage && budget.percentage) {
  const monthIncome = getCurrentMonthIncome(userId);
  let amount = (monthIncome * percentage) / 100;
  
  const rule = JSON.parse(budget.adaptiveRule);
  if (rule.minAmount && amount < rule.minAmount) amount = rule.minAmount;
  if (rule.maxAmount && amount > rule.maxAmount) amount = rule.maxAmount;
  
  return amount;
}
```

---

## 2. Recurring Transactions 🔄

### الوصف
نظام آلي لتوليد المعاملات المتكررة (إيجار، اشتراكات، رواتب) بدون تدخل المستخدم.

### الميزات
- **4 أنواع تكرار**: يومي، أسبوعي، شهري، سنوي
- **Flexible Rules**: قواعد مرنة (يوم محدد من الشهر/الأسبوع)
- **Auto Balance Update**: تحديث الرصيد تلقائياً
- **Alert Creation**: إنشاء تنبيهات عند التنفيذ

### ملفات التنفيذ
```
backend/src/
├── services/recurringScheduler.ts (NEW)
│   ├── processRecurringTransactions()
│   ├── startRecurringTransactionsScheduler()
│   └── calculateNextOccurrence()
└── index.ts (UPDATED)
    └── Starts scheduler on server boot
```

### Schema Changes
```prisma
model Transaction {
  isRecurring        Boolean   @default(false)
  recurrenceRule     String?   // JSON: {frequency, interval, dayOfWeek, etc}
  nextOccurrence     DateTime?
  recurringParentId  BigInt?
  recurringChildren  Transaction[] @relation("RecurringTransactions")
  recurringParent    Transaction?  @relation("RecurringTransactions")
}
```

### Scheduler Configuration
- **Cron Schedule**: `5 0 * * *` (يومياً في 00:05 صباحاً)
- **Library**: `node-cron@3.0.3`

### مثال استخدام

#### إنشاء معاملة متكررة:
```json
POST /api/transactions
{
  "amount": 1200,
  "type": "expense",
  "accountId": "1",
  "categoryId": "5",
  "notes": "Monthly Rent",
  "isRecurring": true,
  "recurrenceRule": "{\"frequency\":\"monthly\",\"interval\":1,\"dayOfMonth\":1}"
}
```

#### السلوك:
1. يتم إنشاء المعاملة كـ **template**
2. كل شهر في اليوم الأول (00:05 صباحاً):
   - يُنشئ نسخة جديدة من المعاملة
   - يخصم 1200$ من الحساب
   - يُحدث `nextOccurrence` للشهر التالي
   - يُنشئ تنبيه للمستخدم

### قواعد التكرار

```typescript
interface RecurrenceRule {
  frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
  interval?: number;      // كل N يوم/أسبوع/شهر
  dayOfWeek?: number;     // للأسبوعي (0=Sunday, 6=Saturday)
  dayOfMonth?: number;    // للشهري (1-31)
  monthOfYear?: number;   // للسنوي (1-12)
}
```

### أمثلة إضافية

**راتب نصف شهري:**
```json
{
  "recurrenceRule": "{\"frequency\":\"monthly\",\"interval\":0.5,\"dayOfMonth\":15}"
}
```

**اشتراك Netflix أسبوعي:**
```json
{
  "recurrenceRule": "{\"frequency\":\"weekly\",\"interval\":1,\"dayOfWeek\":5}"
}
```

---

## 3. Tag System 🏷️

### الوصف
نظام تصنيف مستقل عن Categories، يسمح بربط عدة tags لكل transaction.

### الميزات
- **Separate Model**: جدول منفصل (لم يعد JSON)
- **Many-to-Many**: علاقة متعددة عبر `TransactionTag`
- **Color Support**: دعم الألوان للواجهة
- **Usage Tracking**: عدد الاستخدامات لكل tag

### ملفات التنفيذ
```
backend/src/
├── controllers/tagController.ts (NEW)
│   ├── getAllTags()
│   ├── createTag()
│   ├── updateTag()
│   ├── deleteTag()
│   ├── addTagToTransaction()
│   └── removeTagFromTransaction()
└── routes/tagRoutes.ts (NEW)
```

### Schema Changes
```prisma
model Tag {
  id           BigInt           @id @default(autoincrement())
  userId       BigInt
  name         String
  color        String?
  createdAt    DateTime
  transactions TransactionTag[]
  
  @@unique([userId, name])
}

model TransactionTag {
  transactionId BigInt
  tagId         BigInt
  createdAt     DateTime
  
  @@id([transactionId, tagId])
}
```

### API Endpoints
```
GET    /api/tags                           - جلب كل الـtags مع عدد الاستخدام
POST   /api/tags                           - إنشاء tag جديد
PUT    /api/tags/:id                       - تحديث tag
DELETE /api/tags/:id                       - حذف tag
POST   /api/tags/link                      - ربط tag بـtransaction
DELETE /api/tags/link/:transactionId/:tagId - إلغاء الربط
```

### مثال استخدام

#### 1. إنشاء tags:
```json
POST /api/tags
{
  "name": "Business",
  "color": "#4CAF50"
}

POST /api/tags
{
  "name": "Tax Deductible",
  "color": "#FF9800"
}
```

#### 2. ربط tags بمعاملة:
```json
POST /api/tags/link
{
  "transactionId": "123",
  "tagId": "1"
}

POST /api/tags/link
{
  "transactionId": "123",
  "tagId": "2"
}
```

#### 3. جلب كل الـtags:
```json
GET /api/tags

Response:
[
  {
    "id": "1",
    "name": "Business",
    "color": "#4CAF50",
    "_count": {
      "transactions": 15
    }
  },
  {
    "id": "2",
    "name": "Tax Deductible",
    "color": "#FF9800",
    "_count": {
      "transactions": 8
    }
  }
]
```

---

## 🔄 Migration Guide (دليل الترحيل)

### 1. Update Dependencies
```bash
cd backend
npm install
# node-cron و @types/node-cron تمت إضافتهما تلقائياً
```

### 2. Apply Database Migration
```bash
psql -U postgres -d finance_db -f prisma/migrations/V2__advanced_features.sql
```

**ما سيحدث:**
- إضافة أعمدة جديدة لـBudgets (isAdaptive, isPercentage, etc)
- إضافة أعمدة جديدة لـTransactions (nextOccurrence, recurringParentId)
- إنشاء جدولي Tag و TransactionTag
- نقل البيانات الموجودة من `tags` (JSON) إلى الجدول الجديد
- تحديث Project و Alert models

### 3. Regenerate Prisma Client
```bash
npx prisma generate
```

### 4. Start Server
```bash
npm run dev
```

**Output Expected:**
```
🚀 Backend server running on http://localhost:4000
📊 API available at http://localhost:4000/api
⏰ Recurring transactions scheduler active
[Scheduler] Recurring transactions scheduler started (runs daily at 00:05 AM)
```

---

## 🧪 Testing Scenarios

### Test 1: Adaptive Budget
```bash
# 1. Create percentage-based budget
POST /api/budgets
{
  "name": "Food",
  "isAdaptive": true,
  "isPercentage": true,
  "percentage": 20,
  "categoryId": "1"
}

# 2. Add income
POST /api/transactions
{
  "amount": 5000,
  "type": "income",
  "accountId": "1"
}

# 3. Check budget (should be 1000 = 20% of 5000)
GET /api/budgets/:id/progress

# 4. Add expense
POST /api/transactions
{
  "amount": 800,
  "type": "expense",
  "categoryId": "1",
  "accountId": "1"
}

# 5. Check surplus (200 remaining = 20%)
POST /api/budgets/surplus-transfer
# Should transfer 200 to first goal
```

### Test 2: Recurring Transaction
```bash
# 1. Create recurring template
POST /api/transactions
{
  "amount": 50,
  "type": "expense",
  "accountId": "1",
  "notes": "Netflix Subscription",
  "isRecurring": true,
  "recurrenceRule": "{\"frequency\":\"monthly\",\"interval\":1}"
}

# 2. Wait for scheduler (or trigger manually in code)
# processRecurringTransactions()

# 3. Verify new transaction created
GET /api/transactions
# Should show original + auto-generated copy
```

### Test 3: Tags
```bash
# 1. Create tags
POST /api/tags {"name": "Work", "color": "#2196F3"}
POST /api/tags {"name": "Personal", "color": "#9C27B0"}

# 2. Create transaction
POST /api/transactions {...}

# 3. Link tags
POST /api/tags/link {"transactionId": "1", "tagId": "1"}
POST /api/tags/link {"transactionId": "1", "tagId": "2"}

# 4. Get transaction with tags
GET /api/transactions/1
# Should include tags array via TransactionTag relation
```

---

## 📊 Performance Considerations

### Adaptive Budget Service
- **Caching**: يحسب على الطلب، يُنصح بـcaching لـ5 دقائق
- **Query Optimization**: يستخدم aggregate() بدلاً من findMany
- **Batch Processing**: recalculateAll يعالج دفعة واحدة

### Recurring Scheduler
- **Batch Size**: يعالج كل المعاملات المستحقة دفعة واحدة
- **Error Handling**: كل transaction معزول (error في واحد لا يؤثر على الباقي)
- **Monitoring**: يسجل logs لكل عملية

### Tag System
- **Indexes**: فهرس على (userId, isRead) للسرعة
- **Cascade Delete**: حذف tag يحذف كل الروابط تلقائياً
- **Unique Constraint**: منع تكرار الأسماء لنفس المستخدم

---

## 🔮 Future Enhancements

### V2.1 (قريباً)
- [ ] **Adaptive Rules UI**: واجهة بصرية لتصميم قواعد التكيف
- [ ] **Recurring Schedule Preview**: عرض الـ10 تواريخ القادمة
- [ ] **Tag Auto-suggestion**: اقتراح tags بناءً على النص

### V3.0 (مستقبلاً)
- [ ] **ML-based Adaptation**: تكيف ذكي بالـML بدلاً من القواعد
- [ ] **Smart Recurrence Detection**: اكتشاف تلقائي للمعاملات المتكررة
- [ ] **Tag Clustering**: تجميع tags متشابهة

---

## 📝 Changelog

### v2.0.0 - January 13, 2026
**Added:**
- ✅ Adaptive Budget System with percentage-based calculation
- ✅ Recurring Transactions Scheduler (node-cron)
- ✅ Tag System as separate relational model
- ✅ Surplus auto-transfer to goals
- ✅ 10 new API endpoints

**Changed:**
- Updated Budget model (5 new fields)
- Updated Transaction model (3 new fields)
- Updated Alert model (simplified structure)
- Updated Project model (standardized fields)

**Migration:**
- V2__advanced_features.sql

**Dependencies:**
- Added node-cron@3.0.3
- Added @types/node-cron@3.0.11

---

**Built with ❤️ for AdaptiveFi**  
**التطوير بحب لـ AdaptiveFi**
