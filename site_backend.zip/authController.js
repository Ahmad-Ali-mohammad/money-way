"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateProfile = exports.getProfile = exports.googleAuth = exports.login = exports.register = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const userService_1 = require("../services/userService");
const jwt_1 = require("../lib/jwt");
const registerSchema = zod_1.z.object({
    email: zod_1.z.string().email(),
    password: zod_1.z.string().min(6),
    name: zod_1.z.string().optional(),
    incomePattern: zod_1.z.string().optional(),
    currency: zod_1.z.string().optional(),
});
const loginSchema = zod_1.z.object({
    email: zod_1.z.string().email(),
    password: zod_1.z.string(),
});
const googleAuthSchema = zod_1.z.object({
    token: zod_1.z.string(),
    email: zod_1.z.string().email(),
    name: zod_1.z.string().optional(),
    picture: zod_1.z.string().optional(),
});
const register = async (req, res) => {
    try {
        const { email, password, name, incomePattern, currency } = registerSchema.parse(req.body);
        const existingUser = await prisma_1.prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists' });
        }
        const passwordHash = await bcrypt_1.default.hash(password, 10);
        const user = await prisma_1.prisma.user.create({
            data: {
                email,
                passwordHash,
                name,
                incomePattern,
                currency: currency || 'USD',
            },
        });
        // Seed default data for new user experience
        await (0, userService_1.seedUserData)(user.id);
        const token = jsonwebtoken_1.default.sign({ userId: user.id }, (0, jwt_1.getJwtSecret)(), { expiresIn: '24h' });
        res.status(201).json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
            },
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', '),
                details: error.issues
            });
        }
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.register = register;
const login = async (req, res) => {
    try {
        const { email, password } = loginSchema.parse(req.body);
        const user = await prisma_1.prisma.user.findUnique({ where: { email } });
        if (!user || !user.passwordHash) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const isMatch = await bcrypt_1.default.compare(password, user.passwordHash);
        if (!isMatch) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const token = jsonwebtoken_1.default.sign({ userId: user.id }, (0, jwt_1.getJwtSecret)(), { expiresIn: '24h' });
        res.json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
            },
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', '),
                details: error.issues
            });
        }
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.login = login;
const googleAuth = async (req, res) => {
    try {
        console.log('Google Auth Request:', req.body);
        const { email, name, picture, token: googleToken } = req.body;
        // Validate required fields
        if (!email || !name) {
            return res.status(400).json({
                error: 'Missing required fields: email and name are required'
            });
        }
        // Check if user exists
        let user = await prisma_1.prisma.user.findUnique({ where: { email } });
        if (!user) {
            // Create new user for Google OAuth
            user = await prisma_1.prisma.user.create({
                data: {
                    email,
                    name: name || email.split('@')[0],
                    passwordHash: '', // No password for OAuth users
                    currency: 'USD',
                    incomePattern: 'regular',
                },
            });
            console.log('Created new Google user:', user.id);
            // Seed default data for new user
            await (0, userService_1.seedUserData)(user.id);
        }
        else {
            console.log('Existing Google user logged in:', user.id);
        }
        // Generate JWT token
        const token = jsonwebtoken_1.default.sign({ userId: user.id }, (0, jwt_1.getJwtSecret)(), { expiresIn: '24h' });
        res.json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
            },
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.googleAuth = googleAuth;
const getProfile = async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        const user = await prisma_1.prisma.user.findUnique({
            where: { id: userId },
            select: {
                id: true,
                email: true,
                name: true,
                currency: true,
                incomePattern: true,
                createdAt: true,
            },
        });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Provide default values for optional fields
        res.json({
            id: user.id,
            email: user.email,
            name: user.name || 'User',
            currency: user.currency || 'USD',
            incomePattern: user.incomePattern || 'fixed',
            createdAt: user.createdAt,
        });
    }
    catch (error) {
        console.error('Profile error:', error);
        res.status(500).json({ error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getProfile = getProfile;
const updateProfile = async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        const updateSchema = zod_1.z.object({
            name: zod_1.z.string().optional(),
            email: zod_1.z.string().email().optional(),
            currency: zod_1.z.string().optional(),
            incomePattern: zod_1.z.string().optional(),
            currentPassword: zod_1.z.string().optional(),
            newPassword: zod_1.z.string().min(6).optional(),
        });
        const data = updateSchema.parse(req.body);
        // If changing password, verify current password
        if (data.newPassword && data.currentPassword) {
            const user = await prisma_1.prisma.user.findUnique({ where: { id: userId } });
            if (!user || !user.passwordHash) {
                return res.status(400).json({ error: 'Cannot change password' });
            }
            const isMatch = await bcrypt_1.default.compare(data.currentPassword, user.passwordHash);
            if (!isMatch) {
                return res.status(401).json({ error: 'Current password is incorrect' });
            }
            const passwordHash = await bcrypt_1.default.hash(data.newPassword, 10);
            await prisma_1.prisma.user.update({
                where: { id: userId },
                data: { passwordHash },
            });
        }
        // Update other fields
        const updateData = {};
        if (data.name !== undefined)
            updateData.name = data.name;
        if (data.email !== undefined) {
            // Check if email is already taken
            const existingUser = await prisma_1.prisma.user.findUnique({ where: { email: data.email } });
            if (existingUser && existingUser.id !== userId) {
                return res.status(400).json({ error: 'Email already in use' });
            }
            updateData.email = data.email;
        }
        if (data.currency !== undefined)
            updateData.currency = data.currency;
        if (data.incomePattern !== undefined)
            updateData.incomePattern = data.incomePattern;
        const updatedUser = await prisma_1.prisma.user.update({
            where: { id: userId },
            data: updateData,
            select: {
                id: true,
                email: true,
                name: true,
                currency: true,
                incomePattern: true,
                createdAt: true,
            },
        });
        res.json(updatedUser);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', '),
                details: error.issues
            });
        }
        console.error('Update profile error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateProfile = updateProfile;
//# sourceMappingURL=authController.js.map