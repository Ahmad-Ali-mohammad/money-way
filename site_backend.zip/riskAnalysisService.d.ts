export interface RiskMetrics {
    debtToIncomeRatio: number;
    savingsRate: number;
    liquidityRatio: number;
    financialStressIndex: number;
    riskLevel: 'low' | 'medium' | 'high';
    recommendations: string[];
}
export declare function calculateRiskMetrics(userId: number): Promise<RiskMetrics>;
