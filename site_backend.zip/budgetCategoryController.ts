import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const budgetCategorySchema = z.object({
  name: z.string().min(1, 'Category name is required'),
  type: z.enum(['expense', 'income']).default('expense'),
  parentId: z.number().optional().nullable(),
  icon: z.string().optional(),
  color: z.string().optional(),
  description: z.string().optional(),
});

// Get all budget categories for the authenticated user
export const getAllBudgetCategories = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    // Get user's custom categories plus default system categories
    const categories = await prisma.category.findMany({
      where: {
        OR: [
          { userId: userId },
          { userId: null } // System default categories
        ]
      },
      include: {
        parent: true,
        children: true,
        _count: {
          select: {
            transactions: true,
            budgets: true,
          }
        }
      },
      orderBy: [
        { type: 'asc' },
        { name: 'asc' }
      ],
    });

    // Serialize BigInt values
    const serialized = JSON.parse(
      JSON.stringify(categories, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching budget categories:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get a single budget category by ID
export const getBudgetCategoryById = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(String(req.params.id));

    if (isNaN(categoryId)) {
      return res.status(400).json({ error: 'Invalid category ID' });
    }

    const category = await prisma.category.findFirst({
      where: {
        id: categoryId,
        OR: [
          { userId: userId },
          { userId: null } // Allow access to system categories
        ]
      },
      include: {
        parent: true,
        children: true,
        _count: {
          select: {
            transactions: true,
            budgets: true,
          }
        }
      },
    });

    if (!category) {
      return res.status(404).json({ error: 'Budget category not found' });
    }

    const serialized = JSON.parse(
      JSON.stringify(category, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching budget category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Create a new budget category
export const createBudgetCategory = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const validatedData = budgetCategorySchema.parse(req.body);

    // Check if parent category exists and belongs to user (if parentId provided)
    if (validatedData.parentId) {
      const parentCategory = await prisma.category.findFirst({
        where: {
          id: validatedData.parentId,
          OR: [
            { userId: userId },
            { userId: null }
          ]
        }
      });

      if (!parentCategory) {
        return res.status(404).json({ error: 'Parent category not found' });
      }
    }

    // Check if category with same name already exists for this user
    const existingCategory = await prisma.category.findFirst({
      where: {
        name: validatedData.name,
        userId: userId,
      }
    });

    if (existingCategory) {
      return res.status(400).json({ error: 'Category with this name already exists' });
    }

    const category = await prisma.category.create({
      data: {
        userId,
        name: validatedData.name,
        type: validatedData.type,
        parentId: validatedData.parentId,
      },
      include: {
        parent: true,
        children: true,
        _count: {
          select: {
            transactions: true,
            budgets: true,
          }
        }
      }
    });

    const serialized = JSON.parse(
      JSON.stringify(category, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating budget category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update a budget category
export const updateBudgetCategory = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(String(req.params.id));

    if (isNaN(categoryId)) {
      return res.status(400).json({ error: 'Invalid category ID' });
    }

    const validatedData = budgetCategorySchema.partial().parse(req.body);

    // Check if category exists and belongs to user
    const existingCategory = await prisma.category.findFirst({
      where: {
        id: categoryId,
        userId: userId, // User can only update their own categories
      }
    });

    if (!existingCategory) {
      return res.status(404).json({ error: 'Budget category not found or cannot be modified' });
    }

    // Check if parent category exists (if parentId provided)
    if (validatedData.parentId !== undefined) {
      if (validatedData.parentId === categoryId) {
        return res.status(400).json({ error: 'Category cannot be its own parent' });
      }

      if (validatedData.parentId) {
        const parentCategory = await prisma.category.findFirst({
          where: {
            id: validatedData.parentId,
            OR: [
              { userId: userId },
              { userId: null }
            ]
          }
        });

        if (!parentCategory) {
          return res.status(404).json({ error: 'Parent category not found' });
        }
      }
    }

    // Check if new name conflicts with existing category
    if (validatedData.name && validatedData.name !== existingCategory.name) {
      const duplicateCategory = await prisma.category.findFirst({
        where: {
          name: validatedData.name,
          userId: userId,
          id: { not: categoryId }
        }
      });

      if (duplicateCategory) {
        return res.status(400).json({ error: 'Category with this name already exists' });
      }
    }

    const updatedCategory = await prisma.category.update({
      where: { id: categoryId },
      data: validatedData,
      include: {
        parent: true,
        children: true,
        _count: {
          select: {
            transactions: true,
            budgets: true,
          }
        }
      }
    });

    const serialized = JSON.parse(
      JSON.stringify(updatedCategory, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error updating budget category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Delete a budget category
export const deleteBudgetCategory = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(String(req.params.id));

    if (isNaN(categoryId)) {
      return res.status(400).json({ error: 'Invalid category ID' });
    }

    // Check if category exists and belongs to user
    const existingCategory = await prisma.category.findFirst({
      where: {
        id: categoryId,
        userId: userId, // User can only delete their own categories
      },
      include: {
        _count: {
          select: {
            transactions: true,
            budgets: true,
            children: true,
          }
        }
      }
    });

    if (!existingCategory) {
      return res.status(404).json({ error: 'Budget category not found or cannot be deleted' });
    }

    // Check if category has transactions or budgets
    if (existingCategory._count.transactions > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete category with existing transactions',
        transactionCount: existingCategory._count.transactions
      });
    }

    if (existingCategory._count.budgets > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete category with existing budgets',
        budgetCount: existingCategory._count.budgets
      });
    }

    if (existingCategory._count.children > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete category with subcategories',
        subcategoryCount: existingCategory._count.children
      });
    }

    await prisma.category.delete({
      where: { id: categoryId }
    });

    res.json({ message: 'Budget category deleted successfully' });
  } catch (error) {
    console.error('Error deleting budget category:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get budget category statistics
export const getBudgetCategoryStats = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const categoryId = parseInt(String(req.params.id));

    if (isNaN(categoryId)) {
      return res.status(400).json({ error: 'Invalid category ID' });
    }

    const category = await prisma.category.findFirst({
      where: {
        id: categoryId,
        OR: [
          { userId: userId },
          { userId: null }
        ]
      }
    });

    if (!category) {
      return res.status(404).json({ error: 'Budget category not found' });
    }

    // Get transaction statistics
    const transactions = await prisma.transaction.findMany({
      where: {
        userId: userId,
        categoryId: categoryId,
      },
      select: {
        amount: true,
        type: true,
      }
    });

    const totalSpent = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalIncome = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    // Get active budgets for this category
    const budgets = await prisma.budget.findMany({
      where: {
        userId: userId,
        categoryId: categoryId,
        active: true,
      }
    });

    const totalBudgeted = budgets.reduce((sum, b) => sum + b.amount, 0);
    const totalBudgetSpent = budgets.reduce((sum, b) => sum + b.spent, 0);

    res.json({
      categoryId,
      categoryName: category.name,
      transactionCount: transactions.length,
      totalSpent,
      totalIncome,
      budgetCount: budgets.length,
      totalBudgeted,
      totalBudgetSpent,
      budgetUtilization: totalBudgeted > 0 ? (totalBudgetSpent / totalBudgeted) * 100 : 0
    });
  } catch (error) {
    console.error('Error fetching budget category stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
