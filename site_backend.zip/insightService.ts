import { prisma } from '../lib/prisma';

export interface Insight {
    type: 'income_spike' | 'budget_warning' | 'recurring_detect' | 'stability_high' | 'general';
    message: string;
    action?: string;
}

export async function generateSmartInsights(userId: number): Promise<Insight[]> {
    const insights: Insight[] = [];

    const now = new Date();
    const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(now.getMonth() - 3);

    // 1. Check for Income Spike
    const currentMonthIncome = await prisma.transaction.aggregate({
        where: { userId, type: 'income', occurredAt: { gte: currentMonthStart } },
        _sum: { amount: true }
    });

    const totalIncomeLast3Months = await prisma.transaction.aggregate({
        where: { userId, type: 'income', occurredAt: { gte: threeMonthsAgo, lt: currentMonthStart } },
        _sum: { amount: true }
    });

    const avgMonthlyIncome = Number(totalIncomeLast3Months._sum.amount ?? 0) / 3;
    const currentIncome = Number(currentMonthIncome._sum.amount ?? 0);

    if (currentIncome > avgMonthlyIncome * 1.2 && avgMonthlyIncome > 0) {
        insights.push({
            type: 'income_spike',
            message: `Your income this month is 20% higher than your average. Consider putting $${(currentIncome - avgMonthlyIncome).toFixed(0)} into your emergency fund.`,
            action: 'Add to Savings'
        });
    }

    // 2. Check for Budget Warnings
    const budgets = await prisma.budget.findMany({
        where: { userId },
        include: { category: true }
    });

    for (const budget of budgets) {
        const usage = Number(budget.amount) > 0 ? (Number(budget.spent) / Number(budget.amount)) : 0;
        if (usage > 0.9) {
            insights.push({
                type: 'budget_warning',
                message: `Warning: You've used ${Math.round(usage * 100)}% of your "${budget.category?.name || budget.name}" budget.`,
                action: 'Review Budget'
            });
        }
    }

    // 3. Recurring Expense Detection (Simplified)
    const recentTransactions = await prisma.transaction.findMany({
        where: { userId, type: 'expense', occurredAt: { gte: threeMonthsAgo } },
        orderBy: { occurredAt: 'desc' }
    });

    const descriptionMap = new Map<string, number[]>();
    recentTransactions.forEach(t => {
        if (t.notes) {
            const amounts = descriptionMap.get(t.notes) || [];
            amounts.push(Number(t.amount));
            descriptionMap.set(t.notes, amounts);
        }
    });

    for (const [note, amounts] of descriptionMap.entries()) {
        if (amounts.length >= 3) {
            const avg = amounts.reduce((a, b) => a + b, 0) / amounts.length;
            const isConsistent = amounts.every(a => Math.abs(a - avg) < avg * 0.1);
            if (isConsistent) {
                insights.push({
                    type: 'recurring_detect',
                    message: `Detected recurring payment for "${note}" ($${avg.toFixed(0)}). Would you like to automate this?`,
                    action: 'Automate'
                });
                break; // Just one detection for now
            }
        }
    }

    // Default fallback if no insights found
    if (insights.length === 0) {
        insights.push({
            type: 'general',
            message: "Stick to your budget plan this week to reach your financial goals faster.",
            action: 'View Goals'
        });
    }

    return insights;
}
