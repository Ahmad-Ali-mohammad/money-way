"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMiddleware_1 = require("../middleware/authMiddleware");
const dashboardController_1 = require("../controllers/dashboardController");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authenticate);
router.get('/', dashboardController_1.getDashboardOverview);
router.get('/overview', dashboardController_1.getDashboardOverview); // Same endpoint, two paths
router.get('/stats', dashboardController_1.getDashboardStats);
exports.default = router;
//# sourceMappingURL=dashboardRoutes.js.map