"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyzeProjects = exports.getFeasibilityAnalysis = exports.deleteProject = exports.updateProject = exports.getProjectById = exports.createProject = exports.getAllProjects = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const projectSchema = zod_1.z.object({
    name: zod_1.z.string().min(1),
    description: zod_1.z.string().optional(),
    initialInvestment: zod_1.z.number().positive(),
    monthlyRevenue: zod_1.z.number(),
    monthlyExpenses: zod_1.z.number(),
    startDate: zod_1.z.string().datetime().optional(),
    endDate: zod_1.z.string().datetime().optional(),
    status: zod_1.z.enum(['planning', 'active', 'completed', 'cancelled']).default('planning'),
    riskLevel: zod_1.z.enum(['low', 'medium', 'high']).default('low'),
});
// Helper function to calculate project metrics
const calculateProjectMetrics = (project) => {
    // Extract risk level from metadata if available
    let riskLevel = 'low';
    if (project.metadata) {
        try {
            const meta = typeof project.metadata === 'string' ? JSON.parse(project.metadata) : project.metadata;
            if (meta.riskLevel)
                riskLevel = meta.riskLevel;
        }
        catch (e) { }
    }
    // Apply risk discount coefficient
    let riskCoefficient = 1.0;
    if (riskLevel === 'high')
        riskCoefficient = 0.75; // 25% discount
    else if (riskLevel === 'medium')
        riskCoefficient = 0.90; // 10% discount
    const effectiveMonthlyRevenue = project.monthlyRevenue * riskCoefficient;
    const monthlyProfit = effectiveMonthlyRevenue - project.monthlyExpenses;
    // Break-even point (in months)
    const breakEvenMonths = monthlyProfit > 0
        ? Math.ceil(project.initialInvestment / monthlyProfit)
        : null;
    // ROI calculation (first year)
    const annualProfit = monthlyProfit * 12;
    const roi = project.initialInvestment > 0
        ? ((annualProfit / project.initialInvestment) * 100)
        : 0;
    return {
        monthlyProfit,
        breakEvenMonths,
        breakEvenDate: breakEvenMonths && project.startDate
            ? new Date(new Date(project.startDate).setMonth(new Date(project.startDate).getMonth() + breakEvenMonths))
            : null,
        annualProfit,
        roi: Math.round(roi * 100) / 100,
        riskLevel,
        isViable: monthlyProfit > 0 && breakEvenMonths !== null && breakEvenMonths <= 36,
    };
};
const getAllProjects = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { status } = req.query;
        const where = { userId };
        if (status && typeof status === 'string') {
            where.status = status;
        }
        const projects = await prisma_1.prisma.project.findMany({
            where,
            orderBy: { createdAt: 'desc' },
        });
        const projectsWithMetrics = projects.map(p => {
            const metrics = calculateProjectMetrics(p);
            return {
                ...p,
                metrics,
            };
        });
        const serialized = JSON.parse(JSON.stringify(projectsWithMetrics, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching projects:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllProjects = getAllProjects;
const createProject = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = projectSchema.parse(req.body);
        const project = await prisma_1.prisma.project.create({
            data: {
                userId,
                name: data.name,
                description: data.description,
                initialInvestment: data.initialInvestment,
                monthlyRevenue: data.monthlyRevenue,
                monthlyExpenses: data.monthlyExpenses,
                startDate: data.startDate ? new Date(data.startDate) : new Date(),
                endDate: data.endDate ? new Date(data.endDate) : null,
                status: data.status,
                metadata: JSON.stringify({ riskLevel: data.riskLevel })
            },
        });
        const metrics = calculateProjectMetrics(project);
        const serialized = JSON.parse(JSON.stringify({ ...project, metrics }, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error creating project:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createProject = createProject;
const getProjectById = async (req, res) => {
    try {
        const userId = req.user.userId;
        const projectId = parseInt(req.params.id);
        const project = await prisma_1.prisma.project.findFirst({
            where: {
                id: projectId,
                userId,
            },
        });
        if (!project) {
            return res.status(404).json({ error: 'Project not found' });
        }
        const metrics = calculateProjectMetrics(project);
        const serialized = JSON.parse(JSON.stringify({ ...project, metrics }, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching project:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getProjectById = getProjectById;
const updateProject = async (req, res) => {
    try {
        const userId = req.user.userId;
        const projectId = parseInt(req.params.id);
        const data = projectSchema.partial().parse(req.body);
        const existing = await prisma_1.prisma.project.findFirst({
            where: { id: projectId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Project not found' });
        }
        const updated = await prisma_1.prisma.project.update({
            where: { id: projectId },
            data: {
                ...(data.name && { name: data.name }),
                ...(data.description && { description: data.description }),
                ...(data.initialInvestment !== undefined && { initialInvestment: data.initialInvestment }),
                ...(data.monthlyRevenue !== undefined && { monthlyRevenue: data.monthlyRevenue }),
                ...(data.monthlyExpenses !== undefined && { monthlyExpenses: data.monthlyExpenses }),
                ...(data.startDate && { startDate: new Date(data.startDate) }),
                ...(data.endDate && { endDate: new Date(data.endDate) }),
                ...(data.status && { status: data.status }),
                ...(data.riskLevel && { metadata: JSON.stringify({ riskLevel: data.riskLevel }) }),
            },
        });
        const metrics = calculateProjectMetrics(updated);
        const serialized = JSON.parse(JSON.stringify({ ...updated, metrics }, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error updating project:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateProject = updateProject;
const deleteProject = async (req, res) => {
    try {
        const userId = req.user.userId;
        const projectId = parseInt(req.params.id);
        const existing = await prisma_1.prisma.project.findFirst({
            where: { id: projectId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Project not found' });
        }
        await prisma_1.prisma.project.delete({
            where: { id: projectId },
        });
        res.json({ message: 'Project deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting project:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteProject = deleteProject;
const getFeasibilityAnalysis = async (req, res) => {
    try {
        const userId = req.user.userId;
        const projectId = parseInt(req.params.id);
        const project = await prisma_1.prisma.project.findFirst({
            where: { id: projectId, userId },
        });
        if (!project) {
            return res.status(404).json({ error: 'Project not found' });
        }
        const metrics = calculateProjectMetrics(project);
        // Detailed financial projections (3 years)
        const projections = [];
        for (let year = 1; year <= 3; year++) {
            const yearlyRevenue = Number(project.monthlyRevenue) * 12;
            const yearlyExpenses = Number(project.monthlyExpenses) * 12;
            const yearlyProfit = yearlyRevenue - yearlyExpenses;
            const cumulativeProfit = (yearlyProfit * year) - Number(project.initialInvestment);
            projections.push({
                year,
                revenue: yearlyRevenue,
                expenses: yearlyExpenses,
                profit: yearlyProfit,
                cumulativeProfit,
                roi: Number(project.initialInvestment) > 0
                    ? Math.round((cumulativeProfit / Number(project.initialInvestment)) * 10000) / 100
                    : 0,
            });
        }
        // Risk factors
        const riskFactors = [];
        if (metrics.breakEvenMonths && metrics.breakEvenMonths > 18) {
            riskFactors.push('Long break-even period increases risk');
        }
        if (Number(project.monthlyRevenue) < Number(project.monthlyExpenses) * 1.3) {
            riskFactors.push('Low profit margin - vulnerable to cost increases');
        }
        if (Number(project.initialInvestment) > Number(project.monthlyRevenue) * 24) {
            riskFactors.push('High initial investment relative to revenue');
        }
        // Recommendations
        const recommendations = [];
        if (metrics.isViable) {
            recommendations.push('Project shows positive financial indicators');
            if (metrics.roi > 20) {
                recommendations.push('Strong ROI - consider prioritizing this project');
            }
        }
        else {
            recommendations.push('Consider revising revenue projections or reducing costs');
        }
        if (metrics.breakEvenMonths && metrics.breakEvenMonths > 12) {
            recommendations.push('Plan for adequate cash reserves to cover initial period');
        }
        const analysis = {
            projectId: project.id.toString(),
            projectName: project.name,
            basicMetrics: metrics,
            projections,
            riskAssessment: {
                level: metrics.riskLevel,
                factors: riskFactors,
                score: riskFactors.length === 0 ? 90 : riskFactors.length === 1 ? 70 : 50,
            },
            recommendations,
            conclusion: metrics.isViable
                ? 'Project is financially viable and recommended for execution'
                : 'Project requires significant improvements before execution',
        };
        res.json(analysis);
    }
    catch (error) {
        console.error('Error generating feasibility analysis:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getFeasibilityAnalysis = getFeasibilityAnalysis;
// New: Analyze ad-hoc project data posted by frontend
const analyzeProjects = async (req, res) => {
    try {
        const data = projectSchema.parse(req.body);
        const projectLike = {
            ...data,
            startDate: data.startDate || new Date().toISOString(),
            endDate: data.endDate || null,
        };
        const metrics = calculateProjectMetrics(projectLike);
        // Build simple projections and recommendations similar to getFeasibilityAnalysis
        const projections = [];
        for (let year = 1; year <= 3; year++) {
            const yearlyRevenue = Number(projectLike.monthlyRevenue) * 12;
            const yearlyExpenses = Number(projectLike.monthlyExpenses) * 12;
            const yearlyProfit = yearlyRevenue - yearlyExpenses;
            const cumulativeProfit = (yearlyProfit * year) - Number(projectLike.initialInvestment);
            projections.push({
                year,
                revenue: yearlyRevenue,
                expenses: yearlyExpenses,
                profit: yearlyProfit,
                cumulativeProfit,
            });
        }
        const riskFactors = [];
        if (metrics.breakEvenMonths && metrics.breakEvenMonths > 18)
            riskFactors.push('Long break-even period increases risk');
        if (metrics.roi < 10)
            riskFactors.push('Low expected ROI');
        const recommendations = metrics.isViable ? ['Project appears viable based on provided inputs'] : ['Consider adjusting assumptions to improve viability'];
        res.json({ metrics, projections, riskFactors, recommendations });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error analyzing project:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.analyzeProjects = analyzeProjects;
//# sourceMappingURL=projectController.js.map