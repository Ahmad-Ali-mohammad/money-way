import './setup';
import request from 'supertest';
import app from '../index';
import { describe, it, expect } from 'vitest';

let token: string;

describe('Protected Endpoints and Utilities', () => {
  it('logs in and gets token', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'ahmed@example.com', password: 'password123' });

    expect(res.status).toBe(200);
    token = res.body.token;
    expect(token).toBeTruthy();
  });

  it('fetches dashboard stats', async () => {
    const res = await request(app)
      .get('/api/dashboard/stats?period=month')
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('period');
    expect(res.body).toHaveProperty('totalIncome');
  });

  it('analyzes posted project data', async () => {
    const res = await request(app)
      .post('/api/projects/analyze')
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'Test Project', initialInvestment: 10000, monthlyRevenue: 2000, monthlyExpenses: 1000 });

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('metrics');
    expect(res.body.metrics).toHaveProperty('monthlyProfit');
  });

  it('calls public currencies endpoint', async () => {
    const res = await request(app)
      .get('/api/currencies');

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('currencies');
    expect(Array.isArray(res.body.currencies)).toBe(true);
  });

  it('marks an alert as read (if any exist)', async () => {
    const alertsRes = await request(app)
      .get('/api/alerts')
      .set('Authorization', `Bearer ${token}`);

    expect(alertsRes.status).toBe(200);
    const alerts = alertsRes.body;
    if (alerts.length > 0) {
      const first = alerts[0];
      const markRes = await request(app)
        .patch(`/api/alerts/${first.id}/read`)
        .set('Authorization', `Bearer ${token}`);

      expect(markRes.status).toBe(200);
      expect(markRes.body).toHaveProperty('isRead');
    }
  });
});
