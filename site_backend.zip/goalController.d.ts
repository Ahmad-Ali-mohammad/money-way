import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getAllGoals: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createGoal: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getGoalById: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateGoal: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteGoal: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getGoalProgress: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const addToGoal: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
