"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const projectController_1 = require("../controllers/projectController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/', projectController_1.getAllProjects);
router.post('/', projectController_1.createProject);
router.get('/:id', projectController_1.getProjectById);
router.put('/:id', projectController_1.updateProject);
router.delete('/:id', projectController_1.deleteProject);
router.get('/:id/analysis', projectController_1.getFeasibilityAnalysis);
router.post('/analyze', projectController_1.analyzeProjects);
exports.default = router;
//# sourceMappingURL=projectRoutes.js.map