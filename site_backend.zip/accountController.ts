import { Request, Response } from 'express';
import { prisma } from '../lib/prisma';
import { AuthRequest } from '../middleware/authMiddleware';
import { z } from 'zod';

const accountSchema = z.object({
  name: z.string().min(1),
  type: z.enum(['checking', 'savings', 'credit', 'investment', 'cash']),
  balance: z.number(),
  currency: z.string().default('USD'),
  institutionName: z.string().optional(),
});

export const getAllAccounts = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;

    const accounts = await prisma.account.findMany({
      where: { userId },
      include: {
        _count: {
          select: { transactions: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const serialized = JSON.parse(
      JSON.stringify(accounts, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching accounts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const createAccount = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const data = accountSchema.parse(req.body);

    const account = await prisma.account.create({
      data: {
        userId,
        name: data.name,
        type: data.type,
        balance: data.balance || 0,
        currency: data.currency || 'USD',
        meta: data.institutionName ? JSON.stringify({ institutionName: data.institutionName }) : undefined,
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(account, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.status(201).json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error creating account:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getAccountById = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const accountId = parseInt(req.params.id as string);

    const account = await prisma.account.findFirst({
      where: {
        id: accountId,
        userId,
      },
      include: {
        transactions: {
          orderBy: { occurredAt: 'desc' },
          take: 10,
        },
      },
    });

    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    const serialized = JSON.parse(
      JSON.stringify(account, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    console.error('Error fetching account:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const updateAccount = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const accountId = parseInt(req.params.id as string);
    const data = accountSchema.partial().parse(req.body);

    const existing = await prisma.account.findFirst({
      where: { id: accountId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Account not found' });
    }

    const updated = await prisma.account.update({
      where: { id: accountId },
      data: {
        ...(data.name && { name: data.name }),
        ...(data.type && { type: data.type }),
        ...(data.balance !== undefined && { balance: data.balance }),
        ...(data.currency && { currency: data.currency }),
        ...(data.institutionName && { institutionName: data.institutionName }),
      },
    });

    const serialized = JSON.parse(
      JSON.stringify(updated, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );

    res.json(serialized);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ errors: error.issues });
    }
    console.error('Error updating account:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const deleteAccount = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const accountId = parseInt(req.params.id as string);

    const existing = await prisma.account.findFirst({
      where: { id: accountId, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: 'Account not found' });
    }

    await prisma.account.delete({
      where: { id: accountId },
    });

    res.json({ message: 'Account deleted successfully' });
  } catch (error) {
    console.error('Error deleting account:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getAccountBalance = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const accountId = parseInt(req.params.id as string);

    const account = await prisma.account.findFirst({
      where: { id: accountId, userId },
      select: { balance: true, currency: true, name: true },
    });

    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    res.json({
      balance: account.balance,
      currency: account.currency,
      name: account.name,
    });
  } catch (error) {
    console.error('Error fetching account balance:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};



