"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteReceipt = exports.updateReceipt = exports.createReceipt = exports.getReceiptById = exports.getAllReceipts = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const receiptSchema = zod_1.z.object({
    filePath: zod_1.z.string().optional(),
    metadata: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
});
const getAllReceipts = async (req, res) => {
    try {
        const userId = req.user.userId;
        const receipts = await prisma_1.prisma.receipt.findMany({
            where: { userId },
            orderBy: { uploadedAt: 'desc' },
        });
        const serialized = JSON.parse(JSON.stringify(receipts, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching receipts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllReceipts = getAllReceipts;
const getReceiptById = async (req, res) => {
    try {
        const userId = req.user.userId;
        const receiptId = parseInt(req.params.id);
        const receipt = await prisma_1.prisma.receipt.findFirst({
            where: {
                id: receiptId,
                userId,
            },
        });
        if (!receipt) {
            return res.status(404).json({ error: 'Receipt not found' });
        }
        const serialized = JSON.parse(JSON.stringify(receipt, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching receipt:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getReceiptById = getReceiptById;
const createReceipt = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = receiptSchema.parse(req.body);
        const receipt = await prisma_1.prisma.receipt.create({
            data: {
                userId,
                filePath: data.filePath,
                metadata: data.metadata ? JSON.stringify(data.metadata) : null,
            },
        });
        const serialized = JSON.parse(JSON.stringify(receipt, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error creating receipt:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createReceipt = createReceipt;
const updateReceipt = async (req, res) => {
    try {
        const userId = req.user.userId;
        const receiptId = parseInt(req.params.id);
        const data = receiptSchema.partial().parse(req.body);
        const existing = await prisma_1.prisma.receipt.findFirst({
            where: { id: receiptId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Receipt not found' });
        }
        const updated = await prisma_1.prisma.receipt.update({
            where: { id: receiptId },
            data: {
                ...(data.filePath !== undefined && { filePath: data.filePath }),
                ...(data.metadata !== undefined && { metadata: JSON.stringify(data.metadata) }),
            },
        });
        const serialized = JSON.parse(JSON.stringify(updated, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error updating receipt:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateReceipt = updateReceipt;
const deleteReceipt = async (req, res) => {
    try {
        const userId = req.user.userId;
        const receiptId = parseInt(req.params.id);
        const existing = await prisma_1.prisma.receipt.findFirst({
            where: { id: receiptId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Receipt not found' });
        }
        await prisma_1.prisma.receipt.delete({
            where: { id: receiptId },
        });
        res.json({ message: 'Receipt deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting receipt:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteReceipt = deleteReceipt;
//# sourceMappingURL=receiptController.js.map