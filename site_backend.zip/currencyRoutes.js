"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMiddleware_1 = require("../middleware/authMiddleware");
const currencyController_1 = require("../controllers/currencyController");
const router = (0, express_1.Router)();
// Public routes - get supported currencies
router.get('/', currencyController_1.getSupportedCurrencies);
router.get('/supported', currencyController_1.getSupportedCurrencies);
// Protected routes - require authentication
router.use(authMiddleware_1.authMiddleware);
router.get('/user', currencyController_1.getUserCurrency);
router.put('/user', currencyController_1.setUserCurrency);
router.get('/convert', currencyController_1.convertCurrency);
exports.default = router;
//# sourceMappingURL=currencyRoutes.js.map