"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAdvancedTransactionStats = exports.getTransactionTemplates = exports.bulkCreateTransactions = exports.getTransactionStats = exports.deleteTransaction = exports.updateTransaction = exports.getTransactionById = exports.createTransaction = exports.getAllTransactions = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const transactionSchema = zod_1.z.object({
    amount: zod_1.z.number().positive(),
    type: zod_1.z.enum(['income', 'expense', 'transfer', 'investment']),
    accountId: zod_1.z.number().optional(),
    categoryId: zod_1.z.number().optional(),
    notes: zod_1.z.string().optional(),
    tags: zod_1.z.array(zod_1.z.string()).optional(),
    occurredAt: zod_1.z.string().datetime().optional(),
    isRecurring: zod_1.z.boolean().optional(),
    recurrenceRule: zod_1.z.string().optional(),
});
const getAllTransactions = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { limit = '50', offset = '0', type, startDate, endDate, categoryId, accountId, search } = req.query;
        const where = { userId };
        if (type && typeof type === 'string' && type !== 'all') {
            where.type = type;
        }
        if (startDate || endDate) {
            where.occurredAt = {};
            if (startDate)
                where.occurredAt.gte = new Date(startDate);
            if (endDate)
                where.occurredAt.lte = new Date(endDate);
        }
        if (categoryId) {
            where.categoryId = parseInt(categoryId);
        }
        if (accountId) {
            where.accountId = parseInt(accountId);
        }
        if (search && typeof search === 'string') {
            where.OR = [
                { notes: { contains: search, mode: 'insensitive' } },
                { tags: { array_contains: search } }
            ];
        }
        const transactions = await prisma_1.prisma.transaction.findMany({
            where,
            include: {
                category: true,
                account: true,
            },
            orderBy: { occurredAt: 'desc' },
            take: parseInt(limit),
            skip: parseInt(offset),
        });
        const serialized = JSON.parse(JSON.stringify(transactions, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllTransactions = getAllTransactions;
const createTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = transactionSchema.parse(req.body);
        // Use Prisma transaction for atomic operations
        const result = await prisma_1.prisma.$transaction(async (tx) => {
            // Get user's first account or create one
            let account = await tx.account.findFirst({
                where: { userId },
            });
            if (!account) {
                account = await tx.account.create({
                    data: {
                        userId,
                        name: 'Main Account',
                        type: 'checking',
                        balance: 0,
                    },
                });
            }
            const accountId = data.accountId || account.id;
            // Verify account belongs to user if accountId provided
            if (data.accountId) {
                const targetAccount = await tx.account.findFirst({
                    where: { id: data.accountId, userId },
                });
                if (!targetAccount) {
                    throw new Error('Account not found or access denied');
                }
            }
            // Calculate balance change
            const balanceChange = data.type === 'income' ? data.amount : -data.amount;
            // Create transaction and update account balance atomically
            const transaction = await tx.transaction.create({
                data: {
                    userId,
                    accountId,
                    amount: data.amount,
                    type: data.type,
                    categoryId: data.categoryId || null,
                    notes: data.notes,
                    tags: data.tags ? JSON.parse(JSON.stringify(data.tags)) : null,
                    occurredAt: data.occurredAt ? new Date(data.occurredAt) : new Date(),
                    isRecurring: data.isRecurring || false,
                    recurrenceRule: data.recurrenceRule,
                },
                include: {
                    category: true,
                    account: true,
                },
            });
            // Update account balance
            await tx.account.update({
                where: { id: accountId },
                data: {
                    balance: {
                        increment: balanceChange,
                    },
                },
            });
            return transaction;
        });
        const serialized = JSON.parse(JSON.stringify(result, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error creating transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createTransaction = createTransaction;
const getTransactionById = async (req, res) => {
    try {
        const userId = req.user.userId;
        const transactionId = parseInt(req.params.id);
        const transaction = await prisma_1.prisma.transaction.findFirst({
            where: {
                id: transactionId,
                userId,
            },
            include: {
                category: true,
                account: true,
            },
        });
        if (!transaction) {
            return res.status(404).json({ error: 'Transaction not found' });
        }
        const serialized = JSON.parse(JSON.stringify(transaction, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getTransactionById = getTransactionById;
const updateTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const transactionId = parseInt(req.params.id);
        const data = transactionSchema.partial().parse(req.body);
        const result = await prisma_1.prisma.$transaction(async (tx) => {
            const existing = await tx.transaction.findFirst({
                where: { id: transactionId, userId },
            });
            if (!existing) {
                throw new Error('Transaction not found');
            }
            // Calculate balance adjustments if amount or type changes
            const oldBalanceChange = existing.type === 'income' ? Number(existing.amount) : -Number(existing.amount);
            const newAmount = data.amount !== undefined ? data.amount : Number(existing.amount);
            const newType = data.type || existing.type;
            const newBalanceChange = newType === 'income' ? newAmount : -newAmount;
            const balanceDelta = newBalanceChange - oldBalanceChange;
            // If accountId changes, need to revert old account and update new account
            if (data.accountId !== undefined && data.accountId !== existing.accountId) {
                // Revert balance from old account
                await tx.account.update({
                    where: { id: existing.accountId },
                    data: {
                        balance: {
                            decrement: oldBalanceChange,
                        },
                    },
                });
                // Add balance to new account
                const newAccount = await tx.account.findFirst({
                    where: { id: data.accountId, userId },
                });
                if (!newAccount) {
                    throw new Error('Target account not found');
                }
                await tx.account.update({
                    where: { id: data.accountId },
                    data: {
                        balance: {
                            increment: newBalanceChange,
                        },
                    },
                });
            }
            else if (balanceDelta !== 0) {
                // Update balance in the same account
                await tx.account.update({
                    where: { id: existing.accountId },
                    data: {
                        balance: {
                            increment: balanceDelta,
                        },
                    },
                });
            }
            // Update transaction
            const updated = await tx.transaction.update({
                where: { id: transactionId },
                data: {
                    ...(data.amount !== undefined && { amount: data.amount }),
                    ...(data.type && { type: data.type }),
                    ...(data.accountId !== undefined && { accountId: data.accountId }),
                    ...(data.categoryId !== undefined && { categoryId: data.categoryId }),
                    ...(data.notes !== undefined && { notes: data.notes }),
                    ...(data.tags && { tags: JSON.parse(JSON.stringify(data.tags)) }),
                    ...(data.occurredAt && { occurredAt: new Date(data.occurredAt) }),
                    ...(data.isRecurring !== undefined && { isRecurring: data.isRecurring }),
                    ...(data.recurrenceRule !== undefined && { recurrenceRule: data.recurrenceRule }),
                },
                include: {
                    category: true,
                    account: true,
                },
            });
            return updated;
        });
        const serialized = JSON.parse(JSON.stringify(result, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        if (error instanceof Error && error.message === 'Transaction not found') {
            return res.status(404).json({ error: 'Transaction not found' });
        }
        if (error instanceof Error && error.message === 'Target account not found') {
            return res.status(400).json({ error: 'Target account not found' });
        }
        console.error('Error updating transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateTransaction = updateTransaction;
const deleteTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const transactionId = parseInt(req.params.id);
        await prisma_1.prisma.$transaction(async (tx) => {
            const existing = await tx.transaction.findFirst({
                where: { id: transactionId, userId },
            });
            if (!existing) {
                throw new Error('Transaction not found');
            }
            // Revert the balance change
            const balanceChange = existing.type === 'income' ? Number(existing.amount) : -Number(existing.amount);
            await tx.account.update({
                where: { id: existing.accountId },
                data: {
                    balance: {
                        decrement: balanceChange,
                    },
                },
            });
            // Delete the transaction
            await tx.transaction.delete({
                where: { id: transactionId },
            });
        });
        res.json({ message: 'Transaction deleted successfully' });
    }
    catch (error) {
        if (error instanceof Error && error.message === 'Transaction not found') {
            return res.status(404).json({ error: 'Transaction not found' });
        }
        console.error('Error deleting transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteTransaction = deleteTransaction;
const getTransactionStats = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { startDate, endDate } = req.query;
        const where = { userId };
        if (startDate && endDate) {
            where.occurredAt = {
                gte: new Date(startDate),
                lte: new Date(endDate),
            };
        }
        const [incomeTransactions, expenseTransactions] = await Promise.all([
            prisma_1.prisma.transaction.findMany({
                where: { ...where, type: 'income' },
            }),
            prisma_1.prisma.transaction.findMany({
                where: { ...where, type: 'expense' },
            }),
        ]);
        const totalIncome = incomeTransactions.reduce((sum, t) => sum + Number(t.amount), 0);
        const totalExpense = expenseTransactions.reduce((sum, t) => sum + Number(t.amount), 0);
        res.json({
            totalIncome,
            totalExpense,
            netBalance: totalIncome - totalExpense,
            transactionCount: incomeTransactions.length + expenseTransactions.length,
        });
    }
    catch (error) {
        console.error('Error fetching transaction stats:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getTransactionStats = getTransactionStats;
const bulkCreateTransactions = async (req, res) => {
    try {
        const userId = req.user.userId;
        const transactions = zod_1.z.array(transactionSchema).parse(req.body);
        const results = [];
        const errors = [];
        for (let i = 0; i < transactions.length; i++) {
            try {
                const data = transactions[i];
                const result = await prisma_1.prisma.$transaction(async (tx) => {
                    let account = await tx.account.findFirst({
                        where: { userId },
                    });
                    if (!account) {
                        account = await tx.account.create({
                            data: {
                                userId,
                                name: 'Main Account',
                                type: 'checking',
                                balance: 0,
                            },
                        });
                    }
                    const accountId = data.accountId || account.id;
                    if (data.accountId) {
                        const targetAccount = await tx.account.findFirst({
                            where: { id: data.accountId, userId },
                        });
                        if (!targetAccount) {
                            throw new Error('Account not found or access denied');
                        }
                    }
                    const balanceChange = data.type === 'income' ? data.amount : -data.amount;
                    const transaction = await tx.transaction.create({
                        data: {
                            userId,
                            accountId,
                            amount: data.amount,
                            type: data.type,
                            categoryId: data.categoryId || null,
                            notes: data.notes,
                            tags: data.tags ? JSON.parse(JSON.stringify(data.tags)) : null,
                            occurredAt: data.occurredAt ? new Date(data.occurredAt) : new Date(),
                            isRecurring: data.isRecurring || false,
                            recurrenceRule: data.recurrenceRule,
                        },
                        include: {
                            category: true,
                            account: true,
                        },
                    });
                    await tx.account.update({
                        where: { id: accountId },
                        data: {
                            balance: {
                                increment: balanceChange,
                            },
                        },
                    });
                    return transaction;
                });
                results.push(result);
            }
            catch (error) {
                errors.push({ index: i, error: error instanceof Error ? error.message : 'Unknown error' });
            }
        }
        const serialized = JSON.parse(JSON.stringify(results, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json({
            success: results.length,
            failed: errors.length,
            results: serialized,
            errors,
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error bulk creating transactions:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.bulkCreateTransactions = bulkCreateTransactions;
const getTransactionTemplates = async (req, res) => {
    try {
        const userId = req.user.userId;
        // Get most common transactions as templates
        const templates = await prisma_1.prisma.transaction.groupBy({
            by: ['notes', 'categoryId', 'type'],
            where: {
                userId,
                notes: { not: null },
            },
            _count: {
                id: true,
            },
            _avg: {
                amount: true,
            },
            orderBy: {
                _count: {
                    id: 'desc',
                },
            },
            take: 10,
        });
        const templatesWithDetails = await Promise.all(templates.map(async (template) => {
            const category = template.categoryId
                ? await prisma_1.prisma.category.findUnique({
                    where: { id: template.categoryId },
                    select: { name: true },
                })
                : null;
            return {
                notes: template.notes,
                categoryId: template.categoryId,
                categoryName: category?.name,
                type: template.type,
                averageAmount: Math.round(Number(template._avg.amount) * 100) / 100,
                frequency: template._count.id,
            };
        }));
        res.json(templatesWithDetails);
    }
    catch (error) {
        console.error('Error fetching transaction templates:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getTransactionTemplates = getTransactionTemplates;
const getAdvancedTransactionStats = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { period = 'monthly', startDate, endDate } = req.query;
        let dateFilter = { userId };
        if (startDate && endDate) {
            dateFilter.occurredAt = {
                gte: new Date(startDate),
                lte: new Date(endDate),
            };
        }
        else {
            // Default to last 12 months
            const twelveMonthsAgo = new Date();
            twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);
            dateFilter.occurredAt = { gte: twelveMonthsAgo };
        }
        const transactions = await prisma_1.prisma.transaction.findMany({
            where: dateFilter,
            include: { category: true },
        });
        // Group by period
        const groupedData = {};
        transactions.forEach((t) => {
            let periodKey;
            const date = t.occurredAt;
            switch (period) {
                case 'daily':
                    periodKey = date.toISOString().split('T')[0];
                    break;
                case 'weekly':
                    const weekStart = new Date(date);
                    weekStart.setDate(date.getDate() - date.getDay());
                    periodKey = weekStart.toISOString().split('T')[0];
                    break;
                case 'yearly':
                    periodKey = date.getFullYear().toString();
                    break;
                default: // monthly
                    periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            }
            if (!groupedData[periodKey]) {
                groupedData[periodKey] = {
                    period: periodKey,
                    income: 0,
                    expense: 0,
                    count: 0,
                    categories: {},
                };
            }
            if (t.type === 'income') {
                groupedData[periodKey].income += Number(t.amount);
            }
            else {
                groupedData[periodKey].expense += Number(t.amount);
            }
            groupedData[periodKey].count += 1;
            // Category breakdown
            const categoryName = t.category?.name || 'Uncategorized';
            if (!groupedData[periodKey].categories[categoryName]) {
                groupedData[periodKey].categories[categoryName] = 0;
            }
            groupedData[periodKey].categories[categoryName] += Number(t.amount);
        });
        // Calculate trends and averages
        const periods = Object.values(groupedData);
        const totalIncome = periods.reduce((sum, p) => sum + p.income, 0);
        const totalExpense = periods.reduce((sum, p) => sum + p.expense, 0);
        const avgIncome = periods.length > 0 ? totalIncome / periods.length : 0;
        const avgExpense = periods.length > 0 ? totalExpense / periods.length : 0;
        res.json({
            period,
            totalPeriods: periods.length,
            summary: {
                totalIncome,
                totalExpense,
                netBalance: totalIncome - totalExpense,
                averageIncome: Math.round(avgIncome * 100) / 100,
                averageExpense: Math.round(avgExpense * 100) / 100,
            },
            periods: periods.map((p) => ({
                ...p,
                net: p.income - p.expense,
                savingsRate: p.income > 0 ? Math.round(((p.income - p.expense) / p.income) * 10000) / 100 : 0,
            })),
        });
    }
    catch (error) {
        console.error('Error fetching advanced transaction stats:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAdvancedTransactionStats = getAdvancedTransactionStats;
//# sourceMappingURL=transactionController.js.map