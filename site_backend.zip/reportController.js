"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getProjectKPIs = exports.getRiskAnalysis = exports.getCashFlow = exports.getMonthlyTrends = exports.getCategoryBreakdown = exports.getFinancialSummary = void 0;
const prisma_1 = require("../lib/prisma");
const riskAnalysisService_1 = require("../services/riskAnalysisService");
const kpiService_1 = require("../services/kpiService");
const getFinancialSummary = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { startDate, endDate } = req.query;
        const where = { userId };
        if (startDate && endDate) {
            where.occurredAt = {
                gte: new Date(startDate),
                lte: new Date(endDate),
            };
        }
        const [transactions, accounts, budgets, goals] = await Promise.all([
            prisma_1.prisma.transaction.findMany({ where }),
            prisma_1.prisma.account.findMany({ where: { userId } }),
            prisma_1.prisma.budget.findMany({ where: { userId } }),
            prisma_1.prisma.goal.findMany({ where: { userId } }),
        ]);
        const totalIncome = transactions
            .filter((t) => t.type === 'income')
            .reduce((sum, t) => sum + Number(t.amount), 0);
        const totalExpense = transactions
            .filter((t) => t.type === 'expense')
            .reduce((sum, t) => sum + Number(t.amount), 0);
        const netBalance = totalIncome - totalExpense;
        const totalAccountBalance = accounts.reduce((sum, a) => sum + Number(a.balance), 0);
        const budgetUtilization = budgets.reduce((acc, b) => ({
            total: acc.total + Number(b.amount),
            spent: acc.spent + Number(b.spent),
        }), { total: 0, spent: 0 });
        const goalProgress = goals.reduce((acc, g) => ({
            total: acc.total + Number(g.targetAmount),
            current: acc.current + Number(g.currentAmount),
        }), { total: 0, current: 0 });
        res.json({
            period: { startDate, endDate },
            income: totalIncome,
            expense: totalExpense,
            netBalance,
            totalAccountBalance,
            budgetUtilization: {
                total: budgetUtilization.total,
                spent: budgetUtilization.spent,
                percentage: budgetUtilization.total > 0
                    ? Math.round((budgetUtilization.spent / budgetUtilization.total) * 10000) / 100
                    : 0,
            },
            goalProgress: {
                total: goalProgress.total,
                current: goalProgress.current,
                percentage: goalProgress.total > 0
                    ? Math.round((goalProgress.current / goalProgress.total) * 10000) / 100
                    : 0,
            },
            transactionCount: transactions.length,
            accountCount: accounts.length,
            budgetCount: budgets.length,
            goalCount: goals.length,
        });
    }
    catch (error) {
        console.error('Error generating financial summary:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getFinancialSummary = getFinancialSummary;
const getCategoryBreakdown = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { startDate, endDate, type = 'expense' } = req.query;
        const where = { userId, type };
        if (startDate && endDate) {
            where.occurredAt = {
                gte: new Date(startDate),
                lte: new Date(endDate),
            };
        }
        const transactions = await prisma_1.prisma.transaction.findMany({
            where,
            include: { category: true },
        });
        const breakdown = transactions.reduce((acc, t) => {
            const categoryName = t.category?.name || 'Uncategorized';
            if (!acc[categoryName]) {
                acc[categoryName] = {
                    name: categoryName,
                    amount: 0,
                    count: 0,
                };
            }
            acc[categoryName].amount += t.amount;
            acc[categoryName].count += 1;
            return acc;
        }, {});
        const total = Object.values(breakdown).reduce((sum, cat) => sum + cat.amount, 0);
        const result = Object.values(breakdown).map((cat) => ({
            ...cat,
            percentage: total > 0 ? Math.round((cat.amount / total) * 10000) / 100 : 0,
        }));
        res.json({
            type,
            period: { startDate, endDate },
            total,
            breakdown: result,
        });
    }
    catch (error) {
        console.error('Error generating category breakdown:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getCategoryBreakdown = getCategoryBreakdown;
const getMonthlyTrends = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { months = 12 } = req.query;
        const startDate = new Date();
        startDate.setMonth(startDate.getMonth() - parseInt(months));
        const transactions = await prisma_1.prisma.transaction.findMany({
            where: {
                userId,
                occurredAt: { gte: startDate },
            },
            orderBy: { occurredAt: 'asc' },
        });
        const monthlyData = {};
        transactions.forEach((t) => {
            const monthKey = `${t.occurredAt.getFullYear()}-${String(t.occurredAt.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyData[monthKey]) {
                monthlyData[monthKey] = {
                    month: monthKey,
                    income: 0,
                    expense: 0,
                    net: 0,
                    transactionCount: 0,
                };
            }
            if (t.type === 'income') {
                monthlyData[monthKey].income += t.amount;
            }
            else if (t.type === 'expense') {
                monthlyData[monthKey].expense += t.amount;
            }
            monthlyData[monthKey].net = monthlyData[monthKey].income - monthlyData[monthKey].expense;
            monthlyData[monthKey].transactionCount += 1;
        });
        const trends = Object.values(monthlyData);
        res.json({
            months: parseInt(months),
            trends,
        });
    }
    catch (error) {
        console.error('Error generating monthly trends:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getMonthlyTrends = getMonthlyTrends;
const getCashFlow = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { period = 'monthly' } = req.query;
        const now = new Date();
        let startDate;
        switch (period) {
            case 'daily':
                startDate = new Date(now);
                startDate.setDate(now.getDate() - 30);
                break;
            case 'weekly':
                startDate = new Date(now);
                startDate.setDate(now.getDate() - 90);
                break;
            case 'yearly':
                startDate = new Date(now);
                startDate.setFullYear(now.getFullYear() - 2);
                break;
            default: // monthly
                startDate = new Date(now);
                startDate.setMonth(now.getMonth() - 12);
        }
        const transactions = await prisma_1.prisma.transaction.findMany({
            where: {
                userId,
                occurredAt: { gte: startDate },
            },
            orderBy: { occurredAt: 'asc' },
        });
        const cashFlow = transactions.map((t) => ({
            date: t.occurredAt,
            amount: Number(t.type === 'income' ? t.amount : -t.amount),
            type: t.type,
            balance: 0, // Will be calculated cumulatively
        }));
        let runningBalance = 0;
        cashFlow.forEach((cf) => {
            runningBalance += cf.amount;
            cf.balance = runningBalance;
        });
        res.json({
            period,
            startDate,
            endDate: now,
            cashFlow,
        });
    }
    catch (error) {
        console.error('Error generating cash flow:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getCashFlow = getCashFlow;
const getRiskAnalysis = async (req, res) => {
    try {
        const userId = req.user.userId;
        const riskMetrics = await (0, riskAnalysisService_1.calculateRiskMetrics)(userId);
        res.json({
            riskMetrics,
            timestamp: new Date().toISOString(),
        });
    }
    catch (error) {
        console.error('Error generating risk analysis:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getRiskAnalysis = getRiskAnalysis;
const getProjectKPIs = async (req, res) => {
    try {
        const userId = req.user.userId;
        const projectId = req.params.projectId;
        if (projectId) {
            // Get KPIs for specific project
            const kpis = await (0, kpiService_1.calculateProjectKPIs)(parseInt(projectId));
            res.json({
                projectId: parseInt(projectId),
                kpis,
                timestamp: new Date().toISOString(),
            });
        }
        else {
            // Get overall portfolio KPIs
            const overallKPIs = await (0, kpiService_1.calculateOverallKPIs)(userId);
            res.json({
                overallKPIs,
                timestamp: new Date().toISOString(),
            });
        }
    }
    catch (error) {
        console.error('Error generating project KPIs:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getProjectKPIs = getProjectKPIs;
//# sourceMappingURL=reportController.js.map