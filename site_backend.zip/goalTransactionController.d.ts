import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getAllGoalTransactions: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getGoalTransactionById: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createGoalTransaction: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateGoalTransaction: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteGoalTransaction: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
