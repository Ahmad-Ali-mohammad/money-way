"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteGoalTransaction = exports.updateGoalTransaction = exports.createGoalTransaction = exports.getGoalTransactionById = exports.getAllGoalTransactions = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const goalTransactionSchema = zod_1.z.object({
    goalId: zod_1.z.number().int().positive(),
    amount: zod_1.z.number().positive(),
    description: zod_1.z.string().optional(),
    occurredAt: zod_1.z.string().datetime().optional(),
});
const getAllGoalTransactions = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { limit = '50', offset = '0', goalId } = req.query;
        const where = {};
        // Ensure we only return transactions for goals owned by the user
        where.goal = { userId };
        if (goalId) {
            where.goalId = parseInt(goalId);
        }
        const transactions = await prisma_1.prisma.goalTransaction.findMany({
            where,
            orderBy: { occurredAt: 'desc' },
            take: parseInt(limit),
            skip: parseInt(offset),
        });
        const serialized = JSON.parse(JSON.stringify(transactions, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching goal transactions:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllGoalTransactions = getAllGoalTransactions;
const getGoalTransactionById = async (req, res) => {
    try {
        const userId = req.user.userId;
        const id = parseInt(req.params.id);
        const transaction = await prisma_1.prisma.goalTransaction.findFirst({
            where: { id, goal: { userId } },
        });
        if (!transaction) {
            return res.status(404).json({ error: 'Goal transaction not found' });
        }
        const serialized = JSON.parse(JSON.stringify(transaction, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching goal transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getGoalTransactionById = getGoalTransactionById;
const createGoalTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = goalTransactionSchema.parse(req.body);
        // Ensure goal exists and belongs to user
        const goal = await prisma_1.prisma.goal.findFirst({ where: { id: data.goalId, userId } });
        if (!goal)
            return res.status(404).json({ error: 'Goal not found' });
        const result = await prisma_1.prisma.$transaction(async (tx) => {
            const created = await tx.goalTransaction.create({
                data: {
                    goalId: data.goalId,
                    amount: data.amount,
                    description: data.description,
                    occurredAt: data.occurredAt ? new Date(data.occurredAt) : new Date(),
                },
            });
            // Increment goal currentAmount
            await tx.goal.update({
                where: { id: data.goalId },
                data: { currentAmount: { increment: data.amount } },
            });
            return created;
        });
        const serialized = JSON.parse(JSON.stringify(result, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error creating goal transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createGoalTransaction = createGoalTransaction;
const updateGoalTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const id = parseInt(req.params.id);
        const data = goalTransactionSchema.partial().parse(req.body);
        const result = await prisma_1.prisma.$transaction(async (tx) => {
            const existing = await tx.goalTransaction.findFirst({ where: { id }, include: { goal: true } });
            if (!existing || existing.goal.userId !== userId)
                throw new Error('Not found');
            // If amount changes, adjust goal.currentAmount
            if (data.amount !== undefined && data.amount !== Number(existing.amount)) {
                const delta = data.amount - Number(existing.amount);
                await tx.goal.update({ where: { id: existing.goalId }, data: { currentAmount: { increment: delta } } });
            }
            const updated = await tx.goalTransaction.update({
                where: { id },
                data: {
                    ...(data.amount !== undefined && { amount: data.amount }),
                    ...(data.description !== undefined && { description: data.description }),
                    ...(data.occurredAt && { occurredAt: new Date(data.occurredAt) }),
                },
            });
            return updated;
        });
        const serialized = JSON.parse(JSON.stringify(result, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        if (error instanceof Error && error.message === 'Not found') {
            return res.status(404).json({ error: 'Goal transaction not found' });
        }
        console.error('Error updating goal transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateGoalTransaction = updateGoalTransaction;
const deleteGoalTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const id = parseInt(req.params.id);
        await prisma_1.prisma.$transaction(async (tx) => {
            const existing = await tx.goalTransaction.findFirst({ where: { id }, include: { goal: true } });
            if (!existing || existing.goal.userId !== userId)
                throw new Error('Not found');
            // Decrement goal currentAmount
            await tx.goal.update({ where: { id: existing.goalId }, data: { currentAmount: { decrement: existing.amount } } });
            await tx.goalTransaction.delete({ where: { id } });
        });
        res.json({ message: 'Goal transaction deleted successfully' });
    }
    catch (error) {
        if (error instanceof Error && error.message === 'Not found') {
            return res.status(404).json({ error: 'Goal transaction not found' });
        }
        console.error('Error deleting goal transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteGoalTransaction = deleteGoalTransaction;
//# sourceMappingURL=goalTransactionController.js.map