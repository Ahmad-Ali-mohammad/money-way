# Backend Setup Guide

## تشغيل قاعدة البيانات PostgreSQL

### الطريقة 1: باستخدام Docker (موصى بها) 🐳

1. **تشغيل Docker Desktop**
   ```powershell
   # تأكد أن Docker Desktop شغال
   # افتح Docker Desktop من قائمة Start
   ```

2. **تشغيل PostgreSQL**
   ```powershell
   cd backend
   docker-compose up -d
   ```

3. **التحقق من التشغيل**
   ```powershell
   docker ps
   # يجب أن ترى container اسمه finance_db
   ```

### الطريقة 2: تثبيت PostgreSQL مباشرة

1. **تحميل PostgreSQL**
   - من: https://www.postgresql.org/download/windows/
   - اختر PostgreSQL 16

2. **إنشاء قاعدة البيانات**
   ```sql
   createdb -U postgres finance_db
   ```

## تشغيل Migrations

```powershell
cd backend
npm run prisma:migrate
```

## Seed البيانات (اختياري)

```powershell
# يدوياً باستخدام psql
psql -U postgres -d finance_db -f prisma/seed.sql
```

## تشغيل Backend Server

```powershell
cd backend
npm run dev
```

Server سيشتغل على: http://localhost:4000

## API Endpoints الكاملة

### 🔐 Authentication
- `POST /api/auth/register` - تسجيل مستخدم جديد
- `POST /api/auth/login` - تسجيل الدخول

### 💰 Transactions
- `GET /api/transactions` - جلب جميع المعاملات
- `POST /api/transactions` - إنشاء معاملة
- `GET /api/transactions/:id` - جلب معاملة واحدة
- `PUT /api/transactions/:id` - تعديل معاملة
- `DELETE /api/transactions/:id` - حذف معاملة
- `GET /api/transactions/stats` - إحصائيات المعاملات

### 📂 Categories
- `GET /api/categories` - جلب الفئات
- `POST /api/categories` - إنشاء فئة
- `PUT /api/categories/:id` - تعديل فئة
- `DELETE /api/categories/:id` - حذف فئة

### 🏦 Accounts
- `GET /api/accounts` - جلب جميع الحسابات
- `POST /api/accounts` - إنشاء حساب
- `GET /api/accounts/:id` - جلب حساب واحد
- `PUT /api/accounts/:id` - تعديل حساب
- `DELETE /api/accounts/:id` - حذف حساب
- `GET /api/accounts/:id/balance` - جلب رصيد الحساب

### 💵 Budgets
- `GET /api/budgets` - جلب جميع الميزانيات
- `POST /api/budgets` - إنشاء ميزانية
- `GET /api/budgets/:id` - جلب ميزانية واحدة
- `PUT /api/budgets/:id` - تعديل ميزانية
- `DELETE /api/budgets/:id` - حذف ميزانية
- `GET /api/budgets/:id/progress` - متابعة تقدم الميزانية

### 🎯 Goals
- `GET /api/goals` - جلب جميع الأهداف
- `POST /api/goals` - إنشاء هدف
- `GET /api/goals/:id` - جلب هدف واحد
- `PUT /api/goals/:id` - تعديل هدف
- `DELETE /api/goals/:id` - حذف هدف
- `GET /api/goals/:id/progress` - متابعة تقدم الهدف
- `POST /api/goals/:id/add` - إضافة مبلغ للهدف

### 📊 Reports
- `GET /api/reports/summary` - ملخص مالي شامل
- `GET /api/reports/category-breakdown` - تفصيل حسب الفئات
- `GET /api/reports/monthly-trends` - اتجاهات شهرية
- `GET /api/reports/cash-flow` - التدفق النقدي

## البيئة المطلوبة

تأكد من وجود ملف `.env` في مجلد backend:

```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/finance_db?schema=public"
JWT_SECRET="your-super-secret-jwt-key-replace-in-production"
PORT=4000
NODE_ENV="development"
```

## استكشاف الأخطاء

### Backend لا يشتغل؟
```powershell
# تحقق من أن قاعدة البيانات شغالة
docker ps

# شوف logs
docker logs finance_db

# أعد تشغيل backend
cd backend
npm run dev
```

### Database Connection Error؟
```powershell
# تأكد أن PostgreSQL شغال على port 5432
netstat -an | findstr 5432

# جرب تشغيل Docker مرة ثانية
docker-compose down
docker-compose up -d
```
