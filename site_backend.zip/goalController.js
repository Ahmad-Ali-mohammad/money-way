"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addToGoal = exports.getGoalProgress = exports.deleteGoal = exports.updateGoal = exports.getGoalById = exports.createGoal = exports.getAllGoals = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
// Schema with explicit field validation
const goalSchema = zod_1.z.object({
    name: zod_1.z.string().min(1, 'Goal name is required'),
    targetAmount: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).transform(val => {
        const num = typeof val === 'string' ? parseFloat(val) : val;
        if (isNaN(num) || num <= 0)
            throw new Error('Target amount must be a positive number');
        return num;
    }),
    currentAmount: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).optional().transform(val => {
        if (val === undefined || val === null)
            return 0;
        const num = typeof val === 'string' ? parseFloat(val) : val;
        if (isNaN(num) || num < 0)
            throw new Error('Current amount must be a non-negative number');
        return num;
    }),
    deadline: zod_1.z.string().datetime().optional().nullable(),
    icon: zod_1.z.string().optional().nullable(),
});
// Fetch all goals sorted by deadline proximity (closest first)
const getAllGoals = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goals = await prisma_1.prisma.goal.findMany({
            where: { userId },
            orderBy: [
                { deadline: 'asc' }, // Closest deadline first
            ],
        });
        // Calculate progress for each goal
        const goalsWithProgress = goals.map(goal => {
            const progress = goal.targetAmount > 0
                ? Math.min((Number(goal.currentAmount) / Number(goal.targetAmount)) * 100, 100)
                : 0;
            return {
                ...goal,
                progress: Math.round(progress * 100) / 100,
                remaining: Number(goal.targetAmount) - Number(goal.currentAmount),
                isCompleted: goal.currentAmount >= goal.targetAmount,
            };
        });
        const serialized = JSON.parse(JSON.stringify(goalsWithProgress, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching goals:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllGoals = getAllGoals;
// Create goal with explicit field mapping
const createGoal = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = goalSchema.parse(req.body);
        // Explicit data mapping to prevent field injection
        const goal = await prisma_1.prisma.goal.create({
            data: {
                userId: userId,
                name: data.name,
                targetAmount: data.targetAmount,
                currentAmount: data.currentAmount || 0,
                deadline: data.deadline ? new Date(data.deadline) : null,
                icon: data.icon || null,
            },
        });
        const progress = goal.targetAmount > 0
            ? (Number(goal.currentAmount) / Number(goal.targetAmount)) * 100
            : 0;
        const response = {
            ...goal,
            progress: Math.round(progress * 100) / 100,
            remaining: Number(goal.targetAmount) - Number(goal.currentAmount),
            isCompleted: goal.currentAmount >= goal.targetAmount,
        };
        const serialized = JSON.parse(JSON.stringify(response, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: 'Validation failed',
                details: error.issues.map(e => ({ field: e.path.join('.'), message: e.message }))
            });
        }
        console.error('Error creating goal:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createGoal = createGoal;
const getGoalById = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goalId = parseInt(req.params.id);
        const goal = await prisma_1.prisma.goal.findFirst({
            where: {
                id: goalId,
                userId,
            },
        });
        if (!goal) {
            return res.status(404).json({ error: 'Goal not found' });
        }
        const serialized = JSON.parse(JSON.stringify(goal, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching goal:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getGoalById = getGoalById;
// Update goal with protection against currentAmount reset
const updateGoal = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goalId = parseInt(req.params.id);
        if (isNaN(goalId)) {
            return res.status(400).json({ error: 'Invalid goal ID' });
        }
        // Verify ownership
        const existing = await prisma_1.prisma.goal.findFirst({
            where: { id: goalId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Goal not found or access denied' });
        }
        const data = goalSchema.partial().parse(req.body);
        // Explicit data mapping with currentAmount protection
        const updateData = {};
        if (data.name !== undefined) {
            updateData.name = data.name;
        }
        if (data.targetAmount !== undefined) {
            updateData.targetAmount = data.targetAmount;
        }
        // Only update currentAmount if explicitly provided (protects against accidental reset)
        if (data.currentAmount !== undefined) {
            updateData.currentAmount = data.currentAmount;
        }
        if (data.deadline !== undefined) {
            updateData.deadline = data.deadline ? new Date(data.deadline) : null;
        }
        if (data.icon !== undefined) {
            updateData.icon = data.icon;
        }
        const updated = await prisma_1.prisma.goal.update({
            where: { id: goalId },
            data: updateData,
        });
        const progress = updated.targetAmount > 0
            ? (Number(updated.currentAmount) / Number(updated.targetAmount)) * 100
            : 0;
        const response = {
            ...updated,
            progress: Math.round(progress * 100) / 100,
            remaining: Number(updated.targetAmount) - Number(updated.currentAmount),
            isCompleted: updated.currentAmount >= updated.targetAmount,
        };
        const serialized = JSON.parse(JSON.stringify(response, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                error: 'Validation failed',
                details: error.issues.map(e => ({ field: e.path.join('.'), message: e.message }))
            });
        }
        console.error('Error updating goal:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateGoal = updateGoal;
// Securely delete goal after verifying ownership
const deleteGoal = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goalId = parseInt(req.params.id);
        if (isNaN(goalId)) {
            return res.status(400).json({ error: 'Invalid goal ID' });
        }
        // Verify ownership before deletion
        const existing = await prisma_1.prisma.goal.findFirst({
            where: { id: goalId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Goal not found or access denied' });
        }
        await prisma_1.prisma.goal.delete({
            where: { id: goalId },
        });
        res.json({
            message: 'Goal deleted successfully',
            deletedGoal: {
                id: existing.id.toString(),
                name: existing.name
            }
        });
    }
    catch (error) {
        console.error('Error deleting goal:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteGoal = deleteGoal;
const getGoalProgress = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goalId = parseInt(req.params.id);
        const goal = await prisma_1.prisma.goal.findFirst({
            where: { id: goalId, userId },
        });
        if (!goal) {
            return res.status(404).json({ error: 'Goal not found' });
        }
        const percentage = (Number(goal.currentAmount) / Number(goal.targetAmount)) * 100;
        const remaining = Number(goal.targetAmount) - Number(goal.currentAmount);
        const isCompleted = goal.currentAmount >= goal.targetAmount;
        const serialized = {
            goalId: goal.id.toString(),
            name: goal.name,
            targetAmount: Number(goal.targetAmount),
            currentAmount: Number(goal.currentAmount),
            remaining,
            percentage: Math.round(percentage * 100) / 100,
            isCompleted,
            targetDate: goal.deadline,
        };
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching goal progress:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getGoalProgress = getGoalProgress;
const addToGoal = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goalId = parseInt(req.params.id);
        const { amount } = zod_1.z.object({ amount: zod_1.z.number().positive() }).parse(req.body);
        const goal = await prisma_1.prisma.goal.findFirst({
            where: { id: goalId, userId },
        });
        if (!goal) {
            return res.status(404).json({ error: 'Goal not found' });
        }
        const updated = await prisma_1.prisma.goal.update({
            where: { id: goalId },
            data: {
                currentAmount: {
                    increment: amount,
                },
            },
        });
        const serialized = JSON.parse(JSON.stringify(updated, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error adding to goal:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.addToGoal = addToGoal;
//# sourceMappingURL=goalController.js.map