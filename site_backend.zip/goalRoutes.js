"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const goalController_1 = require("../controllers/goalController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/', goalController_1.getAllGoals);
router.post('/', goalController_1.createGoal);
router.get('/:id', goalController_1.getGoalById);
router.put('/:id', goalController_1.updateGoal);
router.delete('/:id', goalController_1.deleteGoal);
router.get('/:id/progress', goalController_1.getGoalProgress);
router.post('/:id/add', goalController_1.addToGoal);
exports.default = router;
//# sourceMappingURL=goalRoutes.js.map