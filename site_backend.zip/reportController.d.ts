import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getFinancialSummary: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getCategoryBreakdown: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getMonthlyTrends: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getCashFlow: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getRiskAnalysis: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getProjectKPIs: (req: AuthRequest, res: Response) => Promise<void>;
