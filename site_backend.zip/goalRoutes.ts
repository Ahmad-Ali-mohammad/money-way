import { Router } from 'express';
import {
  getAllGoals,
  createGoal,
  getGoalById,
  updateGoal,
  deleteGoal,
  getGoalProgress,
  addToGoal,
} from '../controllers/goalController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.use(authMiddleware);

router.get('/', getAllGoals);
router.post('/', createGoal);
router.get('/:id', getGoalById);
router.put('/:id', updateGoal);
router.delete('/:id', deleteGoal);
router.get('/:id/progress', getGoalProgress);
router.post('/:id/add', addToGoal);

export default router;
