# AdaptiveFi Backend

Financial management backend built with Node.js, Express, Prisma, and PostgreSQL.

## Prerequisites

- Node.js 18+
- PostgreSQL 14+
- npm or yarn

## Setup

1. Install dependencies:
```bash
npm install
```

2. Configure environment variables:
```bash
cp .env.example .env
# Edit .env and set your DATABASE_URL
```

3. Run database migrations:
```bash
npm run prisma:migrate
```

4. Generate Prisma Client:
```bash
npm run prisma:generate
```

5. (Optional) Seed the database:
```bash
# Using psql
psql -U postgres -d finance_db -f prisma/seed.sql
```

## Development

Start the development server:
```bash
npm run dev
```

The API will be available at `http://localhost:4000`

## Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build TypeScript to JavaScript
- `npm start` - Start production server
- `npm run prisma:generate` - Generate Prisma Client
- `npm run prisma:migrate` - Run database migrations
- `npm run prisma:studio` - Open Prisma Studio (database GUI)

## API Endpoints

### 🔐 Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### 💰 Transactions (Protected)
- `GET /api/transactions` - Get all transactions (with filters)
- `POST /api/transactions` - Create transaction
- `GET /api/transactions/stats` - Get transaction statistics
- `GET /api/transactions/:id` - Get transaction by ID
- `PUT /api/transactions/:id` - Update transaction
- `DELETE /api/transactions/:id` - Delete transaction

### 📂 Categories (Protected)
- `GET /api/categories` - Get all categories (hierarchical)
- `POST /api/categories` - Create category
- `PUT /api/categories/:id` - Update category
- `DELETE /api/categories/:id` - Delete category

### 🏦 Accounts (Protected)
- `GET /api/accounts` - Get all accounts
- `POST /api/accounts` - Create account
- `GET /api/accounts/:id` - Get account with recent transactions
- `PUT /api/accounts/:id` - Update account
- `DELETE /api/accounts/:id` - Delete account
- `GET /api/accounts/:id/balance` - Get account balance

### 💵 Budgets (Protected - ✨ **Advanced Adaptive System**)
- `GET /api/budgets` - Get all budgets
- `POST /api/budgets` - Create budget (supports adaptive rules & percentage-based)
- `GET /api/budgets/:id` - Get budget details
- `PUT /api/budgets/:id` - Update budget
- `DELETE /api/budgets/:id` - Delete budget
- `GET /api/budgets/:id/progress` - Get budget progress with auto-calculation
- `GET /api/budgets/recalculate` - **NEW** Recalculate all adaptive budgets
- `POST /api/budgets/surplus-transfer` - **NEW** Transfer surplus to goals

### 🎯 Goals (Protected)
- `GET /api/goals` - Get all savings goals
- `POST /api/goals` - Create goal
- `GET /api/goals/:id` - Get goal details
- `PUT /api/goals/:id` - Update goal
- `DELETE /api/goals/:id` - Delete goal
- `GET /api/goals/:id/progress` - Get goal progress
- `POST /api/goals/:id/add` - Add amount to goal

### 📊 Reports & Analytics (Protected)
- `GET /api/reports/summary` - Comprehensive financial summary
- `GET /api/reports/category-breakdown` - Spending by category
- `GET /api/reports/monthly-trends` - Monthly trends analysis
- `GET /api/reports/cash-flow` - Cash flow analysis

### 💼 Projects (Protected - Feasibility Analysis)
- `GET /api/projects` - Get all projects
- `POST /api/projects` - Create project
- `GET /api/projects/:id` - Get project with metrics
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project
- `GET /api/projects/:id/analysis` - Get detailed feasibility analysis
  - Break-even point calculation
  - ROI analysis (3-year projections)
  - Risk assessment with scoring
  - Business recommendations

### 🔔 Alerts (Protected - Smart Notifications)
- `GET /api/alerts` - Get all alerts (filter by read status)
- `POST /api/alerts` - Create custom alert
- `GET /api/alerts/unread-count` - Get unread count
- `PUT /api/alerts/:id/read` - Mark as read
- `PUT /api/alerts/mark-all-read` - Mark all as read
- `DELETE /api/alerts/:id` - Delete alert
- `POST /api/alerts/check-budgets` - Generate budget alerts
- `POST /api/alerts/check-goals` - Generate goal milestone alerts

### ✅ Health Check
- `GET /api/health` - Server health status

**Total: 50+ Endpoints across 9 modules**

## Database Schema

See `prisma/schema.prisma` for the complete database schema.

## Authentication

All protected routes require a JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

Tokens are obtained via the `/api/auth/login` or `/api/auth/register` endpoints.
