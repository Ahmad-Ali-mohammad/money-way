"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const accountController_1 = require("../controllers/accountController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.use(authMiddleware_1.authMiddleware);
router.get('/', accountController_1.getAllAccounts);
router.post('/', accountController_1.createAccount);
router.get('/:id', accountController_1.getAccountById);
router.put('/:id', accountController_1.updateAccount);
router.delete('/:id', accountController_1.deleteAccount);
router.get('/:id/balance', accountController_1.getAccountBalance);
exports.default = router;
//# sourceMappingURL=accountRoutes.js.map