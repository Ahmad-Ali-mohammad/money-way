import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const supportedCurrencies: {
    USD: {
        symbol: string;
        name: string;
        format: string;
    };
    EUR: {
        symbol: string;
        name: string;
        format: string;
    };
    GBP: {
        symbol: string;
        name: string;
        format: string;
    };
    JPY: {
        symbol: string;
        name: string;
        format: string;
    };
    CNY: {
        symbol: string;
        name: string;
        format: string;
    };
    SAR: {
        symbol: string;
        name: string;
        format: string;
    };
    AED: {
        symbol: string;
        name: string;
        format: string;
    };
    EGP: {
        symbol: string;
        name: string;
        format: string;
    };
    CAD: {
        symbol: string;
        name: string;
        format: string;
    };
    AUD: {
        symbol: string;
        name: string;
        format: string;
    };
};
export declare const getSupportedCurrencies: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getUserCurrency: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const setUserCurrency: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const convertCurrency: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const formatAmount: (amount: number, currencyCode: string) => string;
