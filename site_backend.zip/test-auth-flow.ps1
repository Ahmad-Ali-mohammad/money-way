# Test Registration and Login Flow
Write-Host "`n🧪 اختبار التسجيل وتسجيل الدخول..." -ForegroundColor Cyan
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Gray

# 1. Test Registration (New User)
Write-Host "`n1️⃣ اختبار التسجيل (مستخدم جديد)..." -ForegroundColor Yellow
Write-Host "   البريد: newuser@test.com" -ForegroundColor White
Write-Host "   الاسم: مستخدم تجريبي" -ForegroundColor White

$registerData = @{
    email = "newuser@test.com"
    password = "Test123456"
    name = "مستخدم تجريبي"
    currency = "SAR"
} | ConvertTo-Json

try {
    $registerResponse = Invoke-RestMethod -Uri "http://localhost:4000/api/auth/register" `
        -Method Post `
        -Body $registerData `
        -ContentType "application/json"
    
    Write-Host "   ✅ التسجيل نجح!" -ForegroundColor Green
    Write-Host "   معرف المستخدم: $($registerResponse.user.id)" -ForegroundColor Cyan
    Write-Host "   البريد: $($registerResponse.user.email)" -ForegroundColor Cyan
    Write-Host "   الاسم: $($registerResponse.user.name)" -ForegroundColor Cyan
    Write-Host "   التوكن: $($registerResponse.token.Substring(0,40))..." -ForegroundColor Gray
    
} catch {
    if ($_.Exception.Message -like "*400*") {
        Write-Host "   ℹ️ المستخدم موجود مسبقاً (هذا متوقع)" -ForegroundColor Yellow
    } else {
        Write-Host "   ❌ خطأ في التسجيل: $($_.Exception.Message)" -ForegroundColor Red
        if ($_.ErrorDetails) {
            Write-Host "   التفاصيل: $($_.ErrorDetails.Message)" -ForegroundColor Red
        }
    }
}

# 2. Test Login with Seeded User
Write-Host "`n2️⃣ اختبار تسجيل الدخول (مستخدم من البيانات التجريبية)..." -ForegroundColor Yellow
Write-Host "   البريد: ahmed@example.com" -ForegroundColor White

$loginData = @{
    email = "ahmed@example.com"
    password = "password123"
} | ConvertTo-Json

try {
    $loginResponse = Invoke-RestMethod -Uri "http://localhost:4000/api/auth/login" `
        -Method Post `
        -Body $loginData `
        -ContentType "application/json"
    
    Write-Host "   ✅ تسجيل الدخول نجح!" -ForegroundColor Green
    Write-Host "   المستخدم: $($loginResponse.user.name)" -ForegroundColor Cyan
    Write-Host "   البريد: $($loginResponse.user.email)" -ForegroundColor Cyan
    Write-Host "   معرف المستخدم: $($loginResponse.user.id)" -ForegroundColor Cyan
    
    $token = $loginResponse.token
    Write-Host "   التوكن: $($token.Substring(0,40))..." -ForegroundColor Gray
    
    # 3. Test accessing protected data
    Write-Host "`n3️⃣ اختبار الوصول للبيانات المحمية..." -ForegroundColor Yellow
    
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type" = "application/json"
    }
    
    # Get user profile
    $profile = Invoke-RestMethod -Uri "http://localhost:4000/api/auth/profile" `
        -Method Get `
        -Headers $headers
    
    Write-Host "   ✅ استرجاع الملف الشخصي نجح!" -ForegroundColor Green
    Write-Host "   الاسم: $($profile.name)" -ForegroundColor White
    Write-Host "   البريد: $($profile.email)" -ForegroundColor White
    Write-Host "   العملة: $($profile.currency)" -ForegroundColor White
    
    # Get accounts
    $accounts = Invoke-RestMethod -Uri "http://localhost:4000/api/accounts" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n   ✅ استرجاع الحسابات نجح!" -ForegroundColor Green
    Write-Host "   عدد الحسابات: $($accounts.Count)" -ForegroundColor White
    foreach ($account in $accounts) {
        $balanceColor = if ($account.balance -ge 0) { "Green" } else { "Red" }
        Write-Host "      • $($account.name): " -NoNewline -ForegroundColor White
        Write-Host "$($account.balance) $($account.currency)" -ForegroundColor $balanceColor
    }
    
    # Get transactions
    $transactions = Invoke-RestMethod -Uri "http://localhost:4000/api/transactions?limit=5" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n   ✅ استرجاع المعاملات نجح!" -ForegroundColor Green
    Write-Host "   عدد المعاملات: $($transactions.Count)" -ForegroundColor White
    
    # Get budgets
    $budgets = Invoke-RestMethod -Uri "http://localhost:4000/api/budgets" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n   ✅ استرجاع الميزانيات نجح!" -ForegroundColor Green
    Write-Host "   عدد الميزانيات: $($budgets.Count)" -ForegroundColor White
    foreach ($budget in $budgets) {
        $percentage = if ($budget.amount -gt 0) { 
            [math]::Round(($budget.spent / $budget.amount) * 100, 1) 
        } else { 0 }
        Write-Host "      • $($budget.name): $($budget.spent)/$($budget.amount) ($percentage%)" -ForegroundColor White
    }
    
    Write-Host "`n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Gray
    Write-Host "🎉 جميع الاختبارات نجحت!" -ForegroundColor Green
    Write-Host ""
    Write-Host "📊 ملخص النتائج:" -ForegroundColor Cyan
    Write-Host "   ✅ قاعدة البيانات: متصلة ومفعلة" -ForegroundColor Green
    Write-Host "   ✅ بيانات الاختبار: تم إدراجها بنجاح" -ForegroundColor Green
    Write-Host "   ✅ التسجيل: يعمل بشكل صحيح" -ForegroundColor Green
    Write-Host "   ✅ تسجيل الدخول: يعمل بشكل صحيح" -ForegroundColor Green
    Write-Host "   ✅ المصادقة: تعمل بشكل صحيح" -ForegroundColor Green
    Write-Host "   ✅ API المحمي: يعمل بشكل صحيح" -ForegroundColor Green
    Write-Host ""
    
} catch {
    Write-Host "   ❌ خطأ: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails) {
        Write-Host "   التفاصيل: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
    exit 1
}
