import './setup';
import request from 'supertest';
import app from '../index';
import { describe, it, expect } from 'vitest';

describe('Auth', () => {
  it('should login seeded user and return token', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'ahmed@example.com', password: 'password123' })
      .set('Accept', 'application/json');

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body).toHaveProperty('user');
    expect(res.body.user).toHaveProperty('email', 'ahmed@example.com');
  });
});
