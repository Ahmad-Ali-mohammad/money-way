"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startRecurringTransactionsScheduler = startRecurringTransactionsScheduler;
exports.processRecurringTransactions = processRecurringTransactions;
const node_cron_1 = __importDefault(require("node-cron"));
const prisma_1 = require("../lib/prisma");
function parseRecurrenceRule(rule) {
    try {
        return JSON.parse(rule);
    }
    catch {
        return { frequency: 'monthly' };
    }
}
function calculateNextOccurrence(lastDate, rule) {
    const next = new Date(lastDate);
    const interval = rule.interval || 1;
    switch (rule.frequency) {
        case 'daily':
            next.setDate(next.getDate() + interval);
            break;
        case 'weekly':
            next.setDate(next.getDate() + (7 * interval));
            break;
        case 'monthly':
            next.setMonth(next.getMonth() + interval);
            break;
        case 'yearly':
            next.setFullYear(next.getFullYear() + interval);
            break;
    }
    return next;
}
async function processRecurringTransactions() {
    console.log('[Scheduler] Processing recurring transactions...');
    try {
        const now = new Date();
        // Find all recurring transactions that are due
        const dueTransactions = await prisma_1.prisma.transaction.findMany({
            where: {
                isRecurring: true,
                nextOccurrence: {
                    lte: now,
                },
                recurringParentId: null, // Only parent transactions
            },
            include: {
                account: true,
                category: true,
            },
        });
        console.log(`[Scheduler] Found ${dueTransactions.length} due recurring transactions`);
        for (const parent of dueTransactions) {
            try {
                const rule = parseRecurrenceRule(parent.recurrenceRule || '{}');
                // Create new transaction instance
                const newTransaction = await prisma_1.prisma.transaction.create({
                    data: {
                        userId: parent.userId,
                        accountId: parent.accountId,
                        amount: parent.amount,
                        currency: parent.currency,
                        type: parent.type,
                        categoryId: parent.categoryId,
                        notes: parent.notes,
                        occurredAt: parent.nextOccurrence || now,
                        isRecurring: false,
                        recurringParentId: parent.id,
                    },
                });
                // Update account balance
                const balanceChange = parent.type === 'income'
                    ? Number(parent.amount)
                    : -Number(parent.amount);
                await prisma_1.prisma.account.update({
                    where: { id: parent.accountId },
                    data: {
                        balance: {
                            increment: balanceChange,
                        },
                    },
                });
                // Update parent's next occurrence
                const nextOccurrence = calculateNextOccurrence(parent.nextOccurrence || now, rule);
                await prisma_1.prisma.transaction.update({
                    where: { id: parent.id },
                    data: {
                        nextOccurrence,
                    },
                });
                console.log(`[Scheduler] Created recurring transaction ${newTransaction.id} from parent ${parent.id}`);
                // Create alert for user
                await prisma_1.prisma.alert.create({
                    data: {
                        userId: parent.userId,
                        type: 'income_received',
                        message: `Recurring transaction "${parent.notes || 'Transaction'}" processed: ${parent.currency} ${parent.amount}`,
                        severity: 'low',
                    },
                });
            }
            catch (error) {
                console.error(`[Scheduler] Error processing recurring transaction ${parent.id}:`, error);
            }
        }
        console.log('[Scheduler] Recurring transactions processing completed');
    }
    catch (error) {
        console.error('[Scheduler] Error in processRecurringTransactions:', error);
    }
}
function startRecurringTransactionsScheduler() {
    // Run every day at 00:05 AM
    node_cron_1.default.schedule('5 0 * * *', async () => {
        await processRecurringTransactions();
    });
    console.log('[Scheduler] Recurring transactions scheduler started (runs daily at 00:05 AM)');
}
//# sourceMappingURL=recurringScheduler.js.map