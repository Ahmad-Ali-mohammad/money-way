"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatAmount = exports.convertCurrency = exports.setUserCurrency = exports.getUserCurrency = exports.getSupportedCurrencies = exports.supportedCurrencies = void 0;
const prisma_1 = require("../lib/prisma");
// Supported currencies with their symbols and formats
exports.supportedCurrencies = {
    USD: { symbol: '$', name: 'US Dollar', format: 'en-US' },
    EUR: { symbol: '€', name: 'Euro', format: 'de-DE' },
    GBP: { symbol: '£', name: 'British Pound', format: 'en-GB' },
    JPY: { symbol: '¥', name: 'Japanese Yen', format: 'ja-JP' },
    CNY: { symbol: '¥', name: 'Chinese Yuan', format: 'zh-CN' },
    SAR: { symbol: 'ر.س', name: 'Saudi Riyal', format: 'ar-SA' },
    AED: { symbol: 'د.إ', name: 'UAE Dirham', format: 'ar-AE' },
    EGP: { symbol: 'ج.م', name: 'Egyptian Pound', format: 'ar-EG' },
    CAD: { symbol: 'C$', name: 'Canadian Dollar', format: 'en-CA' },
    AUD: { symbol: 'A$', name: 'Australian Dollar', format: 'en-AU' },
};
// Exchange rates (in real app, fetch from API like exchangerate-api.com)
const exchangeRates = {
    USD: 1.0,
    EUR: 0.92,
    GBP: 0.79,
    JPY: 149.50,
    CNY: 7.24,
    SAR: 3.75,
    AED: 3.67,
    EGP: 30.90,
    CAD: 1.36,
    AUD: 1.52,
};
// Get all supported currencies
const getSupportedCurrencies = async (req, res) => {
    try {
        const currencies = Object.entries(exports.supportedCurrencies).map(([code, info]) => ({
            code,
            ...info,
            exchangeRate: exchangeRates[code],
        }));
        res.json({
            currencies,
            defaultCurrency: 'USD',
        });
    }
    catch (error) {
        console.error('Get currencies error:', error);
        res.status(500).json({ error: 'Failed to fetch currencies' });
    }
};
exports.getSupportedCurrencies = getSupportedCurrencies;
// Get user's preferred currency
const getUserCurrency = async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        const user = await prisma_1.prisma.user.findUnique({
            where: { id: userId },
            select: {
                metadata: true,
            },
        });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        let currency = 'USD';
        try {
            if (user.metadata) {
                const metadata = typeof user.metadata === 'string' ? JSON.parse(user.metadata) : user.metadata;
                currency = metadata.preferredCurrency || 'USD';
            }
        }
        catch (e) {
            console.error('Error parsing metadata:', e);
        }
        const currencyInfo = exports.supportedCurrencies[currency];
        res.json({
            currency,
            ...currencyInfo,
            exchangeRate: exchangeRates[currency],
        });
    }
    catch (error) {
        console.error('Get user currency error:', error);
        res.status(500).json({ error: 'Failed to fetch user currency' });
    }
};
exports.getUserCurrency = getUserCurrency;
// Set user's preferred currency
const setUserCurrency = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const { currency } = req.body;
        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        if (!currency || !exports.supportedCurrencies[currency]) {
            return res.status(400).json({ error: 'Invalid currency code' });
        }
        const user = await prisma_1.prisma.user.findUnique({
            where: { id: userId },
            select: { metadata: true },
        });
        let metadata = {};
        try {
            if (user?.metadata) {
                metadata = typeof user.metadata === 'string' ? JSON.parse(user.metadata) : user.metadata;
            }
        }
        catch (e) {
            console.error('Error parsing existing metadata:', e);
        }
        metadata.preferredCurrency = currency;
        await prisma_1.prisma.user.update({
            where: { id: userId },
            data: {
                metadata: JSON.stringify(metadata),
            },
        });
        const currencyInfo = exports.supportedCurrencies[currency];
        res.json({
            message: 'Currency updated successfully',
            currency,
            ...currencyInfo,
            exchangeRate: exchangeRates[currency],
        });
    }
    catch (error) {
        console.error('Set user currency error:', error);
        res.status(500).json({ error: 'Failed to update currency' });
    }
};
exports.setUserCurrency = setUserCurrency;
// Convert amount between currencies
const convertCurrency = async (req, res) => {
    try {
        const { amount, from, to } = req.query;
        if (!amount || !from || !to) {
            return res.status(400).json({ error: 'Missing required parameters: amount, from, to' });
        }
        const fromRate = exchangeRates[from];
        const toRate = exchangeRates[to];
        if (!fromRate || !toRate) {
            return res.status(400).json({ error: 'Invalid currency code' });
        }
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount)) {
            return res.status(400).json({ error: 'Invalid amount' });
        }
        // Convert to USD first, then to target currency
        const usdAmount = numAmount / fromRate;
        const convertedAmount = usdAmount * toRate;
        res.json({
            from: from,
            to: to,
            amount: numAmount,
            converted: parseFloat(convertedAmount.toFixed(2)),
            rate: parseFloat((toRate / fromRate).toFixed(4)),
        });
    }
    catch (error) {
        console.error('Convert currency error:', error);
        res.status(500).json({ error: 'Failed to convert currency' });
    }
};
exports.convertCurrency = convertCurrency;
// Format amount with currency
const formatAmount = (amount, currencyCode) => {
    const currency = exports.supportedCurrencies[currencyCode];
    if (!currency)
        return `$${amount.toFixed(2)}`;
    try {
        return new Intl.NumberFormat(currency.format, {
            style: 'currency',
            currency: currencyCode,
        }).format(amount);
    }
    catch (e) {
        return `${currency.symbol}${amount.toFixed(2)}`;
    }
};
exports.formatAmount = formatAmount;
//# sourceMappingURL=currencyController.js.map