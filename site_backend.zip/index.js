"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const prisma_1 = require("./lib/prisma");
const authRoutes_1 = __importDefault(require("./routes/authRoutes"));
const transactionRoutes_1 = __importDefault(require("./routes/transactionRoutes"));
const categoryRoutes_1 = __importDefault(require("./routes/categoryRoutes"));
const accountRoutes_1 = __importDefault(require("./routes/accountRoutes"));
const budgetRoutes_1 = __importDefault(require("./routes/budgetRoutes"));
const budgetCategoryRoutes_1 = __importDefault(require("./routes/budgetCategoryRoutes"));
const goalRoutes_1 = __importDefault(require("./routes/goalRoutes"));
const goalTransactionRoutes_1 = __importDefault(require("./routes/goalTransactionRoutes"));
const reportRoutes_1 = __importDefault(require("./routes/reportRoutes"));
const projectRoutes_1 = __importDefault(require("./routes/projectRoutes"));
const alertRoutes_1 = __importDefault(require("./routes/alertRoutes"));
const tagRoutes_1 = __importDefault(require("./routes/tagRoutes"));
const dashboardRoutes_1 = __importDefault(require("./routes/dashboardRoutes"));
const receiptRoutes_1 = __importDefault(require("./routes/receiptRoutes"));
const currencyRoutes_1 = __importDefault(require("./routes/currencyRoutes"));
const recurringScheduler_1 = require("./services/recurringScheduler");
dotenv_1.default.config();
// Ensure JWT secret is set to avoid running with insecure defaults
if (!process.env.JWT_SECRET) {
    console.error('FATAL: JWT_SECRET environment variable is not set. Set JWT_SECRET to a strong secret before starting the server.');
    process.exit(1);
}
const app = (0, express_1.default)();
const PORT = process.env.PORT || 4000;
// CORS Configuration - Allow all origins during development
app.use((0, cors_1.default)({
    origin: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express_1.default.json());
// Routes
app.use('/api/auth', authRoutes_1.default);
app.use('/api/transactions', transactionRoutes_1.default);
app.use('/api/categories', categoryRoutes_1.default);
app.use('/api/accounts', accountRoutes_1.default);
app.use('/api/budgets', budgetRoutes_1.default);
app.use('/api/budget-categories', budgetCategoryRoutes_1.default);
app.use('/api/goals', goalRoutes_1.default);
app.use('/api/goal-transactions', goalTransactionRoutes_1.default);
app.use('/api/reports', reportRoutes_1.default);
app.use('/api/projects', projectRoutes_1.default);
app.use('/api/alerts', alertRoutes_1.default);
app.use('/api/tags', tagRoutes_1.default);
app.use('/api/dashboard', dashboardRoutes_1.default);
app.use('/api/receipts', receiptRoutes_1.default);
app.use('/api/currencies', currencyRoutes_1.default);
// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});
// Sample users endpoint
app.get('/api/users', async (req, res) => {
    try {
        const users = await prisma_1.prisma.user.findMany({
            take: 10,
            select: {
                id: true,
                email: true,
                name: true,
                createdAt: true
            }
        });
        // Handle BigInt serialization
        const serializedUsers = JSON.parse(JSON.stringify(users, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serializedUsers);
    }
    catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
if (process.env.NODE_ENV !== 'test') {
    app.listen(PORT, () => {
        console.log(`🚀 Backend server running on http://localhost:${PORT}`);
        console.log(`📊 API available at http://localhost:${PORT}/api`);
        console.log(`⏰ Recurring transactions scheduler active`);
        // Start schedulers
        (0, recurringScheduler_1.startRecurringTransactionsScheduler)();
    });
}
exports.default = app;
//# sourceMappingURL=index.js.map