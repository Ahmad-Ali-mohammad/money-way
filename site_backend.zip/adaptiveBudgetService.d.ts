export declare function calculateAdaptiveBudgetAmount(userId: number, budgetId: number): Promise<number>;
export declare function recalculateAllAdaptiveBudgets(userId: number): Promise<({
    budgetId: number;
    name: string;
    oldAmount: number;
    newAmount: number;
    adjusted: boolean;
    amount?: undefined;
} | {
    budgetId: number;
    name: string;
    amount: number;
    adjusted: boolean;
    oldAmount?: undefined;
    newAmount?: undefined;
})[]>;
export declare function checkBudgetSurplusTransfer(userId: number): Promise<void>;
