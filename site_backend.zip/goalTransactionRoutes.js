"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const goalTransactionController_1 = require("../controllers/goalTransactionController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
// Apply authentication middleware to all routes
router.use(authMiddleware_1.authMiddleware);
// GET /api/goal-transactions - Get all goal transactions (optional goalId query param)
router.get('/', goalTransactionController_1.getAllGoalTransactions);
// GET /api/goal-transactions/:id - Get goal transaction by ID
router.get('/:id', goalTransactionController_1.getGoalTransactionById);
// POST /api/goal-transactions - Create new goal transaction
router.post('/', goalTransactionController_1.createGoalTransaction);
// PUT /api/goal-transactions/:id - Update goal transaction
router.put('/:id', goalTransactionController_1.updateGoalTransaction);
// DELETE /api/goal-transactions/:id - Delete goal transaction
router.delete('/:id', goalTransactionController_1.deleteGoalTransaction);
exports.default = router;
//# sourceMappingURL=goalTransactionRoutes.js.map