import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getAllReceipts: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getReceiptById: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createReceipt: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateReceipt: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteReceipt: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
