import { Router } from 'express';
import {
  getFinancialSummary,
  getCategoryBreakdown,
  getMonthlyTrends,
  getCashFlow,
  getRiskAnalysis,
  getProjectKPIs,
} from '../controllers/reportController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.use(authMiddleware);

router.get('/summary', getFinancialSummary);
router.get('/category-breakdown', getCategoryBreakdown);
router.get('/monthly-trends', getMonthlyTrends);
router.get('/cash-flow', getCashFlow);
router.get('/risk-analysis', getRiskAnalysis);
router.get('/kpis', getProjectKPIs);
router.get('/kpis/:projectId', getProjectKPIs);

export default router;
