import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getAllAccounts: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createAccount: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getAccountById: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateAccount: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteAccount: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getAccountBalance: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
