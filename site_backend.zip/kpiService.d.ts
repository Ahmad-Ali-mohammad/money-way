export interface ProjectKPIs {
    roi: number;
    irr: number;
    npv: number;
    profitabilityRatio: number;
    paybackPeriod: number;
    breakEvenPoint: number;
}
export interface OverallKPIs {
    totalROI: number;
    averageIRR: number;
    totalNPV: number;
    portfolioProfitability: number;
    riskAdjustedReturn: number;
}
export declare function calculateProjectKPIs(projectId: number): Promise<ProjectKPIs>;
export declare function calculateOverallKPIs(userId: number): Promise<OverallKPIs>;
