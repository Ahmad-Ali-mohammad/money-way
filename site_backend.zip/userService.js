"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedUserData = seedUserData;
const prisma_1 = require("../lib/prisma");
async function seedUserData(userId) {
    // 1. Create Default Categories
    const categories = [
        { name: 'Salary', type: 'income' },
        { name: 'Freelance', type: 'income' },
        { name: 'Housing', type: 'expense' },
        { name: 'Food & Dining', type: 'expense' },
        { name: 'Transportation', type: 'expense' },
        { name: 'Utilities', type: 'expense' },
        { name: 'Health', type: 'expense' },
        { name: 'Entertainment', type: 'expense' },
        { name: 'Shopping', type: 'expense' },
        { name: 'Savings', type: 'expense' },
    ];
    await Promise.all(categories.map(cat => prisma_1.prisma.category.create({
        data: {
            name: cat.name,
            type: cat.type,
            userId,
        }
    })));
    const userCategories = await prisma_1.prisma.category.findMany({ where: { userId } });
    const foodCat = userCategories.find(c => c.name === 'Food & Dining');
    const transportCat = userCategories.find(c => c.name === 'Transportation');
    // 2. Create Default Account
    await prisma_1.prisma.account.create({
        data: {
            userId,
            name: 'Main Wallet',
            type: 'cash',
            balance: 0,
            currency: 'USD',
        }
    });
    // 3. Create Default Savings Goal
    await prisma_1.prisma.goal.create({
        data: {
            userId,
            name: 'Emergency Fund',
            targetAmount: 5000,
            currentAmount: 0,
            deadline: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
        }
    });
    // 4. Create Initial Adaptive Budgets (Strategies)
    if (foodCat) {
        await prisma_1.prisma.budget.create({
            data: {
                userId,
                categoryId: foodCat.id,
                name: 'Food Monthly Budget',
                amount: 0, // Will be calculated adaptively
                isAdaptive: true,
                isPercentage: true,
                percentage: 15, // 15% of income for food
                adaptiveRule: JSON.stringify({ basePercentage: 15, maxAmount: 1000 }),
            }
        });
    }
    if (transportCat) {
        await prisma_1.prisma.budget.create({
            data: {
                userId,
                categoryId: transportCat.id,
                name: 'Transportation Budget',
                amount: 0,
                isAdaptive: true,
                isPercentage: true,
                percentage: 10,
                adaptiveRule: JSON.stringify({ basePercentage: 10, maxAmount: 500 }),
            }
        });
    }
    // 5. Create a Welcome Alert
    await prisma_1.prisma.alert.create({
        data: {
            userId,
            type: 'custom',
            message: 'Welcome to AdaptiveFi! We have set up basic categories and an Emergency Fund goal for you. Start by adding your first transaction.',
            severity: 'low',
        }
    });
}
//# sourceMappingURL=userService.js.map