import { Router } from 'express';
import {
  getAllAlerts,
  createAlert,
  markAsRead,
  markAllAsRead,
  deleteAlert,
  getUnreadCount,
  checkBudgetAlerts,
  checkGoalAlerts,
} from '../controllers/alertController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.use(authMiddleware);

router.get('/', getAllAlerts);
router.post('/', createAlert);
router.get('/unread-count', getUnreadCount);
router.put('/:id/read', markAsRead);
router.patch('/:id/read', markAsRead);
router.put('/mark-all-read', markAllAsRead);
router.delete('/:id', deleteAlert);

// Smart alert generation endpoints
router.post('/check-budgets', checkBudgetAlerts);
router.post('/check-goals', checkGoalAlerts);

export default router;
