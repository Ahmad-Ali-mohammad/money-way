"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeTagFromTransaction = exports.addTagToTransaction = exports.deleteTag = exports.updateTag = exports.createTag = exports.getAllTags = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const tagSchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(50),
    color: zod_1.z.string().optional(),
});
const getAllTags = async (req, res) => {
    try {
        const userId = req.user.userId;
        const tags = await prisma_1.prisma.tag.findMany({
            where: { userId },
            orderBy: { name: 'asc' },
            include: {
                _count: {
                    select: { transactions: true },
                },
            },
        });
        const serialized = JSON.parse(JSON.stringify(tags, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching tags:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllTags = getAllTags;
const createTag = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = tagSchema.parse(req.body);
        // Check if tag already exists
        const existing = await prisma_1.prisma.tag.findFirst({
            where: {
                userId,
                name: data.name,
            },
        });
        if (existing) {
            return res.status(400).json({ error: 'Tag already exists' });
        }
        const tag = await prisma_1.prisma.tag.create({
            data: {
                userId,
                name: data.name,
                color: data.color,
            },
        });
        const serialized = JSON.parse(JSON.stringify(tag, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error creating tag:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createTag = createTag;
const updateTag = async (req, res) => {
    try {
        const userId = req.user.userId;
        const tagId = parseInt(req.params.id);
        const data = tagSchema.partial().parse(req.body);
        const existing = await prisma_1.prisma.tag.findFirst({
            where: { id: tagId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Tag not found' });
        }
        const updated = await prisma_1.prisma.tag.update({
            where: { id: tagId },
            data: {
                ...(data.name && { name: data.name }),
                ...(data.color !== undefined && { color: data.color }),
            },
        });
        const serialized = JSON.parse(JSON.stringify(updated, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error updating tag:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.updateTag = updateTag;
const deleteTag = async (req, res) => {
    try {
        const userId = req.user.userId;
        const tagId = parseInt(req.params.id);
        const existing = await prisma_1.prisma.tag.findFirst({
            where: { id: tagId, userId },
        });
        if (!existing) {
            return res.status(404).json({ error: 'Tag not found' });
        }
        await prisma_1.prisma.tag.delete({
            where: { id: tagId },
        });
        res.json({ message: 'Tag deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting tag:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteTag = deleteTag;
const addTagToTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const transactionId = parseInt(req.body.transactionId);
        const tagId = parseInt(req.body.tagId);
        // Verify transaction ownership
        const transaction = await prisma_1.prisma.transaction.findFirst({
            where: {
                id: transactionId,
                userId,
            },
        });
        if (!transaction) {
            return res.status(404).json({ error: 'Transaction not found' });
        }
        // Verify tag ownership
        const tag = await prisma_1.prisma.tag.findFirst({
            where: {
                id: tagId,
                userId,
            },
        });
        if (!tag) {
            return res.status(404).json({ error: 'Tag not found' });
        }
        // Check if already linked
        const existing = await prisma_1.prisma.transactionTag.findUnique({
            where: {
                transactionId_tagId: {
                    transactionId: transactionId,
                    tagId: tagId,
                },
            },
        });
        if (existing) {
            return res.status(400).json({ error: 'Tag already linked to transaction' });
        }
        const link = await prisma_1.prisma.transactionTag.create({
            data: {
                transactionId: transactionId,
                tagId: tagId,
            },
        });
        const serialized = JSON.parse(JSON.stringify(link, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        console.error('Error adding tag to transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.addTagToTransaction = addTagToTransaction;
const removeTagFromTransaction = async (req, res) => {
    try {
        const userId = req.user.userId;
        const transactionId = parseInt(req.params.transactionId);
        const tagId = parseInt(req.params.tagId);
        // Verify transaction ownership
        const transaction = await prisma_1.prisma.transaction.findFirst({
            where: {
                id: transactionId,
                userId,
            },
        });
        if (!transaction) {
            return res.status(404).json({ error: 'Transaction not found' });
        }
        await prisma_1.prisma.transactionTag.delete({
            where: {
                transactionId_tagId: {
                    transactionId: transactionId,
                    tagId: tagId,
                },
            },
        });
        res.json({ message: 'Tag removed from transaction' });
    }
    catch (error) {
        console.error('Error removing tag from transaction:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.removeTagFromTransaction = removeTagFromTransaction;
//# sourceMappingURL=tagController.js.map