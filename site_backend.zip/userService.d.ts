export declare function seedUserData(userId: number): Promise<void>;
