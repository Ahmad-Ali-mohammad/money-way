export interface Insight {
    type: 'income_spike' | 'budget_warning' | 'recurring_detect' | 'stability_high' | 'general';
    message: string;
    action?: string;
}
export declare function generateSmartInsights(userId: number): Promise<Insight[]>;
