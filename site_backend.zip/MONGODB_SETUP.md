# دليل إعداد MongoDB للمشروع

## ✅ تم التحويل من PostgreSQL إلى MongoDB!

### الخطوة 1: تثبيت MongoDB (اختر واحدة)

#### الخيار أ: MongoDB Community Edition (موصى به)
1. حمّل من: https://www.mongodb.com/try/download/community
2. ثبّت البرنامج
3. MongoDB سيعمل تلقائياً على `mongodb://localhost:27017`

#### الخيار ب: MongoDB باستخدام Docker
```powershell
docker run --name mongodb-finance -p 27017:27017 -d mongo
```

#### الخيار ج: MongoDB Atlas (سحابي - مجاني)
1. أنشئ حساب على: https://www.mongodb.com/cloud/atlas/register
2. أنشئ Cluster مجاني
3. احصل على Connection String واستبدله في `.env`

### الخطوة 2: التحقق من عمل MongoDB

```powershell
# اختبار الاتصال
mongosh
# إذا اتصل بنجاح، اكتب:
show dbs
exit
```

### الخطوة 3: تشغيل التطبيق

```powershell
cd backend

# إعادة توليد Prisma Client (تم بالفعل ✅)
npx prisma generate

# ملء البيانات التجريبية
npm run prisma:seed

# تشغيل السيرفر
npm run dev
```

### الخطوة 4: اختبار التسجيل

```powershell
.\test-auth.ps1
```

## 📝 معلومات مهمة

### Connection String الافتراضي
```
mongodb://localhost:27017/finance_db
```

### MongoDB Compass (GUI Tool)
- حمّل من: https://www.mongodb.com/products/compass
- اتصل بـ: `mongodb://localhost:27017`
- استكشف البيانات بصرياً

### بيانات الاختبار
- **Email**: `ahmed@example.com`
- **Password**: `password123`

## المزايا ✨

- ✅ **لا حاجة لـ Migrations** - MongoDB schema-less
- ✅ **سهولة التثبيت** - ملف واحد قابل للتنفيذ
- ✅ **JSON Native** - يعمل بشكل طبيعي مع JavaScript/TypeScript
- ✅ **مرونة عالية** - يمكن تغيير الـ Schema بسهولة

## التغييرات المُطبقة

1. ✅ تحويل `schema.prisma` من PostgreSQL إلى MongoDB
2. ✅ تغيير جميع IDs من `BigInt` إلى `String @db.ObjectId`
3. ✅ تغيير `Decimal` إلى `Float`
4. ✅ إزالة `@db.Decimal`, `@db.Text`, `@db.Date`, `@db.VarChar`
5. ✅ تحديث `.env` للاتصال بـ MongoDB
6. ✅ إعادة توليد Prisma Client

## استكشاف الأخطاء

### MongoDB لا يعمل
```powershell
# Windows - تشغيل كخدمة
net start MongoDB

# أو تشغيل يدوياً
"C:\Program Files\MongoDB\Server\7.0\bin\mongod.exe" --dbpath "C:\data\db"
```

### خطأ في الاتصال
- تأكد من أن MongoDB يعمل على المنفذ 27017
- تحقق من `DATABASE_URL` في ملف `.env`
- جرب: `mongodb://127.0.0.1:27017/finance_db`

### الكود لم يتغير!
- جميع Controllers تعمل بدون تغيير
- Prisma يتعامل مع الفروقات تلقائياً
- لا حاجة لتعديل أي TypeScript code
