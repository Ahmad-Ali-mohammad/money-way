"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkGoalAlerts = exports.checkBudgetAlerts = exports.getUnreadCount = exports.deleteAlert = exports.markAllAsRead = exports.markAsRead = exports.createAlert = exports.getAllAlerts = void 0;
const prisma_1 = require("../lib/prisma");
const zod_1 = require("zod");
const alertSchema = zod_1.z.object({
    type: zod_1.z.enum(['budget_exceeded', 'goal_milestone', 'unusual_spending', 'income_received', 'bill_due', 'custom']),
    message: zod_1.z.string().min(1),
    severity: zod_1.z.enum(['low', 'medium', 'high']).default('medium'),
    isRead: zod_1.z.boolean().default(false),
    metadata: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
});
const getAllAlerts = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { isRead } = req.query;
        const where = { userId };
        if (isRead !== undefined) {
            where.isRead = isRead === 'true';
        }
        const alerts = await prisma_1.prisma.alert.findMany({
            where,
            orderBy: { createdAt: 'desc' },
            take: 50,
        });
        const serialized = JSON.parse(JSON.stringify(alerts, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error fetching alerts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getAllAlerts = getAllAlerts;
const createAlert = async (req, res) => {
    try {
        const userId = req.user.userId;
        const data = alertSchema.parse(req.body);
        const alert = await prisma_1.prisma.alert.create({
            data: {
                userId,
                type: data.type,
                message: data.message,
                severity: data.severity,
                isRead: data.isRead,
                metadata: data.metadata ? JSON.parse(JSON.stringify(data.metadata)) : null,
            },
        });
        const serialized = JSON.parse(JSON.stringify(alert, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.status(201).json(serialized);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ errors: error.issues });
        }
        console.error('Error creating alert:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.createAlert = createAlert;
const markAsRead = async (req, res) => {
    try {
        const userId = req.user.userId;
        const alertId = parseInt(req.params.id);
        const alert = await prisma_1.prisma.alert.findFirst({
            where: { id: alertId, userId },
        });
        if (!alert) {
            return res.status(404).json({ error: 'Alert not found' });
        }
        const updated = await prisma_1.prisma.alert.update({
            where: { id: alertId },
            data: { isRead: true },
        });
        const serialized = JSON.parse(JSON.stringify(updated, (key, value) => typeof value === 'bigint' ? value.toString() : value));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error marking alert as read:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.markAsRead = markAsRead;
const markAllAsRead = async (req, res) => {
    try {
        const userId = req.user.userId;
        await prisma_1.prisma.alert.updateMany({
            where: { userId, isRead: false },
            data: { isRead: true },
        });
        res.json({ message: 'All alerts marked as read' });
    }
    catch (error) {
        console.error('Error marking all alerts as read:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.markAllAsRead = markAllAsRead;
const deleteAlert = async (req, res) => {
    try {
        const userId = req.user.userId;
        const alertId = parseInt(req.params.id);
        const alert = await prisma_1.prisma.alert.findFirst({
            where: { id: alertId, userId },
        });
        if (!alert) {
            return res.status(404).json({ error: 'Alert not found' });
        }
        await prisma_1.prisma.alert.delete({
            where: { id: alertId },
        });
        res.json({ message: 'Alert deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting alert:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.deleteAlert = deleteAlert;
const getUnreadCount = async (req, res) => {
    try {
        const userId = req.user.userId;
        const count = await prisma_1.prisma.alert.count({
            where: { userId, isRead: false },
        });
        res.json({ unreadCount: count });
    }
    catch (error) {
        console.error('Error getting unread count:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getUnreadCount = getUnreadCount;
// Smart Alert Generation Functions
const checkBudgetAlerts = async (req, res) => {
    try {
        const userId = req.user.userId;
        const budgets = await prisma_1.prisma.budget.findMany({
            where: { userId },
            include: { category: true },
        });
        const alerts = [];
        for (const budget of budgets) {
            const percentage = (Number(budget.spent) / Number(budget.amount)) * 100;
            if (percentage >= 100 && !budget.isAdaptive) {
                alerts.push({
                    type: 'budget_exceeded',
                    message: `Budget exceeded for ${budget.category?.name || budget.name}! You've spent ${Math.round(percentage)}% of your budget.`,
                    severity: 'high',
                    metadata: {
                        budgetId: budget.id.toString(),
                        categoryName: budget.category?.name || budget.name,
                        percentage: Math.round(percentage).toString(),
                    },
                });
            }
            else if (percentage >= 80 && percentage < 100) {
                alerts.push({
                    type: 'budget_exceeded',
                    message: `Warning: You've used ${Math.round(percentage)}% of your ${budget.category?.name || budget.name} budget.`,
                    severity: 'medium',
                    metadata: {
                        budgetId: budget.id.toString(),
                        categoryName: budget.category?.name || budget.name,
                        percentage: Math.round(percentage).toString(),
                    },
                });
            }
        }
        // Create alerts in database
        for (const alertData of alerts) {
            await prisma_1.prisma.alert.create({
                data: {
                    userId,
                    ...alertData,
                    metadata: JSON.parse(JSON.stringify(alertData.metadata)),
                },
            });
        }
        res.json({
            message: `Generated ${alerts.length} budget alerts`,
            alerts: alerts.length,
        });
    }
    catch (error) {
        console.error('Error checking budget alerts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.checkBudgetAlerts = checkBudgetAlerts;
const checkGoalAlerts = async (req, res) => {
    try {
        const userId = req.user.userId;
        const goals = await prisma_1.prisma.goal.findMany({
            where: { userId },
        });
        const alerts = [];
        for (const goal of goals) {
            const percentage = (Number(goal.currentAmount) / Number(goal.targetAmount)) * 100;
            // Milestone alerts (25%, 50%, 75%, 100%)
            const milestones = [25, 50, 75, 100];
            for (const milestone of milestones) {
                if (percentage >= milestone && percentage < milestone + 5) {
                    alerts.push({
                        type: 'goal_milestone',
                        message: `Congratulations! You've reached ${milestone}% of your "${goal.name}" goal!`,
                        severity: 'low',
                        metadata: {
                            goalId: goal.id.toString(),
                            goalName: goal.name,
                            percentage: Math.round(percentage).toString(),
                            milestone: milestone.toString(),
                        },
                    });
                }
            }
        }
        for (const alertData of alerts) {
            await prisma_1.prisma.alert.create({
                data: {
                    userId,
                    ...alertData,
                    metadata: JSON.parse(JSON.stringify(alertData.metadata)),
                },
            });
        }
        res.json({
            message: `Generated ${alerts.length} goal alerts`,
            alerts: alerts.length,
        });
    }
    catch (error) {
        console.error('Error checking goal alerts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.checkGoalAlerts = checkGoalAlerts;
//# sourceMappingURL=alertController.js.map