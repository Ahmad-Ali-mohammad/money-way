# Test Registration and Login Flow
Write-Host "`n=== Testing Registration and Login ===" -ForegroundColor Cyan

# 1. Test Registration (New User)
Write-Host "`n[1] Testing Registration (New User)..." -ForegroundColor Yellow
Write-Host "    Email: newuser@test.com" -ForegroundColor White

$registerData = @{
    email = "newuser@test.com"
    password = "Test123456"
    name = "Test User"
    currency = "SAR"
} | ConvertTo-Json

try {
    $registerResponse = Invoke-RestMethod -Uri "http://localhost:4000/api/auth/register" `
        -Method Post `
        -Body $registerData `
        -ContentType "application/json"
    
    Write-Host "    OK - Registration successful!" -ForegroundColor Green
    Write-Host "    User ID: $($registerResponse.user.id)" -ForegroundColor Cyan
    Write-Host "    Email: $($registerResponse.user.email)" -ForegroundColor Cyan
    Write-Host "    Name: $($registerResponse.user.name)" -ForegroundColor Cyan
    
} catch {
    if ($_.Exception.Message -like "*400*") {
        Write-Host "    INFO - User already exists (expected)" -ForegroundColor Yellow
    } else {
        Write-Host "    ERROR - Registration failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# 2. Test Login with Seeded User
Write-Host "`n[2] Testing Login (Seeded User)..." -ForegroundColor Yellow
Write-Host "    Email: ahmed@example.com" -ForegroundColor White

$loginData = @{
    email = "ahmed@example.com"
    password = "password123"
} | ConvertTo-Json

try {
    $loginResponse = Invoke-RestMethod -Uri "http://localhost:4000/api/auth/login" `
        -Method Post `
        -Body $loginData `
        -ContentType "application/json"
    
    Write-Host "    OK - Login successful!" -ForegroundColor Green
    Write-Host "    User: $($loginResponse.user.name)" -ForegroundColor Cyan
    Write-Host "    Email: $($loginResponse.user.email)" -ForegroundColor Cyan
    Write-Host "    User ID: $($loginResponse.user.id)" -ForegroundColor Cyan
    
    $token = $loginResponse.token
    
    # 3. Test accessing protected data
    Write-Host "`n[3] Testing Protected Endpoints..." -ForegroundColor Yellow
    
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type" = "application/json"
    }
    
    # Get accounts
    $accounts = Invoke-RestMethod -Uri "http://localhost:4000/api/accounts" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n    OK - Accounts retrieved!" -ForegroundColor Green
    Write-Host "    Total accounts: $($accounts.Count)" -ForegroundColor White
    foreach ($account in $accounts) {
        $balanceColor = if ($account.balance -ge 0) { "Green" } else { "Red" }
        Write-Host "      * $($account.name): " -NoNewline -ForegroundColor White
        Write-Host "$($account.balance) $($account.currency)" -ForegroundColor $balanceColor
    }
    
    # Get transactions
    $transactions = Invoke-RestMethod -Uri "http://localhost:4000/api/transactions?limit=5" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n    OK - Transactions retrieved!" -ForegroundColor Green
    Write-Host "    Total transactions: $($transactions.Count)" -ForegroundColor White
    
    # Get budgets
    $budgets = Invoke-RestMethod -Uri "http://localhost:4000/api/budgets" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n    OK - Budgets retrieved!" -ForegroundColor Green
    Write-Host "    Total budgets: $($budgets.Count)" -ForegroundColor White
    foreach ($budget in $budgets) {
        $percentage = if ($budget.amount -gt 0) { 
            [math]::Round(($budget.spent / $budget.amount) * 100, 1) 
        } else { 0 }
        Write-Host "      * $($budget.name): $($budget.spent)/$($budget.amount) ($percentage%)" -ForegroundColor White
    }
    
    # Get goals
    $goals = Invoke-RestMethod -Uri "http://localhost:4000/api/goals" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n    OK - Goals retrieved!" -ForegroundColor Green
    Write-Host "    Total goals: $($goals.Count)" -ForegroundColor White
    
    # Get tags
    $tags = Invoke-RestMethod -Uri "http://localhost:4000/api/tags" `
        -Method Get `
        -Headers $headers
    
    Write-Host "`n    OK - Tags retrieved!" -ForegroundColor Green
    Write-Host "    Total tags: $($tags.Count)" -ForegroundColor White
    
    Write-Host "`n======================================" -ForegroundColor Gray
    Write-Host "SUCCESS - All tests passed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Summary:" -ForegroundColor Cyan
    Write-Host "  [OK] Database connected and active" -ForegroundColor Green
    Write-Host "  [OK] Test data seeded successfully" -ForegroundColor Green
    Write-Host "  [OK] Registration working" -ForegroundColor Green
    Write-Host "  [OK] Login working" -ForegroundColor Green
    Write-Host "  [OK] Authentication working" -ForegroundColor Green
    Write-Host "  [OK] Protected API working" -ForegroundColor Green
    Write-Host ""
    Write-Host "Test Credentials:" -ForegroundColor Yellow
    Write-Host "  Email: ahmed@example.com" -ForegroundColor White
    Write-Host "  Password: password123" -ForegroundColor White
    Write-Host ""
    
} catch {
    Write-Host "    ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails) {
        Write-Host "    Details: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
    exit 1
}
