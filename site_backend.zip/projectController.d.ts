import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
export declare const getAllProjects: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createProject: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getProjectById: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateProject: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteProject: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getFeasibilityAnalysis: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const analyzeProjects: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
