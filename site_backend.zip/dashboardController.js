"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDashboardStats = exports.getDashboardOverview = void 0;
const prisma_1 = require("../lib/prisma");
const insightService_1 = require("../services/insightService");
const getDashboardOverview = async (req, res) => {
    try {
        const userId = req.user.userId;
        // Get current date and date 3 months ago
        const now = new Date();
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(now.getMonth() - 3);
        const [incomeAggregate, expenseAggregate, transactionCount, recentTransactions, goals, accounts, recentExpensesAggregate] = await Promise.all([
            prisma_1.prisma.transaction.aggregate({
                where: { userId, type: 'income' },
                _sum: { amount: true },
            }),
            prisma_1.prisma.transaction.aggregate({
                where: { userId, type: 'expense' },
                _sum: { amount: true },
            }),
            prisma_1.prisma.transaction.count({ where: { userId } }),
            prisma_1.prisma.transaction.findMany({
                where: { userId },
                include: { category: true },
                orderBy: { occurredAt: 'desc' },
                take: 10,
            }),
            prisma_1.prisma.goal.findMany({
                where: { userId },
                orderBy: { createdAt: 'desc' },
                take: 5,
            }),
            prisma_1.prisma.account.findMany({
                where: { userId }
            }),
            prisma_1.prisma.transaction.aggregate({
                where: {
                    userId,
                    type: 'expense',
                    occurredAt: { gte: threeMonthsAgo }
                },
                _sum: { amount: true }
            })
        ]);
        const totalIncome = Number(incomeAggregate._sum.amount ?? 0);
        const totalExpense = Number(expenseAggregate._sum.amount ?? 0);
        // Financial Stability Score Algorithm
        const totalLiquidAssets = accounts.reduce((sum, acc) => sum + Number(acc.balance), 0);
        const totalSavingsGoals = goals.reduce((sum, g) => sum + Number(g.currentAmount), 0);
        const threeMonthExpenses = Number(recentExpensesAggregate._sum.amount ?? 0);
        const monthlyExpenseAverage = Math.max(threeMonthExpenses / 3, 1); // Avoid division by zero
        const safetyBuffer = totalLiquidAssets + totalSavingsGoals;
        const monthsOfRunway = safetyBuffer / monthlyExpenseAverage;
        const stabilityScore = Math.min(Math.round((monthsOfRunway / 6) * 100), 100);
        // Generate insights
        const insights = await (0, insightService_1.generateSmartInsights)(userId);
        const payload = {
            summary: {
                totalIncome,
                totalExpense,
                netCashflow: totalIncome - totalExpense,
                transactionCount,
                stabilityScore,
                monthsOfRunway: Math.round(monthsOfRunway * 10) / 10,
            },
            recentTransactions,
            goals,
            insights,
        };
        const serialized = JSON.parse(JSON.stringify(payload, (key, value) => (typeof value === 'bigint' ? value.toString() : value)));
        res.json(serialized);
    }
    catch (error) {
        console.error('Error building dashboard overview:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getDashboardOverview = getDashboardOverview;
// New: basic stats endpoint for specific periods
const getDashboardStats = async (req, res) => {
    try {
        const userId = req.user.userId;
        const period = req.query.period || 'month';
        const now = new Date();
        let startDate = new Date();
        if (period === 'month') {
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        }
        else if (period === 'year') {
            startDate = new Date(now.getFullYear(), 0, 1);
        }
        else {
            // default to 3 months
            startDate.setMonth(now.getMonth() - 2);
            startDate = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
        }
        const [incomeAggregate, expenseAggregate] = await Promise.all([
            prisma_1.prisma.transaction.aggregate({
                where: { userId, type: 'income', occurredAt: { gte: startDate } },
                _sum: { amount: true },
            }),
            prisma_1.prisma.transaction.aggregate({
                where: { userId, type: 'expense', occurredAt: { gte: startDate } },
                _sum: { amount: true },
            }),
        ]);
        const totalIncome = Number(incomeAggregate._sum.amount ?? 0);
        const totalExpense = Number(expenseAggregate._sum.amount ?? 0);
        res.json({ period, totalIncome, totalExpense, netCashflow: totalIncome - totalExpense });
    }
    catch (error) {
        console.error('Error building dashboard stats:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getDashboardStats = getDashboardStats;
//# sourceMappingURL=dashboardController.js.map